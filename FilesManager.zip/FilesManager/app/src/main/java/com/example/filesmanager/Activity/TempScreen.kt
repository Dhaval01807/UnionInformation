package com.example.filesmanager.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.example.filesmanager.databinding.ActivityTempScreenBinding

class TempScreen : AppCompatActivity() {

    private lateinit var binding: ActivityTempScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTempScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = ViewModelProvider(this)[TempViewModel::class.java]

        viewModel.tempList.observe(this){
            binding.txt.text = it.size.toString()
        }

        binding.add.setOnClickListener {
            viewModel.update()
        }

        binding.update.setOnClickListener {
            viewModel.updateNotifiy()
        }

    }
}