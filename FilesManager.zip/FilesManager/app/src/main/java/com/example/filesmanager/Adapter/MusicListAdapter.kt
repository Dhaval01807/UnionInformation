package com.example.filesmanager.Adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filesmanager.Activity.MusicPlayerScreen
import com.example.filesmanager.Model.MusicModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.Helper

class MusicListAdapter(val context: Context, var arr: List<MusicModel>): RecyclerView.Adapter<MusicListAdapter.MusicListViewHolder>() {
    class MusicListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val musicLayout = itemView.findViewById<LinearLayout>(R.id.ll_music)
        val musicIcon = itemView.findViewById<ImageView>(R.id.iv_music_icon)
        val musicName = itemView.findViewById<TextView>(R.id.tv_music_name)
        val duration = itemView.findViewById<TextView>(R.id.tv_music_duration)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): MusicListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.music_list_layout,parent,false)
        return MusicListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: MusicListViewHolder, position: Int) {
        holder.musicName.text = arr[position].fileName
        holder.duration.text = Helper.getDuration(arr[position].duration)
        Glide.with(holder.musicIcon.context).load(Uri.parse("content://media/external/audio/albumart/${arr[position].posterUri}")).into(holder.musicIcon)
        holder.musicLayout.setOnClickListener{
            AppConstant.musicPlayList = arr
            AppConstant.musicIndex = position
            val newIntent = Intent(context,MusicPlayerScreen::class.java)
            context.startActivity(newIntent)
        }
    }

    fun update(newData: List<MusicModel>){
        arr = newData
        notifyDataSetChanged()
    }
}