package com.example.filesmanager.Activity

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.filesmanager.R
import org.apache.ftpserver.FtpServer
import org.apache.ftpserver.FtpServerFactory
import org.apache.ftpserver.ftplet.UserManager
import org.apache.ftpserver.listener.ListenerFactory
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory
import org.apache.ftpserver.usermanager.impl.BaseUser
import org.apache.ftpserver.usermanager.impl.WritePermission
import java.io.File
import java.io.FileOutputStream

class Temp : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_temp)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val ftpServer: FtpServer

        try {
            val serverFactory: FtpServerFactory = FtpServerFactory()
            val listenerFactory: ListenerFactory = ListenerFactory()
            listenerFactory.setPort(8888)
            serverFactory.addListener("default", listenerFactory.createListener())


            val userManagerFactory: PropertiesUserManagerFactory = PropertiesUserManagerFactory()
//            val usersFile = File("ftpusers.properties")

            val file = File(cacheDir, "ftpusers.properties")

            val output = FileOutputStream(file)
            assets.open("ftpusers.properties").use {
                    input->
                var read:Int=0
                output.use {
                        it->
                    while(read!=-1){
                        read = input.read()
                        it.write(read)
                    }
                }
            }

            Log.e("TAG", "onCreate: ${file.path}", )

            userManagerFactory.setFile(file)



            val userManager: UserManager = userManagerFactory.createUserManager()

            val user: BaseUser = BaseUser()
            user.name = "pc"
            user.password = "121"
            user.homeDirectory = "/storage/emulated/0/Download/"
            user.authorities = listOf(WritePermission())

            userManager.save(user)
            serverFactory.setUserManager(userManager)

            ftpServer = serverFactory.createServer()

            ftpServer.start()
            Log.d("TAG", "FTP Server started on port " + 8888)
        } catch (e: Exception) {
            Log.e("TAG", "Error starting FTP server", e)
        }
    }

}