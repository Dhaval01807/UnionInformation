package com.example.filesmanager.ViewModel

import android.content.ContentResolver
import android.os.Build
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import androidx.lifecycle.ViewModel
import com.example.filesmanager.Model.NewFileModel
import java.text.SimpleDateFormat
import java.util.Date

class NewFileRepo : ViewModel() {


    fun getAllNewFile(contentResolver: ContentResolver): List<NewFileModel> {
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }

        val extension = arrayOf(
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("png"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpg"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpeg"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("gif"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp4"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("mkv"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("avi"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp3"),
        )
        val projection = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
        )

        val dateOf30DayBefore = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
        val selection = MediaStore.Files.FileColumns.DATE_MODIFIED + " > ?"
        val args = arrayOf(
            (dateOf30DayBefore / 1000).toString()
        )
        val allFile: MutableList<NewFileModel> = mutableListOf()
        val format = SimpleDateFormat("dd-MM-yyyy")
        val pointer = contentResolver.query(
            uri,
            projection,
            selection,
            args,
            "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
        )
        try {
            if (pointer != null) {
                while (pointer.moveToNext()) {
                    val fileId = pointer.getLong(0)
                    val fileName = pointer.getString(1)
                    val filePath = pointer.getString(2)
                    val fileSize = pointer.getLong(3)
                    val fileType = pointer.getString(4)
                    val fileDate = pointer.getString(5)
                    val date = format.format(Date(fileDate.toLong()*1000))
                    if (extension.contains(fileType)) {
                        allFile.add(
                            NewFileModel(
                                fileId,
                                fileName,
                                filePath,
                                fileSize,
                                fileType,
                                date
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            return listOf()
        }

        return allFile
    }
}