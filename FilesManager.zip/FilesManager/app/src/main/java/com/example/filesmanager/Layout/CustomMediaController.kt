package com.example.filesmanager.Layout

import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.media.MediaPlayer
import android.provider.MediaStore
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import com.example.filesmanager.Interface.CustomMediaPlayer
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class CustomMediaController(val context:Activity) : FrameLayout(context),
    CustomMediaPlayer {


    private final val TAG = "CustomMediaController"


    var playButton: ImageView? = null
    var previousButton: ImageView? = null
    var nextButton: ImageView? = null
    var currentDuration: TextView? = null
    var totalDuration: TextView? = null
    var mediaPlayer: MediaPlayer? = null
    var backButton: ImageView? = null
    var videoName: TextView? = null
    var videoRotate: ImageView? = null
    var videoCrop: ImageView? = null



    private var anchorView: ViewGroup? = null
    private val isPlaying: MutableStateFlow<Boolean> = MutableStateFlow(true)
    var seekHandler: Job? = null
    var seekBar: SeekBar? = null

    fun initiateMediaPlayer() {
        mediaPlayer = MediaPlayer()
        mediaPlayer?.reset()
        mediaPlayer?.setOnPreparedListener {

            videoName?.text = Helper.videoFolder[Helper.videoPosition].fileName
            it.start()
            seekBar?.max = it.duration
            seekBar?.progress = 0
            it.setOnCompletionListener {
                if(Helper.videoPosition == Helper.videoFolder.size-1){
                    context.finish()
                }else{
                    nextItem()
                }
            }
            totalDuration?.text = Helper.getDuration(it.duration.toLong())
            playButton?.isEnabled = true
            nextButton?.isEnabled = true
            previousButton?.isEnabled = true
            seekBar?.isEnabled = true
            seekHandler()
        }

        mediaPlayer?.setDataSource(
            context, ContentUris.withAppendedId(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                Helper.videoFolder[Helper.videoPosition].id
            )
        )
    }

    fun changeVideo() {
        playButton?.isEnabled = false
        nextButton?.isEnabled = false
        previousButton?.isEnabled = false
        seekBar?.isEnabled = false

        mediaPlayer?.reset()
        mediaPlayer?.setDataSource(
            context, ContentUris.withAppendedId(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                Helper.videoFolder[Helper.videoPosition].id
            )
        )
        mediaPlayer?.prepareAsync()
    }

    fun setAnchorView(
        view: ViewGroup
    ) {
        anchorView = view
        removeAllViews()

        var controllerView: View? = null
        var topBarView: View? = null

        controllerView = getControllerView()
        val bottomLayoutParams = LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM
        )
        addView(controllerView, bottomLayoutParams)
        controllerView?.visibility = GONE

        topBarView = getAppBarView()
        val topBarLayoutParams = LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP
        )
        addView(topBarView, topBarLayoutParams)
        topBarView?.visibility = GONE

        val frameLayout = LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
        )
        anchorView?.addView(this, frameLayout)
    }

    fun getAppBarView(): View {
        val layoutInflater: LayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val appBarView = layoutInflater.inflate(R.layout.video_app_bar, null)
        initializeAppBar(appBarView)
        return appBarView!!
    }

    fun getControllerView(): View {
        val layoutInflater: LayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val controllerView = layoutInflater.inflate(R.layout.media_controller_layout, null)
        initializeButtons(controllerView)
        return controllerView!!
    }

    fun initializeAppBar(view:View){
        backButton = view.findViewById(R.id.iv_video_back)
        videoName = view.findViewById(R.id.tv_video_name)

        backButton?.setOnClickListener {
            context.finish()
        }
    }
    fun initializeButtons(view: View) {
        playButton = view.findViewById<ImageView>(R.id.iv_video_play_pause)
        previousButton = view.findViewById<ImageView>(R.id.iv_video_previous)
        nextButton = view.findViewById<ImageView>(R.id.iv_video_next)
        currentDuration = view.findViewById<TextView>(R.id.tv_current_duration)
        totalDuration = view.findViewById<TextView>(R.id.tv_total_duration)
        seekBar = view.findViewById<SeekBar>(R.id.sb_video_progress)
        videoRotate = view.findViewById(R.id.iv_video_rotate)
        videoCrop = view.findViewById(R.id.iv_video_crop)

        CoroutineScope(Dispatchers.IO).launch {
            isPlaying.collectLatest {
                Log.e(TAG, "initializeButtons: Collected")
                withContext(Dispatchers.Main){
                    if (it) {
                        playButton?.setImageDrawable(
                            AppCompatResources.getDrawable(
                                context, R.drawable.ic_pause_btn
                            )
                        )
                    } else {
                        playButton?.setImageDrawable(
                            AppCompatResources.getDrawable(
                                context, R.drawable.ic_play_btn
                            )
                        )
                    }
                }
            }
        }


        videoRotate?.setOnClickListener {

            val screenOrientation = resources.configuration.orientation
            if(screenOrientation == Configuration.ORIENTATION_PORTRAIT){
                context.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            }else{
                context.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            }
        }

        playButton?.setOnClickListener{
            if (isPlaying.value) {
                pause()
            } else {
                start()
            }
        }

        previousButton?.setOnClickListener{
            prevItem()
        }

        nextButton?.setOnClickListener{
            nextItem()
        }

        seekBar?.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(p0: SeekBar?, p1: Int, p2: Boolean) {
                    currentDuration?.text = Helper.getDuration(p1.toLong())
                }

                override fun onStartTrackingTouch(p0: SeekBar?) {

                }

                override fun onStopTrackingTouch(p0: SeekBar?) {
                    p0?.let {
                        seekTo(it.progress)
                    }
                }

            })
    }

    fun seekHandler() {
        Log.e(TAG, "seekHandler: SeekHandler", )
        seekHandler?.cancel()
        seekHandler = CoroutineScope(Dispatchers.IO).launch {
            var duration = 0
            do {
                
                duration = mediaPlayer?.currentPosition!!
                Log.e(TAG, "seekHandler: $duration ${mediaPlayer?.duration}", )
                seekBar?.progress = duration
                delay(1000)
            } while (duration < mediaPlayer?.duration!!)
        }
    }

    override fun start() {
        isPlaying.update {
            true
        }
        mediaPlayer?.start()
    }

    override fun pause() {
        isPlaying.update {
            false
        }
        mediaPlayer?.pause()
    }

    override fun getDuration(): Int {
        return mediaPlayer?.duration ?: 0
    }

    override fun getCurrentPosition(): Int {
        return mediaPlayer?.currentPosition ?: 0
    }

    override fun seekTo(pos: Int) {
        mediaPlayer?.seekTo(pos)
    }

    override fun isPlaying(): Boolean {
        return isPlaying.value
    }

    override fun getBufferPercentage(): Int {
        return 0
    }

    override fun canPause(): Boolean {
        return isPlaying.value
    }

    override fun canSeekBackward(): Boolean {
        return true
    }

    override fun canSeekForward(): Boolean {
        return true
    }


    override fun isFullScreen(): Boolean {
        return true
    }

    override fun toggleFullScreen() {

    }

    override fun nextItem() {
        if(Helper.videoPosition!=Helper.videoFolder.size-1){
            Helper.videoPosition = Helper.videoPosition.plus(1)
            changeVideo()
        }
    }

    override fun prevItem() {
        if (Helper.videoPosition != 0) {
            Helper.videoPosition -= 1
            changeVideo()
        }
    }
}