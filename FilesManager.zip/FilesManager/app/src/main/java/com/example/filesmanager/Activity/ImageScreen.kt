package com.example.filesmanager.Activity

import android.app.Dialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.filesmanager.Adapter.ImageAdapter
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityImageScreenBinding
import com.yalantis.ucrop.UCrop
import java.io.File


class ImageScreen : AppCompatActivity() {
    private lateinit var binding: ActivityImageScreenBinding

    private final val TAG = "SingleImage"
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        val rotateList = List(Helper.imageFolder.size) { 0f }.toMutableList()
        var imageIndex = 0
        binding = ActivityImageScreenBinding.inflate(layoutInflater)

        setContentView(binding.root)


        val imageSlider = ImageAdapter(Helper.imageFolder, rotateList)
        binding.vpImageSlider.adapter = imageSlider
        binding.vpImageSlider.setCurrentItem(Helper.imagePosition,false)
        binding.vpImageSlider.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                Helper.imagePosition = position
                super.onPageSelected(position)
            }
        })


        binding.llRotate.setOnClickListener {
            rotateList[imageIndex] += 90f
            imageSlider.rotateImage(rotateList[imageIndex], Helper.imagePosition)
            if (rotateList[imageIndex] == 360f) {
                rotateList[imageIndex] = 0f
            }
        }

        binding.llDelete.setOnClickListener {
            val dialog = Dialog(this, R.style.FullWidthDialog)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            val layoutParams = WindowManager.LayoutParams()
            layoutParams.copyFrom(dialog.window!!.attributes)
            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT

            dialog.window!!.attributes = layoutParams
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(true)

            val view = layoutInflater.inflate(R.layout.confirm_delete_dialog, null)
            dialog.setContentView(view)

            dialog.show()
        }

        binding.llShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "image/jpeg"
            shareIntent.putExtra(
                Intent.EXTRA_STREAM,
                ContentUris.withAppendedId(Helper.imageUri, Helper.imageFolder[Helper.imagePosition].id)
            )
            startActivity(shareIntent)
        }

        binding.llCrop.setOnClickListener {
            var download = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)

            val crop = UCrop.of(
                ContentUris.withAppendedId(
                    Helper.imageUri,
                    Helper.imageFolder[Helper.imagePosition].id
                ), Uri.fromFile(File(cacheDir.path + "/temp.jpg"))
            )
                .withMaxResultSize(120, 120)

            val cropIntent = crop.getIntent(this)

            cropIntentResult.launch(cropIntent)
        }

    }

    val cropIntentResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        Log.e(TAG, "Something Hit: ${result.resultCode}")
        val temp = File(cacheDir.path + "/temp.jpg")
        if (result.resultCode == RESULT_OK) {
            val resultUri: Uri = UCrop.getOutput(result.data!!)!!
            if(temp.exists()){
                temp.delete()
            }
        } else{
            if(temp.exists()){
                temp.delete()
            }
        }
    }
}