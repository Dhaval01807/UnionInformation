package com.example.filesmanager.Adapter


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper


class DuplicateFileListAdapter(context: Context, private val arr: List<QuickFileModel>) :
    ArrayAdapter<QuickFileModel>(context, 0, arr) {


    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView

        if (view == null) {
            view = LayoutInflater.from(context)
                .inflate(R.layout.quick_clean_file_layout, parent, false)
        }

        val file: QuickFileModel = getItem(position)!!

        val fileIcon = view!!.findViewById<ImageView>(R.id.iv_quickFile_icon)
        val fileName = view.findViewById<TextView>(R.id.tv_quickFile_name)
        val fileSize = view.findViewById<TextView>(R.id.tv_quickFile_size)
        val fileLayout = view.findViewById<LinearLayout>(R.id.ll_quick_clean)
        val fileDelete = view.findViewById<CheckBox>(R.id.cb_quickFile_delete)
        val fileDate = view.findViewById<TextView>(R.id.tv_fileDate)



        Helper.populateIcon(context, Helper.fromMimeType(arr[position].fileType),arr[position].filePath,arr[position].id,fileIcon)

        fileName.text = file.fileName
        fileSize.text = Helper.formatSize(file.fileSize)

        return view
    }

    fun update() {
        notifyDataSetChanged()
    }
}