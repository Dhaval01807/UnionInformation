package com.example.filesmanager.ViewModel

import android.content.ContentResolver
import android.os.Build
import android.provider.MediaStore
import com.example.filesmanager.Model.DownloadModel

class DownloadRepo {

    fun getAllDownloadFile(contentResolver: ContentResolver): List<DownloadModel> {
        val downloadFiles: MutableList<DownloadModel> = mutableListOf()

        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }


        val selection =
            MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME + "= ?"
        val projections =
            arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.BUCKET_DISPLAY_NAME,
            )

        val pointer = contentResolver.query(uri, projections, selection, arrayOf("Download"), null)
        if (pointer != null) {
            while (pointer.moveToNext()) {
                val id = pointer.getLong(0)
                val filePath = pointer.getString(1)
                val fileName = pointer.getString(2)
                val fileType = pointer.getString(4)
                val fileSize = pointer.getLong(5)
                if (fileType != null) {
                    downloadFiles.add(DownloadModel(id, fileName, fileType, fileSize,filePath))
                }
            }
        }

        return downloadFiles
    }
}