package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.TextView
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.R

class DuplicateFilesAdapter(context: Context, private val arr: List<List<QuickFileModel>>) :
    ArrayAdapter<QuickFileModel>(context, 0, arr.size) {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var view = convertView

        if (view == null) {
            view =
                LayoutInflater.from(context).inflate(R.layout.duplicate_files_layout, parent, false)
        }

        val fileName = view!!.findViewById<TextView>(R.id.tv_fileName)
        val list = view.findViewById<LinearLayout>(R.id.lv_duplicate_file)

        val adapter = DuplicateFileListAdapter(context, arr[position])
        for (i in 0 until arr[position].size) {
            fileName.text =arr[position].first().fileName
            val view = adapter.getView(i, null, list)
            list.addView(view)
        }

        return view
    }
}

//
//class DuplicateFilesAdapter(val context: Context, val arr: Map<String, List<QuickFileModel>>) :
//    RecyclerView.Adapter<DuplicateFilesAdapter.DuplicateFilesViewHolder>() {
//
//    val keys = arr.keys.toList()
//
//    class DuplicateFilesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
//        val fileName: TextView = itemView.findViewById(R.id.tv_fileName)
//        val list: LinearLayout = itemView.findViewById(R.id.lv_duplicate_file)
//    }
//
//    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DuplicateFilesViewHolder {
//        val view = LayoutInflater.from(parent.context)
//            .inflate(R.layout.duplicate_files_layout, parent, false)
//        return DuplicateFilesViewHolder(view)
//    }
//
//    override fun getItemCount(): Int {
//        return arr.size
//    }
//
//    override fun onBindViewHolder(holder: DuplicateFilesViewHolder, position: Int) {
//        holder.fileName.text = arr[keys[position]]!!.first().fileName
//        val adapter = DuplicateFileListAdapter(context,arr[keys[position]]!!)
//
//        for (i in 0 until arr[keys[position]]!!.size) {
//            val view = adapter.getView(i, null, holder.list)
//            holder.list.addView(view)
//        }
//    }
//}