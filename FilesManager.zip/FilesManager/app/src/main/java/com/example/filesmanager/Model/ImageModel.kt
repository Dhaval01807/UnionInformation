package com.example.filesmanager.Model

data class ImageModel(val id:Long,val fileName:String,val filePath:String,val fileSize:Long)
