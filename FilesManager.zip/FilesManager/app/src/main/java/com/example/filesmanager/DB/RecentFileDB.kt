package com.example.filesmanager.DB

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [RecentFileEntity::class], version = 2, exportSchema = false)
abstract class RecentFileDB : RoomDatabase() {
    abstract fun getRecentDao(): RecentFileDao

    companion object {
        private const val Database_NAME = "recent.db"

        @Volatile
        private var INSTANCE: RecentFileDB? = null

        fun getInstance(context: Context): RecentFileDB {
            synchronized(this) {
                var instance = INSTANCE

                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        RecentFileDB::class.java,
                        Database_NAME
                    ).fallbackToDestructiveMigration().build()

                    INSTANCE = instance
                }
                return instance
            }
        }
    }
}