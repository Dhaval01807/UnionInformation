package com.example.filesmanager.Activity

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.filesmanager.Adapter.QuickFilesAdapter
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.ViewModel.QuickScanViewModel
import com.example.filesmanager.databinding.ActivityQuickScanResultBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class QuickScanResult : AppCompatActivity() {
    private lateinit var binding: ActivityQuickScanResultBinding
    private lateinit var viewModel: QuickScanViewModel
    private final val TAG = "QuickScanResult"
    var shortAnimationDuration: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityQuickScanResultBinding.inflate(layoutInflater)
        shortAnimationDuration = 200
        setContentView(binding.root)

        viewModel = CommonViewModel.cleanViewModel
        if (!viewModel.quickScanDone) {
            CoroutineScope(Dispatchers.IO).launch {
                viewModel.quickScan(contentResolver)
            }
        }


        initializeLiveData()
        initializeClickListener()


    }

    private fun initializeClickListener() {
        binding.ivDuplicateFileDown.setOnClickListener {
            flipVisibility(binding.ivDuplicateFileDown, binding.lvDuplicateFile)
        }

        binding.ivLargeFileDown.setOnClickListener {
            flipVisibility(binding.ivLargeFileDown, binding.lvLargeFile)
        }

        binding.ivInstalledApkDown.setOnClickListener {
            flipVisibility(binding.ivInstalledApkDown, binding.lvInstalledApk)
        }

        binding.ivTrashDown.setOnClickListener {
            flipVisibility(binding.ivTrashDown, binding.lvTrash)
        }
    }

    private fun initializeLiveData() {
        viewModel.largeFile.observe(this) {
            if (viewModel.largeFileSearched) {
                binding.pbLargeFile.visibility = GONE
                binding.ivLargeFileDown.visibility = VISIBLE
                binding.tvLargeFileStatus.text =
                    updateSelectionText(0, viewModel.largeFileSize, 0, it.size.toLong())

                val adapter = QuickFilesAdapter(
                    context = this,
                    it.toMutableList(),
                    viewModel.largeFileDelete,
                    viewModel.largeDeleteFileSize,
                    binding.cbLargeFile
                )
                for (i in it.indices) {
                    val view = adapter.getView(i, null, binding.lvLargeFile)
                    binding.lvLargeFile.addView(view)
                }

                binding.cbLargeFile.setOnCheckedChangeListener { compoundButton, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }
        }
        viewModel.largeDeleteFileSize.observe(this) {
            Log.e(TAG, "onCreate: ${viewModel.largeFileDelete.value?.size}")
            binding.tvLargeFileStatus.text = updateSelectionText(
                it,
                viewModel.largeFileSize,
                viewModel.largeFileDelete.value!!.size.toLong(),
                viewModel.largeFile.value!!.size.toLong()
            )
            updateDeleteLayout()

        }


        viewModel.duplicateFile.observe(this) {
            if (viewModel.duplicateFileSearched) {

                binding.pbDuplicateFile.visibility = GONE
                binding.ivDuplicateFileDown.visibility = VISIBLE
                binding.tvDuplicateStatus.text =
                    updateSelectionText(0, viewModel.duplicateFileSize, 0, it.size.toLong())


                val keys = it.keys
                val fileList: MutableList<QuickFileModel> = mutableListOf()
                for (key in keys) {
                    fileList.addAll(it[key]!!)
                }
                val adapter = QuickFilesAdapter(
                    this,
                    fileList,
                    viewModel.duplicateFileDelete,
                    viewModel.duplicateDeleteSize,
                    binding.cbDuplicateFile
                )
                for (i in 0 until it.size) {
                    val view = adapter.getView(i, null, binding.lvDuplicateFile)
                    binding.lvDuplicateFile.addView(view)
                }

                binding.cbDuplicateFile.setOnCheckedChangeListener { _, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }

        }
        viewModel.duplicateDeleteSize.observe(this) {
            binding.tvDuplicateStatus.text = updateSelectionText(
                it,
                viewModel.duplicateFileSize,
                viewModel.duplicateFileDelete.value!!.size.toLong(),
                viewModel.duplicateFile.value!!.size.toLong()
            )
            updateDeleteLayout()
        }


        viewModel.installedApk.observe(this) {
            if (viewModel.installApkSearched) {

                binding.pbInstalled.visibility = GONE
                binding.ivInstalledApkDown.visibility = VISIBLE
                binding.tvInstalledStatus.text =
                    updateSelectionText(0, viewModel.installedApkSize, 0, it.size.toLong())


                val adapter = QuickFilesAdapter(
                    this,
                    it.toMutableList(),
                    viewModel.installedApkDelete,
                    viewModel.installedApkDeleteSize,
                    binding.cbInstalledApk
                )

                for (i in 0 until it.size) {
                    val view = adapter.getView(i, null, binding.lvInstalledApk)
                    binding.lvInstalledApk.addView(view)
                }

                binding.cbInstalledApk.setOnCheckedChangeListener { compoundButton, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }

        }
        viewModel.installedApkDeleteSize.observe(this) {
            binding.tvInstalledStatus.text = updateSelectionText(
                it,
                viewModel.installedApkDeleteSize.value!!,
                viewModel.installedApkDelete.value!!.size.toLong(),
                viewModel.installedApk.value!!.size.toLong()
            )
            updateDeleteLayout()

        }


        viewModel.trashFile.observe(this) {

            if (viewModel.trashFileSearched) {

                binding.pbTrash.visibility = GONE
                binding.ivTrashDown.visibility = VISIBLE
                binding.tvTrashStatus.text =
                    updateSelectionText(0, viewModel.trashFileSize, 0, it.size.toLong())


                val adapter = QuickFilesAdapter(
                    this,
                    it.toMutableList(),
                    viewModel.trashDelete,
                    viewModel.trashDeleteSize,
                    binding.cbTrashFile
                )

                for (i in it.indices) {
                    val view = adapter.getView(i, null, binding.lvTrash)
                    binding.lvTrash.addView(view)
                }

                binding.cbTrashFile.setOnCheckedChangeListener { compoundButton, isChecked ->
                    if (isChecked) adapter.selectAll() else adapter.clearAll()
                }
            }

        }
        viewModel.trashDeleteSize.observe(this) {
            binding.tvTrashStatus.text = updateSelectionText(
                it,
                viewModel.trashFileSize,
                viewModel.trashDelete.value!!.size.toLong(),
                viewModel.trashFile.value!!.size.toLong()
            )
            updateDeleteLayout()
        }
    }

    private fun updateSelectionText(
        deleteFileSize: Long,
        totalFileSize: Long,
        deleteFileCount: Long,
        totalCount: Long
    ): String {
        return "${Helper.formatSize(deleteFileSize)}/${Helper.formatSize(totalFileSize)} || ${deleteFileCount}/${totalCount} Items"
    }

    private fun updateDeleteLayout() {

        val size: Long =
            viewModel.largeDeleteFileSize.value!! + viewModel.duplicateDeleteSize.value!! + viewModel.duplicateDeleteSize.value!! + viewModel.trashDeleteSize.value!!
        if (size != 0L) {
            binding.llCleanBottom.visibility = VISIBLE
            binding.tvFinalTotalClean.text = Helper.formatSize(size)
        } else {
            binding.llCleanBottom.visibility = GONE
        }
    }

    private fun flipVisibility(down: ImageView, list: LinearLayout) {
        if (down.rotation.toInt() == 0 || down.rotation.toInt() == 360) {
            down.rotation = 0f
            down.animate().rotation(180f).setDuration(shortAnimationDuration.toLong())
                .setListener(null)
        } else {
            down.animate().rotation(360f).setDuration(shortAnimationDuration.toLong())
                .setListener(null)
        }

        list.apply {
            if (visibility == VISIBLE) {
                alpha = 1f
                animate().alpha(0f).setDuration(shortAnimationDuration.toLong())
                    .setListener(object :
                        AnimatorListenerAdapter() {
                        override fun onAnimationEnd(animation: Animator) {
                            visibility = GONE
                        }
                    })
            } else {
                alpha = 0f
                visibility = VISIBLE
                animate().alpha(1f).setDuration(shortAnimationDuration.toLong()).setListener(null)
            }
        }
    }


}