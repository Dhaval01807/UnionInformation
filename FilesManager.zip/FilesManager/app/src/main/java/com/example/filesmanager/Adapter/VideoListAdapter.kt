package com.example.filesmanager.Adapter

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filesmanager.Activity.ExoVideoPlayer
import com.example.filesmanager.Model.VideoModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper

class VideoListAdapter(val context: Context, var arr:List<VideoModel>): RecyclerView.Adapter<VideoListAdapter.VideoListViewHolder>() {

    private final val TAG = "VideoListAdapter"
    class VideoListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val videoLayout = itemView.findViewById<LinearLayout>(R.id.ll_video_layout)
        val videoThumbnail = itemView.findViewById<ImageView>(R.id.iv_video_thumbnail)
        val videoName = itemView.findViewById<TextView>(R.id.tv_video_name)
        val videoTime = itemView.findViewById<TextView>(R.id.tv_video_time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): VideoListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.video_list_layout,parent,false)
        return VideoListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: VideoListViewHolder, position: Int) {
        holder.videoName.text = arr[position].fileName
        Glide.with(context).load(ContentUris.withAppendedId(Helper.videoUri,arr[position].id)).thumbnail(0.1f).into(holder.videoThumbnail)
        holder.videoTime.text = Helper.getDuration(arr[position].duration)

        holder.videoLayout.setOnClickListener{
            Helper.videoPosition = position
            Helper.videoFolder = arr
            val newIntent = Intent(context,ExoVideoPlayer::class.java)
            context.startActivity(newIntent)
        }
    }
}

