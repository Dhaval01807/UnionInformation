package com.example.filesmanager.Adapter

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filesmanager.Activity.ExoVideoPlayer
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.Model.VideoModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date

class VideoListAdapter(val context: Context, var arr:List<VideoModel>): RecyclerView.Adapter<VideoListAdapter.VideoListViewHolder>() {

    private final val TAG = "VideoListAdapter"
    class VideoListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val videoLayout = itemView.findViewById<LinearLayout>(R.id.ll_video_layout)
        val videoThumbnail = itemView.findViewById<ImageView>(R.id.iv_video_thumbnail)
        val videoName = itemView.findViewById<TextView>(R.id.tv_video_name)
        val videoTime = itemView.findViewById<TextView>(R.id.tv_video_time)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): VideoListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.video_list_layout,parent,false)
        return VideoListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: VideoListViewHolder, pos: Int) {
        holder.videoName.text = arr[holder.absoluteAdapterPosition].fileName
        Glide.with(context).load(ContentUris.withAppendedId(Helper.videoUri,arr[holder.absoluteAdapterPosition].id)).thumbnail(0.1f).into(holder.videoThumbnail)
        holder.videoTime.text = Helper.getDuration(arr[holder.absoluteAdapterPosition].duration)

        holder.videoLayout.setOnClickListener{
            Helper.videoPosition = holder.absoluteAdapterPosition
            Helper.videoFolder = arr
            val newIntent = Intent(context,ExoVideoPlayer::class.java)
            CoroutineScope(Dispatchers.IO).launch {
                RecentFileDB.getInstance(context).getRecentDao().insertRecent(
                    RecentFileEntity(
                        fileId = arr[holder.absoluteAdapterPosition].id,
                        fileName = arr[holder.absoluteAdapterPosition].fileName,
                        filePath = arr[holder.absoluteAdapterPosition].filePath,
                        openTime = Date().time,
                        fileType = arr[holder.absoluteAdapterPosition].fileType
                    )
                )
            }
            context.startActivity(newIntent)
        }
    }
}

