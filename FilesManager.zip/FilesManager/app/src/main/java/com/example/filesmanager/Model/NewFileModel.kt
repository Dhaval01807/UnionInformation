package com.example.filesmanager.Model

data class NewFileModel(val id:Long,val fileName:String,val filePath:String,val fileSize: Long,val fileType:String,val fileDate:String)
