package com.example.filesmanager.Adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

class StoreFilesAdapter(
    val context: Context,
    private var arr: MutableList<QuickFileModel>,
    val deleteFiles: MutableStateFlow<MutableList<QuickFileModel>>,
    val deleteSize:MutableStateFlow<Long>
) :
    RecyclerView.Adapter<StoreFilesAdapter.StoreFilesViewHolder>() {

    class StoreFilesViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val fileIcon = view.findViewById<ImageView>(R.id.iv_quickFile_icon)
        val fileName = view.findViewById<TextView>(R.id.tv_quickFile_name)
        val fileSize = view.findViewById<TextView>(R.id.tv_quickFile_size)
        val fileLayout = view.findViewById<LinearLayout>(R.id.ll_quick_clean)
        val fileDelete = view.findViewById<CheckBox>(R.id.cb_quickFile_delete)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoreFilesViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.quick_clean_file_layout, parent, false)
        return StoreFilesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: StoreFilesViewHolder, position: Int) {

        holder.fileDelete.isChecked = arr[holder.absoluteAdapterPosition].iSelected
        holder.fileDelete.setOnCheckedChangeListener { buttonView, isChecked ->
            if (isChecked) {
                if (!deleteFiles.value.contains(arr[holder.absoluteAdapterPosition])) {
                    deleteFiles.value.add(arr[holder.absoluteAdapterPosition])
                    Log.e("TAG", "onBindViewHolder: ${arr[holder.absoluteAdapterPosition].fileSize}", )
                    deleteSize.update {
                        it+arr[holder.absoluteAdapterPosition].fileSize
                    }
                }
                arr[holder.absoluteAdapterPosition].iSelected = true
            } else {
                if (deleteFiles.value.contains(arr[holder.absoluteAdapterPosition])) {
                    deleteSize.update {
                        it-arr[holder.absoluteAdapterPosition].fileSize
                    }
                    deleteFiles.value.remove(arr[holder.absoluteAdapterPosition])
                }
                arr[holder.absoluteAdapterPosition].iSelected = false
            }
        }

        Helper.populateIcon(
            context,
            Helper.fromMimeType(arr[holder.absoluteAdapterPosition].fileType),
            arr[holder.absoluteAdapterPosition].filePath,
            arr[holder.absoluteAdapterPosition].id,
            holder.fileIcon
        )

        holder.fileName.text = arr[holder.absoluteAdapterPosition].fileName
        holder.fileSize.text = Helper.formatSize(arr[holder.absoluteAdapterPosition].fileSize)
    }

    fun update(newData:List<QuickFileModel>){
        arr = newData.toMutableList()
        notifyDataSetChanged()
    }
}