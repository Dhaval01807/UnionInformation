package com.example.filesmanager.Activity

import android.app.Dialog
import android.content.ContentUris
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.bumptech.glide.Glide
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityImageIntentScreenBinding
import com.yalantis.ucrop.UCrop
import java.io.File

class ImageIntentScreen : AppCompatActivity() {
    private lateinit var binding: ActivityImageIntentScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityImageIntentScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val data = intent.data
        Glide.with(this).load(data).placeholder(R.drawable.ic_images).into(binding.imageview)

        var rotate: Float = 0f
        binding.llRotate.setOnClickListener {
            rotate += 90f
            if (rotate == 360f) {
                rotate = 0f
            }
            binding.imageview.rotation = rotate

        }

        binding.llDelete.setOnClickListener {
            val dialog = Dialog(this, R.style.FullWidthDialog)
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

            val layoutParams = WindowManager.LayoutParams()
            layoutParams.copyFrom(dialog.window!!.attributes)
            layoutParams.width = WindowManager.LayoutParams.MATCH_PARENT
            layoutParams.height = WindowManager.LayoutParams.WRAP_CONTENT

            dialog.window!!.attributes = layoutParams
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            dialog.setCancelable(true)

            val view = layoutInflater.inflate(R.layout.confirm_delete_dialog, null)
            dialog.setContentView(view)

            dialog.show()
        }

        binding.llShare.setOnClickListener {
            val shareIntent = Intent(Intent.ACTION_SEND)
            shareIntent.type = "image/jpeg"
            shareIntent.putExtra(
                Intent.EXTRA_STREAM,
                ContentUris.withAppendedId(Helper.imageUri, Helper.imageFolder[Helper.imagePosition].id)
            )
            startActivity(shareIntent)
        }

        binding.llCrop.setOnClickListener {
            var download = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            val crop = UCrop.of(
                ContentUris.withAppendedId(
                    Helper.imageUri,
                    Helper.imageFolder[Helper.imagePosition].id
                ), Uri.fromFile(File(cacheDir.path + "/temp.jpg"))
            )
                .withMaxResultSize(120, 120)

            val cropIntent = crop.getIntent(this)

            cropIntentResult.launch(cropIntent)
        }
    }


    val cropIntentResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        Log.e("TAG", "Something Hit: ${result.resultCode}")
        val temp = File(cacheDir.path + "/temp.jpg")
        if (result.resultCode == RESULT_OK) {
            val resultUri: Uri = UCrop.getOutput(result.data!!)!!
            if(temp.exists()){
                temp.delete()
            }
        } else{
            if(temp.exists()){
                temp.delete()
            }
        }
    }
}