package com.example.filesmanager.Utils

import android.content.Context
import android.util.Log
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.ftp.FTPReply
import org.apache.ftpserver.FtpServer
import org.apache.ftpserver.FtpServerFactory
import org.apache.ftpserver.ftplet.UserManager
import org.apache.ftpserver.listener.ListenerFactory
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory
import org.apache.ftpserver.usermanager.impl.BaseUser
import org.apache.ftpserver.usermanager.impl.WritePermission

import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException


class FtpServer {

    lateinit var ftpServer: FtpServer
     private var ftpClient: FTPClient? = null
    private final val TAG = "FtpServerClass"

    @Throws(IOException::class)
    fun startServer(username: String, password: String, port: Int,context: Context, location: String = "") {
        try {
            val serverFactory: FtpServerFactory = FtpServerFactory()
            val listenerFactory: ListenerFactory = ListenerFactory()
            listenerFactory.setPort(port)
            serverFactory.addListener("default", listenerFactory.createListener())


            val userManagerFactory: PropertiesUserManagerFactory = PropertiesUserManagerFactory()
            val file = File(context.cacheDir, "ftpusers.properties")
            if(!file.exists()){
                val output = FileOutputStream(file)
                context.assets.open("ftpusers.properties").use {
                        input->
                    var read:Int=0
                    output.use {
                            it->
                        while(read!=-1){
                            read = input.read()
                            it.write(read)
                        }
                    }
                }
            }
            userManagerFactory.setFile(file)
            val userManager: UserManager = userManagerFactory.createUserManager()
            val user: BaseUser = BaseUser()
            user.name = username
            user.password = password
            user.homeDirectory = "/storage/emulated/0/Download/"
            user.authorities = listOf(WritePermission())
            userManager.save(user)
            serverFactory.setUserManager(userManager)

            ftpServer = serverFactory.createServer()

            ftpServer.start()
        } catch (e: Exception) {
            Log.e("TAG", "Error starting FTP server", e)
            throw IOException()
        }
    }

    fun stopServer() {
        Log.e(TAG, "stopServer: ", )
        ftpServer.stop()
    }

    fun ftpConnect(host: String, username: String, password: String, port: Int): Boolean {
        try {
            ftpClient = FTPClient()
            ftpClient!!.connect(host, port)

            if (FTPReply.isPositiveCompletion(ftpClient!!.replyCode)) {
                val status: Boolean = ftpClient!!.login(username, password)
                /*
               * Set File Transfer Mode
               * To avoid corruption issue you must specified a correct
               * transfer mode, such as ASCII_FILE_TYPE, BINARY_FILE_TYPE,
               * EBCDIC_FILE_TYPE .etc. Here, I use BINARY_FILE_TYPE for
               * transferring text, image, and compressed files.
            */
                ftpClient?.setFileType(FTP.BINARY_FILE_TYPE)
                ftpClient?.enterLocalPassiveMode()
                return status
            }
        } catch (e: Exception) {
            Log.d(TAG, "Error: could not connect to host " + host);
        }
        return false
    }

    fun ftpDownloadFile() {
        var downloadFile: FileOutputStream = FileOutputStream("something.txt")
        ftpClient?.retrieveFile("/", downloadFile)
    }

    fun ftpUploadFile(srcFilePath: String, desFileName: String, desDirectory: String, context: Context): Boolean {
        var status = false
        try {
            FileInputStream(srcFilePath).use {
                input->
                status = ftpClient?.storeFile(desFileName,input)!!
            }
            return status
        } catch (e: java.lang.Exception) {
            e.printStackTrace()
            Log.d(TAG, "upload failed: $e")
        }
        return status
    }

    fun ftpDisconnect(): Boolean {
        try {
            ftpClient?.logout()
            ftpClient?.disconnect()
            return true
        } catch (e: java.lang.Exception) {
            Log.d(TAG, "Error occurred while disconnecting from ftp server.")
        }
        return false
    }
}