package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.R


class OnBoardingAdapter(val context: Context) :
    RecyclerView.Adapter<OnBoardingAdapter.ViewHolder>() {
    val image: List<Int> =
        listOf(R.drawable.on_boarding_1, R.drawable.on_boarding_2, R.drawable.on_boarding_3)
    val heading: List<String> = listOf(
        "Manage your files in a simple way",
        "No more junk files",
        "Manage your personal data with complete security"
    )
    val subHeading: List<String> = listOf(
        "You could integrate your local files with the files in cloud storage",
        "Clean all the junk files/folders with Super fast Clean Master",
        "Tap on “Get Started” button to  continue further step"
    )


    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val image: ImageView = itemView.findViewById(R.id.tv_image)
        val heading: TextView = itemView.findViewById(R.id.tv_heading)
        val subHeading: TextView = itemView.findViewById(R.id.tv_subheading)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.on_boarding_layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return 3
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.image.setImageDrawable(AppCompatResources.getDrawable(context, image[holder.absoluteAdapterPosition]))
        holder.heading.text = heading[holder.absoluteAdapterPosition]
        holder.subHeading.text = subHeading[holder.absoluteAdapterPosition]
    }
}