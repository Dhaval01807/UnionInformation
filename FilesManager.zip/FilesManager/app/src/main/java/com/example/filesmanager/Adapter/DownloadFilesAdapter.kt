package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.Model.DownloadModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.Utils.Helper.FileTypes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date

class DownloadFilesAdapter(val context: Context, var arr: List<DownloadModel>) :
    RecyclerView.Adapter<DownloadFilesAdapter.DownloadFilesViewHolder>() {
    class DownloadFilesViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val downloadFiles = itemView.findViewById<LinearLayout>(R.id.ll_download_file)
        val fileName = itemView.findViewById<TextView>(R.id.tv_downloadFile_name)
        val fileSize = itemView.findViewById<TextView>(R.id.tv_downloadFile_size)
        val fileIcon = itemView.findViewById<ImageView>(R.id.iv_downloadFile_icon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): DownloadFilesViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.download_file_layout, parent, false)
        return DownloadFilesViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: DownloadFilesViewHolder, position: Int) {
        holder.fileName.text = arr[holder.absoluteAdapterPosition].fileName
        holder.fileSize.text = Helper.formatSize(arr[holder.absoluteAdapterPosition].fileSize)
        Helper.populateIcon(context,Helper.fromMimeType(arr[holder.absoluteAdapterPosition].fileType),arr[holder.absoluteAdapterPosition].filePath,arr[holder.absoluteAdapterPosition].id,holder.fileIcon)
        val extension: FileTypes? = Helper.fromMimeType(arr[holder.absoluteAdapterPosition].fileType)
        holder.downloadFiles.setOnClickListener {
            when (extension) {
                FileTypes.APK -> {
                    Helper.launchApkIntent(context, arr[holder.absoluteAdapterPosition].filePath)
                }

                FileTypes.AUDIO -> {
                    //Todo
                }

                FileTypes.VIDEO -> {
                    //Todo
                }

                FileTypes.PDF -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
                    )
                }

                FileTypes.TXT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt").toString()
                    )
                }

                FileTypes.WORD -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc").toString()
                    )
                }

                FileTypes.PPT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt").toString()
                    )
                }

                FileTypes.EXCEL -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls").toString()
                    )
                }

                FileTypes.IMAGE -> {
//                    Todo
                }

                FileTypes.WORDX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx").toString()
                    )
                }

                FileTypes.PPTX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx").toString()
                    )
                }

                FileTypes.EXCELX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx").toString()
                    )
                }

                else -> {
                    Toast.makeText(context,"File Not Supported",Toast.LENGTH_SHORT).show()
                }
            }
            CoroutineScope(Dispatchers.IO).launch {
                RecentFileDB.getInstance(context).getRecentDao().insertRecent(
                    RecentFileEntity(
                        fileId = arr[holder.absoluteAdapterPosition].id,
                        fileName = arr[holder.absoluteAdapterPosition].fileName,
                        filePath = arr[holder.absoluteAdapterPosition].filePath,
                        openTime = Date().time,
                        fileType = arr[holder.absoluteAdapterPosition].fileType
                    )
                )
            }
        }

    }

    fun update(newData: List<DownloadModel>){
        arr = newData
        notifyDataSetChanged()
    }


}