package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.Model.DocsModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.Utils.Helper.FileTypes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date


class DocScreenAdapter(val context: Context, var arr: List<DocsModel>) :
    RecyclerView.Adapter<DocScreenAdapter.DocScreenViewHolder>() {

    private final val TAG = "Doc Adapter";

    class DocScreenViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fileLayout = itemView.findViewById<LinearLayout>(R.id.ll_docs)
        val fileIcon = itemView.findViewById<ImageView>(R.id.iv_docs_icon)
        val fileName = itemView.findViewById<TextView>(R.id.tv_docs_name)
        val fileSize = itemView.findViewById<TextView>(R.id.tv_docs_size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): DocScreenViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.docs_layout, parent, false)
        return DocScreenViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: DocScreenViewHolder, position: Int) {
        holder.fileName.text = arr[position].fileName
        holder.fileSize.text = Helper.formatSize(arr[position].fileSize)
        val extension: FileTypes? = Helper.fromMimeType(arr[position].fileType)
        Helper.populateIcon(
            context,
            extension,
            arr[position].filePath,
            arr[position].id,
            holder.fileIcon
        )
        holder.fileLayout.setOnClickListener {
            when (extension) {
                FileTypes.APK -> {
                    Helper.launchApkIntent(context, arr[position].filePath)
                }

                FileTypes.AUDIO -> {
                    //Todo
                }

                FileTypes.VIDEO -> {
                    //Todo
                }

                FileTypes.PDF -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
                    )
                }

                FileTypes.TXT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt").toString()
                    )
                }

                FileTypes.WORD -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc").toString()
                    )
                }

                FileTypes.PPT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt").toString()
                    )
                }

                FileTypes.EXCEL -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls").toString()
                    )
                }

                FileTypes.IMAGE -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
                    )
                }

                FileTypes.WORDX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx").toString()
                    )
                }

                FileTypes.PPTX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx").toString()
                    )
                }

                FileTypes.EXCELX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[position].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx").toString()
                    )
                }

                else -> {
                    //Todo
//                    Helper.launchDocSupportedIntent(
//                        context, arr[position].filePath,
//                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
//                    )
                }
            }
            CoroutineScope(Dispatchers.IO).launch {
                RecentFileDB.getInstance(context).getRecentDao()
                    .insertRecent(
                        RecentFileEntity(
                            fileId = arr[position].id,
                            fileName = arr[position].fileName,
                            filePath = arr[position].filePath,
                            fileType = arr[position].fileType,
                            openTime = Date().time
                        )
                    )
            }
        }
    }

    fun update(newData: List<DocsModel>) {
        arr = newData
        notifyDataSetChanged()
    }
}