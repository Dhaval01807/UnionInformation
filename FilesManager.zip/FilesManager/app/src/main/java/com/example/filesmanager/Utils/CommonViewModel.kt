package com.example.filesmanager.Utils

import com.example.filesmanager.ViewModel.QuickScanViewModel
import com.example.filesmanager.ViewModel.StorageViewModel

class CommonViewModel {

    companion object{
        lateinit var viewModel: StorageViewModel
        lateinit var cleanViewModel: QuickScanViewModel
    }
}