package com.example.filesmanager

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager

class MyApp : Application() {

    override fun onCreate() {
        val notificationChannel =
            NotificationChannel("12", "Music Notification", NotificationManager.IMPORTANCE_HIGH)
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(notificationChannel)
        super.onCreate()
    }
}