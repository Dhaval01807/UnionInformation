package com.example.filesmanager.Activity

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.Utils.CommonViewModel.Companion.cleanViewModel
import com.example.filesmanager.Utils.CommonViewModel.Companion.viewModel
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityStoreAnalysisBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class StoreAnalysis : AppCompatActivity() {
    private lateinit var binding: ActivityStoreAnalysisBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoreAnalysisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = CommonViewModel.viewModel
        val cleanViewModel = CommonViewModel.cleanViewModel

        binding.appbar.appTitle.text = "Store Analysis"
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }
        binding.tvStoreSpace.text = "${Helper.formatSize(Helper.iAvailableSpace)} Free"



        binding.pbStoreStorageProgress.max = ((((Helper.iTotalSpace) / 1024) / 1024) / 1024).toInt()
        binding.pbStoreStorageProgress.progress =
            (((Helper.iUsedSpace / 1024) / 1024) / 1024).toInt()
        binding.tvStoreStoragePercentage.text = "${
            String.format(
                " % .2f",
                (binding.pbStoreStorageProgress.progress.toDouble() / binding.pbStoreStorageProgress.max.toDouble()) * 100
            )
        }%"

        if (!viewModel.imageSearched) {
            CoroutineScope(Dispatchers.IO).launch {
                viewModel.getAllImage(contentResolver)
            }
        }

        viewModel.allImages.observe(this) {
            binding.tvStoreImageSize.text = Helper.formatSize(viewModel.allImagesSize)
        }

        if (!viewModel.videoSearched) {
            CoroutineScope(Dispatchers.IO).launch {
                viewModel.getAllVideo(contentResolver)
            }
        }


        viewModel.allVideos.observe(this) {
            binding.tvStoreVideoSize.text = Helper.formatSize(viewModel.allVideosSize)
        }

        if (!viewModel.docsSearched) {
            CoroutineScope(Dispatchers.IO).launch {
                viewModel.getAllDocs(contentResolver)
            }
        }

        viewModel.allDocs.observe(this) {
            binding.tvStoreDocumentSize.text = Helper.formatSize(viewModel.allDocsSize)
        }

        if (!viewModel.musicSearched) {
            CoroutineScope(Dispatchers.IO).launch {
                viewModel.getAllMusic(contentResolver)
            }
        }

        viewModel.allDocs.observe(this) {
            binding.tvStoreAudioSize.text = Helper.formatSize(viewModel.musicsSize)
        }


        val service = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = service.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(), packageName
        )

        var permission = false
        if (mode == AppOpsManager.MODE_DEFAULT) {
            permission =
                (checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) === PackageManager.PERMISSION_GRANTED)
        } else {
            permission = (mode == AppOpsManager.MODE_ALLOWED)
        }
        checkPermissionAndPopulate(permission)
        binding.btnAppStorePermission.setOnClickListener {
            val permissionIntent = Intent()
            permissionIntent.setAction(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            appStaticPermission.launch(permissionIntent)
        }
        if (!CommonViewModel.cleanViewModel.quickScanDone) {
            CoroutineScope(Dispatchers.IO).launch {
                CommonViewModel.cleanViewModel.quickScan(contentResolver)
            }
        }

        populateLargeFile()
        populateDuplicateFile()

    }

    private fun populateLargeFile() {
        Log.e("TAG", "populateLargeFile: ")


        cleanViewModel.largeFile.observe(this) {
            if (cleanViewModel.largeFileSearched) {
                binding.pbLargeFile.visibility = GONE
                binding.tvLargeFileViewMore.visibility = VISIBLE
                binding.tvStoreLargeFileSize.text =
                    Helper.formatSize(cleanViewModel.largeFileSize)


                val newData = it.sortedBy { cleanViewModel.largeFile.value!![0].fileSize }
                Log.e("TAG", "populateLargeFile: ${newData.size}")
                if (newData.size >= 2) {
                    binding.llLargeFile1.visibility = VISIBLE
                    binding.llLargeFile2.visibility = VISIBLE


                    Helper.populateIcon(
                        this,
                        Helper.fromMimeType(newData[0].fileType),
                        newData[0].filePath,
                        newData[0].id,
                        binding.ivStoreLargeFile1Icon
                    )
                    Helper.populateIcon(
                        this,
                        Helper.fromMimeType(newData[1].fileType),
                        newData[1].filePath,
                        newData[1].id,
                        binding.ivStoreLargeFile2Icon
                    )

                    binding.tvStoreLargeFile1Name.text = newData[0].fileName
                    binding.tvStoreLargeFile2Name.text = newData[1].fileName

                    binding.tvStoreLargeFile1Size.text = Helper.formatSize(newData[0].fileSize)
                    binding.tvStoreLargeFile2Size.text = Helper.formatSize(newData[1].fileSize)
                } else if (newData.isNotEmpty()) {
                    binding.llLargeFile1.visibility = VISIBLE

                    Helper.populateIcon(
                        this,
                        Helper.fromMimeType(newData[0].fileType),
                        newData[0].filePath,
                        newData[0].id,
                        binding.ivStoreLargeFile1Icon
                    )


                    binding.tvStoreLargeFile1Name.text = newData[0].fileName

                    binding.tvStoreLargeFile1Size.text = Helper.formatSize(newData[0].fileSize)
                }
            }
        }
        binding.pbLargeFile.visibility = GONE

        binding.tvLargeFileViewMore.setOnClickListener {
            if(!cleanViewModel.largeFileSearched){
                Toast.makeText(this,"Please Til Scan Complete",Toast.LENGTH_SHORT).show()
            }else{
                val newIntent = Intent(this, StoreFileScreen::class.java)
                startActivity(newIntent)
            }
        }
    }

    private fun populateDuplicateFile() {

        cleanViewModel.duplicateFile.observe(this) {
            if(cleanViewModel.duplicateFileSearched){
                binding.pbDuplicateFile.visibility = GONE
                binding.llDuplicate.visibility = VISIBLE
                binding.tvDuplicateViewMore.visibility = VISIBLE
                binding.tvStoreDuplicateSize.text =
                    Helper.formatSize(cleanViewModel.duplicateFileSize)
                val keys = it.keys
                val values = it.values
                if (keys.size >= 2) {
                    Helper.populateIcon(
                        this,
                        Helper.fromMimeType(it[keys.elementAt(0)]!!.first().fileType),
                        it[keys.elementAt(0)]!!.first().filePath,
                        it[keys.elementAt(0)]!!.first().id,
                        binding.ivStoreDuplicate1Icon
                    )
                    Helper.populateIcon(
                        this,
                        Helper.fromMimeType(it[keys.elementAt(1)]!!.first().fileType),
                        it[keys.elementAt(1)]!!.first().filePath,
                        it[keys.elementAt(1)]!!.first().id,
                        binding.ivStoreDuplicate2Icon
                    )


                    binding.tvStoreDuplicate1Name.text =
                        it[keys.elementAt(0)]!!.first().fileName
                    binding.tvStoreDuplicate2Name.text =
                        it[keys.elementAt(1)]!!.first().fileName

                    binding.tvStoreDuplicate1Size.text =
                        Helper.formatSize(it[keys.elementAt(0)]!!.first().fileSize)
                    binding.tvStoreDuplicate2Size.text =
                        Helper.formatSize(it[keys.elementAt(1)]!!.first().fileSize)
                } else if (keys.isNotEmpty()) {
                    binding.llLargeFile1.visibility = VISIBLE

                    Helper.populateIcon(
                        this,
                        Helper.fromMimeType(it[keys.elementAt(0)]!!.first().fileType),
                        it[keys.elementAt(0)]!!.first().filePath,
                        it[keys.elementAt(0)]!!.first().id,
                        binding.ivStoreDuplicate1Icon
                    )

                    binding.tvStoreLargeFile1Name.text =
                        it[keys.elementAt(0)]!!.first().fileName

                    binding.tvStoreLargeFile1Size.text =
                        Helper.formatSize(it[keys.elementAt(0)]!!.first().fileSize)

                }
            }
        }



        binding.tvDuplicateViewMore.setOnClickListener {
            if(!cleanViewModel.duplicateFileSearched){
                Toast.makeText(this,"Please Wait Til Scan Complete",Toast.LENGTH_SHORT).show()
            }else{
                AppConstant.duplicateFileList = cleanViewModel.duplicateFile.value ?: mapOf()
                val newIntent = Intent(this, DuplicateFileScreen::class.java)
                startActivity(newIntent)
            }
        }

    }


    private fun checkPermissionAndPopulate(permission: Boolean) {
        if (permission) {
            binding.pbApp.visibility = VISIBLE
            binding.llAppPermission.visibility = GONE
            if (!viewModel.appInformationSearched) {
                CoroutineScope(Dispatchers.IO).launch {
                    viewModel.getAllAppInfo(baseContext)
                }
            }

            viewModel.allAppInformation.observe(this) {
                if(viewModel.appInformationSearched){
                    binding.pbApp.visibility = GONE
                    binding.tvAppViewMore.visibility = VISIBLE
                    populateAppView()
                }
            }
        } else {
            binding.llAppPermission.visibility = VISIBLE
            binding.llAppInformation.visibility = GONE
            binding.pbApp.visibility = GONE
            binding.tvAppViewMore.visibility= GONE
        }
    }

    private fun populateAppView() {

        binding.tvStoreTotalAppSize.text = Helper.formatSize(viewModel.appTotalSize)
        viewModel.allAppInformation.value?.let {
            if (it.size >= 2) {
                Glide.with(this)
                    .load(packageManager.getApplicationIcon(it[0].packageName))
                    .into(binding.ivStoreApp1Icon)
                Glide.with(this)
                    .load(packageManager.getApplicationIcon(it[1].packageName))
                    .into(binding.ivStoreApp2Icon)

                binding.tvStoreApp1Name.text = it[0].appName
                binding.tvStoreApp2Name.text = it[1].appName

                binding.tvStoreApp1Size.text = Helper.formatSize(it[0].occupiedSize)
                binding.tvStoreApp2Size.text = Helper.formatSize(it[1].occupiedSize)
            } else if (it.isNotEmpty()) {
                Glide.with(this)
                    .load(packageManager.getApplicationIcon(it[0].packageName))
                    .into(binding.ivStoreApp1Icon)

                binding.tvStoreApp1Name.text = it[0].appName

                binding.tvStoreApp1Size.text = Helper.formatSize(it[0].occupiedSize)
            } else {
                binding.btnAppStorePermission.visibility = GONE
                binding.tvStoreAppStatus.text = "No App Information"
            }
        }
        if (viewModel.allAppInformation.value?.size != 0) {
            binding.llAppInformation.visibility = VISIBLE
            binding.pbApp.visibility = GONE
        }
    }


    private val appStaticPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

            Log.e("TAG", "$result: ")
            Log.e("TAG", "${result.resultCode}: ")
            val service = getSystemService(APP_OPS_SERVICE) as AppOpsManager
            val mode = service.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(), packageName
            )

            var permission = false
            if (mode == AppOpsManager.MODE_DEFAULT) {
                permission =
                    (checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) === PackageManager.PERMISSION_GRANTED)
            } else {
                permission = (mode == AppOpsManager.MODE_ALLOWED)
            }

            Log.e("TAG", "Result: $permission", )
            checkPermissionAndPopulate(permission)
        }
}