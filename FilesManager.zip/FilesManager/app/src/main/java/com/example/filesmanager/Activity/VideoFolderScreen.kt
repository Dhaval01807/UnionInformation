package com.example.filesmanager.Activity

import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.VideoFolderAdapter
import com.example.filesmanager.R
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.databinding.ActivityVideoFolderScreenBinding

class VideoFolderScreen : AppCompatActivity() {

    private lateinit var binding: ActivityVideoFolderScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityVideoFolderScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        binding.appbar.appTitle.text = "Video Folder"
        val viewModel = CommonViewModel.viewModel
        if (!viewModel.videoSearched) {
            viewModel.getAllVideo(contentResolver)

        }


        val folderAdapter = VideoFolderAdapter(this, viewModel.allVideos.value!!)
        viewModel.allVideos.observe(this) { it ->
            if (it != null) {
                if (it.isEmpty()) {
                    if (viewModel.videoSearched) {
                        binding.pbVideoFolder.visibility = GONE
                        binding.tvVideoFolderStatus.visibility = VISIBLE
                        binding.tvVideoFolderStatus.text = "No Video Found"
                        binding.rvVideoFolder.visibility = GONE
                    }
                } else {
                    binding.pbVideoFolder.visibility = GONE
                    binding.rvVideoFolder.visibility = VISIBLE
                    binding.tvVideoFolderStatus.visibility = GONE
                    folderAdapter.update(it)
                }
            } else {
                if (viewModel.videoSearched) {
                    binding.pbVideoFolder.visibility = GONE
                    binding.tvVideoFolderStatus.visibility = VISIBLE
                    binding.tvVideoFolderStatus.text = getString(R.string.noImage)
                    binding.rvVideoFolder.visibility = GONE
                }
            }
        }

        binding.rvVideoFolder.adapter = folderAdapter
        binding.rvVideoFolder.layoutManager = LinearLayoutManager(this)
    }
}