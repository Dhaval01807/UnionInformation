package com.example.filesmanager.Model

data class DownloadModel(val id:Long,val fileName:String,val fileType:String,val fileSize:Long,val filePath:String)
