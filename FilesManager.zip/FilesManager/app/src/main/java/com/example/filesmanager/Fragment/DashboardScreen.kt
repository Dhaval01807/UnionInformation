package com.example.filesmanager.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.filesmanager.Adapter.DashboardCategoryAdapter
import com.example.filesmanager.Model.DashboardCategoryModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.FragmentDashboardScreenBinding


class DashboardScreen : Fragment() {

    private lateinit var binding: FragmentDashboardScreenBinding
    private final val TAG = "DashBoardScreen"
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

//        Log.e(TAG, "onCreateView: ${}")
        binding = FragmentDashboardScreenBinding.inflate(inflater, container, false)

        binding.tvStorageFree.text = Helper.formatSize(Helper.iAvailableSpace)
        binding.tvStorageUsed.text = Helper.formatSize(Helper.iUsedSpace)

        binding.pbStorageProgress.max = ((((Helper.iTotalSpace)/1024)/1024)/1024).toInt()
        binding.pbStorageProgress.progress = (((Helper.iUsedSpace/1024)/1024)/1024).toInt()



        binding.tvStoragePercentage.text = "${String.format("%.2f", (binding.pbStorageProgress.progress.toDouble()/binding.pbStorageProgress.max.toDouble())*100)}%"

        val dashBoardData = arrayListOf<DashboardCategoryModel>(
            DashboardCategoryModel(R.drawable.ic_docs, "Docs", "#0F00DD16"),
            DashboardCategoryModel(R.drawable.ic_images, "Images", "#0F0073DD"),
            DashboardCategoryModel(R.drawable.ic_videos, "Videos", "#0FDD0092"),
            DashboardCategoryModel(R.drawable.ic_download, "Download", "#0F5E3ED2"),
            DashboardCategoryModel(R.drawable.ic_new_files, "New Files", "#0FBD2AEE"),
            DashboardCategoryModel(R.drawable.ic_store_analysis, "Store analysis", "#0F2347C9"),
            DashboardCategoryModel(R.drawable.ic_audio, "Audios", "#0FDD8400"),
            DashboardCategoryModel(R.drawable.ic_apps, "Apps", "#0FEB5523"),
            DashboardCategoryModel(R.drawable.ic_remote, "Remote", "#0FD52B2B"),
            DashboardCategoryModel(R.drawable.ic_remote, "Access From...", "#0F81BA1A"),

        )




        binding.gridDashBoard.adapter = DashboardCategoryAdapter(requireContext(), requireActivity(),dashBoardData)



        binding.ivSetting.setOnClickListener {
            //Todo
//            val newIntent = Intent(context, SettingScreen::class.java)
//            startActivity(newIntent)
        }

        return binding.root;
    }
}