package com.example.filesmanager.ViewModel

import android.content.ContentResolver
import android.provider.MediaStore
import android.util.Log
import com.example.filesmanager.Model.ImageModel
import com.example.filesmanager.Utils.Helper

class ImageRepo {
    fun getAllImage(contentResolver: ContentResolver): Map<String,List<ImageModel>>{
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.MIME_TYPE
        )
        val uri = Helper.imageUri

        val pointer = contentResolver.query(uri,projection,null,null,null)
        val temp:MutableMap<String,MutableList<ImageModel>> = hashMapOf()
        if(pointer!=null){
            while(pointer.moveToNext()){
                val id = pointer.getLong(0)
                val fileName = pointer.getString(1);
                val filePath = pointer.getString(2);
                val fileSize = pointer.getLong(3)
                val fileType = pointer.getString(4)
                if(!temp.containsKey(filePath)){
                    temp[filePath] = mutableListOf<ImageModel>()
                }

                Log.e("TAG", "getAllImage: $fileType  ${Helper.fromMimeType(fileType)}", )
                temp[filePath]!!.add(ImageModel(id,fileName,filePath,fileSize,fileType))
            }
        }
        return temp
    }
}