package com.example.filesmanager.Activity

import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.MutableLiveData
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.ConsumeResponseListener
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.SkuDetailsParams
import com.android.billingclient.api.SkuDetailsResponseListener
import com.example.filesmanager.R
import com.example.filesmanager.Utils.AdLoader
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.BillingClientSetup
import com.example.filesmanager.Utils.RemoteValue
import com.example.filesmanager.Utils.StringConstant
import com.example.filesmanager.databinding.ActivityProScreenBinding
import java.util.Arrays

class ProScreen : AppCompatActivity(),PurchasesUpdatedListener {
    lateinit var billingClient: BillingClient
    val SKU_Lifetime_AddBucket_120: String = "file_manager_pro_monthly"
    val SKU_Lifetime_AddBucket_240: String = "file_manager_pro_yearly"
    private var purchaseItem: Purchase? = null
    var price: MutableLiveData<Double> = MutableLiveData(0.0)
    var yearly: MutableLiveData<Double> = MutableLiveData(0.0)

    private lateinit var binding: ActivityProScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityProScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val intent = intent
        var fromPro: Boolean = false
        setupBillingClient()
        intent?.let {
            fromPro = it.getBooleanExtra("fromPro", true)
        }


        val sharePref = applicationContext.getSharedPreferences(
            StringConstant.packageName,
            MODE_PRIVATE
        )


        var localPrice = sharePref.getInt("price", 0)

        price.value = localPrice.toDouble()
        price.observe(this) {
            binding.monthlyPlanPrice.text = "${it.toString()}/Monthly"
        }

        yearly.observe(this){
            binding.yearlyPlanPrice.text = "${it.toString()}/Yearly"
        }


        Log.e("TAG", "onCreate From Pro: $fromPro", )
        if (fromPro) {
            binding.ivClose.visibility = View.VISIBLE
            binding.btnWithAd.visibility = View.GONE
        } else {
            if (RemoteValue.rewardAdId.isNotEmpty()) {
                AdLoader.loadRewardedAd(RemoteValue.rewardAdId, this)
                AdLoader.rewardAdLoaded.observe(this) {

                    if (AdLoader.rewardFailed) {
                        val newIntent = Intent(this, HomeScreen::class.java)
                        startActivity(newIntent)
                        finish()
                    }
                    if (binding.progressbar.visibility == View.VISIBLE) {
                        AdLoader.showRewardedAd(this)
                    }
                }
            }
        }


        binding.btnBuyPro.setOnClickListener {
            purchaseItem(SKU_Lifetime_AddBucket_120)
        }




        binding.ivClose.setOnClickListener {
            finish()
        }

        binding.btnWithAd.setOnClickListener {
            if (RemoteValue.rewardAdId.isEmpty()) {
                val newIntent = Intent(this, HomeScreen::class.java)
                startActivity(newIntent)
                finish()
            } else {
                if (AdLoader.rewardFailed) {
                    val newIntent = Intent(this, HomeScreen::class.java)
                    startActivity(newIntent)
                    finish()
                } else {
                    if (AdLoader.rewardAdLoaded.value!!) {
                        AdLoader.showRewardedAd(this)
                    } else {
                        binding.progressbar.visibility = View.VISIBLE
                    }
                }
            }

        }

        val termSpanning: SpannableString = SpannableString(binding.term.text)
        val privacy = SpannableString(binding.privacy.text)
        termSpanning.setSpan(
            ForegroundColorSpan(getColor(R.color.colorBlue)),
            0,
            binding.term.text.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE

        )
        termSpanning.setSpan(
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.setData(Uri.parse(RemoteValue.privacyLink))
                    startActivity(intent)
                }

            },
            0,
            binding.term.text.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        privacy.setSpan(
            ForegroundColorSpan(getColor(R.color.colorBlue)),
            0,
            binding.privacy.text.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        privacy.setSpan(
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.setData(Uri.parse(RemoteValue.privacyLink))
                    startActivity(intent)
                }

            },
            0,
            binding.privacy.text.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )

        binding.term.isClickable = true
        binding.term.movementMethod = LinkMovementMethod.getInstance()
        binding.term.text = termSpanning

        binding.privacy.isClickable = true
        binding.privacy.movementMethod = LinkMovementMethod.getInstance()
        binding.privacy.text = termSpanning

    }

    private fun setupBillingClient() {
        val instance: BillingClient = BillingClientSetup.getInstance(this@ProScreen, this@ProScreen)
        this.billingClient = instance

        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingServiceDisconnected() {
            }

            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryProductDetails()
                }
            }
        })
        instance.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(billingResult: BillingResult) {
                if (billingResult.responseCode == 0) {
                    return
                }
            }

            override fun onBillingServiceDisconnected() {
            }
        })
    }

    fun purchaseItem(item: String) {
        if (billingClient.isReady) {
            billingClient.querySkuDetailsAsync(
                SkuDetailsParams.newBuilder()
                .setSkusList(Arrays.asList<String>(*arrayOf<String>(item)))
                .setType(BillingClient.SkuType.INAPP).build(),
                SkuDetailsResponseListener { billingResult, list ->
                    if (billingResult.responseCode == 0 && list!!.size > 0) {
                        billingClient.launchBillingFlow(
                            this@ProScreen, BillingFlowParams.newBuilder().setSkuDetails(
                                list!![0]
                            ).build()
                        ).responseCode
                        return@SkuDetailsResponseListener
                    }
                })
        } else {
        }
    }

    private fun queryProductDetails() {
        val skuList: MutableList<String> = ArrayList()
        skuList.add(SKU_Lifetime_AddBucket_120)
        val params = SkuDetailsParams.newBuilder()
        params.setSkusList(skuList).setType(BillingClient.SkuType.INAPP)

        billingClient.querySkuDetailsAsync(
            params.build()
        ) { billingResult, skuDetailsList ->
            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && skuDetailsList != null) {
                for (skuDetails in skuDetailsList) {
                    val sku = skuDetails.sku
                    val prices = skuDetails.price
                    price.value = prices.toDouble()
                }
            }
        }
    }

    override fun onPurchasesUpdated(billingResult: BillingResult, list: MutableList<Purchase>?) {
        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && list != null) {
            handleItemAlreadyPurchase(list)

            for (purchase in list) {
                if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
                    successDialog()
                    val sharePref = applicationContext.getSharedPreferences(
                        StringConstant.packageName,
                        MODE_PRIVATE
                    )
                    sharePref.edit().putBoolean("PURCHASE", true).apply()


                } else if (purchase.purchaseState == Purchase.PurchaseState.PENDING) {
                } else if (purchase.purchaseState == Purchase.PurchaseState.UNSPECIFIED_STATE) {
                }
            }
        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
            Toast.makeText(this, "Please Restart the app", Toast.LENGTH_SHORT).show()
        } else {
        }
    }

    private fun successDialog() {
        val dialog = Dialog(this, R.style.s_permission)
        dialog.setContentView(R.layout.my_purchase_dialog)
        dialog.setCancelable(false)
        val buttonYes = dialog.findViewById<TextView>(R.id.buttonOk)
        buttonYes.setOnClickListener {
            dialog.dismiss()
            val i: Intent = Intent(this@ProScreen, HomeScreen::class.java)
            startActivity(i)
            finish()
        }
        if (!isFinishing) {
            dialog.show()
        }
    }

    fun handleItemAlreadyPurchase(list: List<Purchase>) {
        purchaseItem = null
        val next = list[0]
        this.billingClient.consumeAsync(
            ConsumeParams.newBuilder()
                .setPurchaseToken(next.purchaseToken).build(),
            ConsumeResponseListener { billingResult, s ->
                if (next.purchaseToken.equals(SKU_Lifetime_AddBucket_120, ignoreCase = true)) {
                    val sharePref = applicationContext.getSharedPreferences(
                        StringConstant.packageName,
                        MODE_PRIVATE
                    )
                    sharePref.edit().putBoolean("PURCHASE", true).apply()
                }
            })
    }
}