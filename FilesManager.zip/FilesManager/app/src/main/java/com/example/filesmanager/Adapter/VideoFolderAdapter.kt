package com.example.filesmanager.Adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.Activity.VideoListScreen
import com.example.filesmanager.Model.VideoModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper

class VideoFolderAdapter(val context: Context, var arr: Map<String, List<VideoModel>>) :
    RecyclerView.Adapter<VideoFolderAdapter.VideoFolderViewHolder>() {

    private final val TAG = "VideoFolderAdapter";
    var folderName :List<String> = listOf()
    class VideoFolderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val folderLayout = itemView.findViewById<LinearLayout>(R.id.ll_video_folder)
        val folderIcon = itemView.findViewById<ImageView>(R.id.iv_videoFolder_icon)
        val folderName = itemView.findViewById<TextView>(R.id.tv_videoFolder_name)
        val numberOfVideos = itemView.findViewById<TextView>(R.id.tv_videoFolder_video_number)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): VideoFolderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.video_folder_layout, parent, false)
        return VideoFolderViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: VideoFolderViewHolder, pos: Int) {
        holder.folderName.text = folderName[holder.absoluteAdapterPosition]
        holder.numberOfVideos.text = "${arr[folderName[holder.absoluteAdapterPosition]]!!.size} Videos"
        holder.folderLayout.setOnClickListener {
            Helper.videoFolder = arr[folderName[holder.absoluteAdapterPosition]] ?: listOf()
            val newIntent = Intent(context,VideoListScreen::class.java)
            newIntent.putExtra("FolderName",folderName[holder.absoluteAdapterPosition])
            context.startActivity(newIntent)
        }
//
//        Glide.with(context).load(arr[folderName[holder.]]?.get(0)?.let {
//            ContentUris.withAppendedId(
//                Helper.videoUri,
//                it.id
//            )
//        }).placeholder(R.mipmap.ic_launcher).thumbnail(0.1f).into(holder.folderThumbnail)
    }

    fun update(newData: Map<String, List<VideoModel>>) {
        folderName = newData.keys.toList()
        arr = newData
        notifyDataSetChanged()
    }

}