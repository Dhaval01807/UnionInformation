package com.example.filesmanager.ViewModel

import android.content.ContentResolver
import android.provider.MediaStore
import android.util.Log
import androidx.lifecycle.ViewModel
import com.example.filesmanager.Model.VideoModel
import com.example.filesmanager.Utils.Helper

class VideoRepo: ViewModel() {

    var TAG = "VideoViewModel"

    fun getAllVideo(contentResolver: ContentResolver):Map<String,List<VideoModel>>{
        Log.e(TAG, "getAllVideo: ", )
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE
        )
        val uri = Helper.videoUri

        val pointer = contentResolver.query(uri,projection,null,null,null)
        val temp:MutableMap<String,MutableList<VideoModel>> = hashMapOf()
        Log.e(TAG, "getAllVideo: ${pointer!!.count}", )
        if(pointer!=null){
            while(pointer.moveToNext()){
                val id = pointer.getLong(0)
                val fileName = pointer.getString(1)
                val filePath = pointer.getString(2)
                val fileSize = pointer.getLong(4)
                val duration = pointer.getLong(5)
                val width = pointer.getLong(6)
                val height = pointer.getLong(7)
                val fileType = pointer.getString(8)
                if(!temp.containsKey(filePath?: "Root")){
                    temp[filePath?: "Root"] = mutableListOf<VideoModel>()
                }
                temp[filePath?: "Root"]!!.add(VideoModel(id,fileName,filePath?: "Root",duration,fileSize,width,height,fileType))
            }
        }

        Log.e(TAG, "getAllVideo: ${temp.size}", )
        return temp
    }
}