package com.example.filesmanager.Activity

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.filesmanager.R
import com.example.filesmanager.databinding.ActivitySettingScreenBinding

class SettingScreen : AppCompatActivity() {
    private lateinit var binding: ActivitySettingScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivitySettingScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.appTitle.text = "Setting Screen"
        binding.appbar.backBtn.setOnClickListener {
            finish()
        }
        binding.btnProScreen.setOnClickListener {
            val newIntent = Intent(this,ProScreen::class.java)
            newIntent.putExtra("fromPro",true)
            startActivity(newIntent)
        }
    }
}