package com.example.filesmanager.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.StoreFilesAdapter
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.databinding.ActivityStoreFileScreenBinding

class StoreFileScreen : AppCompatActivity() {
    private lateinit var binding: ActivityStoreFileScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoreFileScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val adapter = StoreFilesAdapter(this,AppConstant.storeFileList)
        binding.rvStoreFile.adapter = adapter
        binding.rvStoreFile.layoutManager = LinearLayoutManager(this)
    }
}