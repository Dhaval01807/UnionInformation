package com.example.filesmanager.Activity

import android.os.Bundle
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.StoreFilesAdapter
import com.example.filesmanager.Model.QuickFileModel
import com.example.filesmanager.Utils.AppConstant
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityStoreFileScreenBinding
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class StoreFileScreen : AppCompatActivity() {
    private lateinit var binding: ActivityStoreFileScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoreFileScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        binding.appbar.appTitle.text = "Large File"
        val viewModel = CommonViewModel.cleanViewModel
        val deleteFiles: MutableStateFlow<MutableList<QuickFileModel>> = MutableStateFlow(
            mutableListOf()
        )
        val deleteDone: MutableStateFlow<Boolean> = MutableStateFlow(false)

        val deleteSize: MutableStateFlow<Long> = MutableStateFlow(0L)
        val adapter = StoreFilesAdapter(
            this,
            viewModel.largeFile.value?.toMutableList() ?: mutableListOf(),
            deleteFiles,
            deleteSize
        )
        lifecycleScope.launch {
            deleteSize.collectLatest {
                deleteDone.update { false }
                if (it > 0) {
                    binding.llCleanBottom.visibility = VISIBLE
                    binding.tvFinalTotalClean.text = Helper.formatSize(it)
                } else {
                    binding.llCleanBottom.visibility = GONE
                }
            }
        }
        binding.rvStoreFile.adapter = adapter
        binding.rvStoreFile.layoutManager = LinearLayoutManager(this)

        lifecycleScope.launch {
            deleteDone.collectLatest {
                if (it) {
                    val newData = viewModel.largeFile.value?.toMutableList() ?: mutableListOf()
                    newData.removeAll(deleteFiles.value)
                    viewModel.largeFile.postValue(newData)

                    adapter.update(newData)
                    deleteSize.update { 0 }
                    Toast.makeText(this@StoreFileScreen, "Delete Complete", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
        binding.btnFinalClean.setOnClickListener {
            Helper.deleteFiles(deleteFiles.value, deleteDone)
        }
    }
}