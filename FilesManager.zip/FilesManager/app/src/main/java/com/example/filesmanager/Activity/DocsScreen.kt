package com.example.filesmanager.Activity

import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.DocScreenAdapter
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.databinding.ActivityDocsScreenBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DocsScreen : AppCompatActivity() {
    private lateinit var binding: ActivityDocsScreenBinding
    private final val TAG = "Docs Screen"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDocsScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.backBtn.setOnClickListener {
            finish()
        }

        binding.appbar.appTitle.text = "Docoument Scan"
        val viewModel = CommonViewModel.viewModel
        if(!viewModel.docsSearched){
            CoroutineScope(Dispatchers.IO).launch {
                viewModel.getAllDocs(contentResolver)
            }
        }
        val docAdapter = DocScreenAdapter(this,viewModel.allDocs.value?: listOf())
        binding.rvDocs.adapter = docAdapter
        binding.rvDocs.layoutManager = LinearLayoutManager(this)

        viewModel.allDocs.observe(this) {
            if (it != null) {
                if (it.isEmpty()) {
                    if(viewModel.docsSearched){
                        binding.pbDocFile.visibility = GONE
                        binding.tvDocStatus.visibility = VISIBLE
                        binding.rvDocs.visibility = GONE
                    }
                } else {
                    binding.rvDocs.visibility = VISIBLE
                    binding.tvDocStatus.visibility = GONE
                    binding.pbDocFile.visibility = GONE
                    docAdapter.update(it)
                }
            } else {

                if (viewModel.docsSearched) {
                    binding.pbDocFile.visibility = GONE
                    binding.tvDocStatus.visibility = VISIBLE
                    binding.rvDocs.visibility = GONE
                }
            }
        }
    }
}