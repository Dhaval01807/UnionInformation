package com.example.filesmanager.Activity

import android.Manifest
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.filesmanager.Adapter.AppListAdapter
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.databinding.ActivityAppScreenBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class AppScreen : AppCompatActivity() {
    private final val TAG = "AppScreen"
    private lateinit var binding: ActivityAppScreenBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAppScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val viewModel = CommonViewModel.viewModel
        val service = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = service.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(), packageName
        )

        var permission = false
        if (mode == AppOpsManager.MODE_DEFAULT) {
            permission =
                (checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) === PackageManager.PERMISSION_GRANTED)
        } else {
            permission = (mode == AppOpsManager.MODE_ALLOWED)
        }
        
        if (!permission) {
            binding.tvAppStatus.text = "Need Permission For Getting Other App Information"
            binding.tvAppStatus.visibility = VISIBLE
            binding.btnAppPermission.visibility = VISIBLE
            binding.rvInstalledApp.visibility = GONE
        }else{
            if(!viewModel.appInformationSearched) {
                CoroutineScope(Dispatchers.IO).launch{
                    viewModel.getAllAppInfo(this@AppScreen)
                }
            }
            viewModel.allAppInformation.observe(this){

                Log.e(TAG, "onCreate: Hit", )
                if(it!=null){

                    if(it.isNotEmpty()){
                        val appAdapter = AppListAdapter(this,it)
                        binding.pbAppProgress.visibility = GONE
                        binding.rvInstalledApp.visibility = VISIBLE
                        binding.rvInstalledApp.adapter = appAdapter
                        binding.rvInstalledApp.layoutManager = LinearLayoutManager(this)
                    }else{
                        if(viewModel.appInformationSearched){
                            binding.pbAppProgress.visibility = GONE
                            binding.tvAppStatus.text = "No App Found"
                            binding.tvAppStatus.visibility = VISIBLE
                        }
                    }
                }else{
                    if(viewModel.appInformationSearched){
                        binding.pbAppProgress.visibility = GONE
                        binding.tvAppStatus.text = "No App Found"
                        binding.tvAppStatus.visibility = VISIBLE
                    }
                }
            }

            val appAdapter = AppListAdapter(this,viewModel.allAppInformation.value?: listOf())
            binding.rvInstalledApp.adapter = appAdapter
            binding.rvInstalledApp.layoutManager = LinearLayoutManager(this)
        }

        binding.btnAppPermission.setOnClickListener{
            val permissionIntent = Intent()
            permissionIntent.setAction(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            appStaticPermission.launch(permissionIntent)
        }
    }

    private val appStaticPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->

        Log.e(TAG, "Result Of Intent: ", )
        val service = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        val mode = service.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(), packageName
        )

        var permission = false
        if (mode == AppOpsManager.MODE_DEFAULT) {
            permission =
                (checkCallingOrSelfPermission(Manifest.permission.PACKAGE_USAGE_STATS) === PackageManager.PERMISSION_GRANTED)
        } else {
            permission = (mode == AppOpsManager.MODE_ALLOWED)
        }

        Log.e(TAG, "Result:${permission} ", )
        if (!permission){
            binding.tvAppStatus.text = "Need Permission For Getting Other App Information"
            binding.tvAppStatus.visibility = VISIBLE
            binding.btnAppPermission.visibility = VISIBLE
            binding.rvInstalledApp.visibility = GONE
        }else{
            recreate()
        }
    }
}

