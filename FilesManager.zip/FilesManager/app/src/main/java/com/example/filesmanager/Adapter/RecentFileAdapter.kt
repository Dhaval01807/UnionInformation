package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.Utils.Helper.FileTypes

class RecentFileAdapter(val context: Context, val arr:List<RecentFileEntity>): RecyclerView.Adapter<RecentFileAdapter.ViewHolder>() {
    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fileLayout = itemView.findViewById<LinearLayout>(R.id.ll_recent)
        val fileIcon = itemView.findViewById<ImageView>(R.id.iv_recent_icon)
        val fileName = itemView.findViewById<TextView>(R.id.tv_recent_name)
        val fileSize = itemView.findViewById<TextView>(R.id.tv_recent_size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.recent_file_layout, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int =arr.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.fileName.text = arr[position].fileName
        holder.fileSize.text = Helper.formatDate(arr[position].openTime)
        val extension: FileTypes? = Helper.fromMimeType(arr[position].fileType)
        Helper.populateIcon(
            context,
            extension,
            arr[position].filePath,
            arr[position].id,
            holder.fileIcon
        )
    }
}