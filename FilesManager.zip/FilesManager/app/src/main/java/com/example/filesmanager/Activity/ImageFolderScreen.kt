package com.example.filesmanager.Activity

import android.os.Bundle
import android.view.View.GONE
import android.view.View.VISIBLE
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.Adapter.ImageFolderAdapter
import com.example.filesmanager.R
import com.example.filesmanager.Utils.CommonViewModel
import com.example.filesmanager.databinding.ActivityImageFolderScreenBinding

class ImageFolderScreen : AppCompatActivity() {
    private lateinit var binding: ActivityImageFolderScreenBinding
    private final var TAG = "ImageFolderScreen"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityImageFolderScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.appbar.backBtn.setOnClickListener {
            finish()
        }
        binding.appbar.appTitle.text = "Image Folders"
        val viewModel = CommonViewModel.viewModel
        if (!viewModel.imageSearched) {
            viewModel.getAllImage(contentResolver)
        }

        val folderAdapter = ImageFolderAdapter(
            this,
            if (viewModel.imageSearched) viewModel.allImages.value!! else hashMapOf()
        )

        viewModel.allImages.observe(this) {
            if (it != null) {
                if (it.isEmpty()) {
                    if (viewModel.imageSearched) {
                        binding.pbImageFolder.visibility = GONE
                        binding.tvImageFolderStatus.visibility = VISIBLE
                        binding.tvImageFolderStatus.text = getString(R.string.noImage)
                        binding.rvImageFolder.visibility = GONE
                    }
                } else {
                    binding.tvImageFolderStatus.visibility = GONE
                    binding.pbImageFolder.visibility = GONE
                    binding.rvImageFolder.visibility = VISIBLE
                    folderAdapter.update(it)
                }
            } else {
                if (viewModel.imageSearched) {
                    binding.pbImageFolder.visibility = GONE
                    binding.tvImageFolderStatus.visibility = VISIBLE
                    binding.tvImageFolderStatus.text = getString(R.string.noImage)
                    binding.rvImageFolder.visibility = GONE
                }
            }
        }

        binding.rvImageFolder.adapter = folderAdapter
        binding.rvImageFolder.layoutManager =
            GridLayoutManager(this, 3, RecyclerView.VERTICAL, false)
    }
}