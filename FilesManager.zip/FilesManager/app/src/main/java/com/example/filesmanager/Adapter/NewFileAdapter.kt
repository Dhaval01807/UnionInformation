package com.example.filesmanager.Adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.Model.NewFileModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper

class NewFileAdapter(val context: Context, var arr:List<NewFileModel>): RecyclerView.Adapter<NewFileAdapter.NewFileViewHolder>() {
    class NewFileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val newFileIcon = itemView.findViewById<ImageView>(R.id.iv_new_file_icon)
        val newFileName = itemView.findViewById<TextView>(R.id.tv_newFile_name)
        val newFileExtra = itemView.findViewById<TextView>(R.id.tv_newFile_info)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewFileViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.new_file_layout,parent,false)
        return NewFileViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: NewFileViewHolder, position: Int) {
        holder.newFileName.text = arr[position].fileName
        Log.e("TAG", "onBindViewHolder: ${arr[position].fileDate}", )
        holder.newFileExtra.text =arr[position].fileDate

        Helper.populateIcon(context,
            Helper.fromMimeType(arr[position].fileType),arr[position].filePath,arr[position].id,holder.newFileIcon)
    }

    fun update(newData: List<NewFileModel>){
        arr = newData
        notifyDataSetChanged()
    }
}