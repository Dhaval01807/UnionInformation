package com.example.filesmanager.Adapter

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.Activity.ImageIntentScreen
import com.example.filesmanager.DB.RecentFileDB
import com.example.filesmanager.DB.RecentFileEntity
import com.example.filesmanager.Model.NewFileModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.Utils.Helper.FileTypes
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date

class NewFileAdapter(val context: Context, var arr: List<NewFileModel>) :
    RecyclerView.Adapter<NewFileAdapter.NewFileViewHolder>() {
    class NewFileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val newFileLayout = itemView.findViewById<LinearLayout>(R.id.ll_newFile)
        val newFileIcon = itemView.findViewById<ImageView>(R.id.iv_new_file_icon)
        val newFileName = itemView.findViewById<TextView>(R.id.tv_newFile_name)
        val newFileExtra = itemView.findViewById<TextView>(R.id.tv_newFile_info)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewFileViewHolder {
        val view =
            LayoutInflater.from(parent.context).inflate(R.layout.new_file_layout, parent, false)
        return NewFileViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: NewFileViewHolder, position: Int) {
        holder.newFileName.text = arr[holder.absoluteAdapterPosition].fileName
        Log.e("TAG", "onBindViewHolder: ${arr[holder.absoluteAdapterPosition].fileDate}")
        holder.newFileExtra.text = arr[holder.absoluteAdapterPosition].fileDate

        Helper.populateIcon(
            context,
            Helper.fromMimeType(arr[holder.absoluteAdapterPosition].fileType),
            arr[holder.absoluteAdapterPosition].filePath,
            arr[holder.absoluteAdapterPosition].id,
            holder.newFileIcon
        )

        holder.newFileLayout.setOnClickListener {
            val extension: FileTypes? = Helper.fromMimeType(arr[holder.absoluteAdapterPosition].fileType)

            when (extension) {
                FileTypes.APK -> {
                    Helper.launchApkIntent(context, arr[holder.absoluteAdapterPosition].filePath)
                }

                FileTypes.AUDIO -> {
                    //Todo
                }

                FileTypes.VIDEO -> {
                    //Todo
                }

                FileTypes.PDF -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
                    )
                }

                FileTypes.TXT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt").toString()
                    )
                }

                FileTypes.WORD -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc").toString()
                    )
                }

                FileTypes.PPT -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt").toString()
                    )
                }

                FileTypes.EXCEL -> {
                    Helper.launchDocSupportedIntent(
                        context,
                        arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xls").toString()
                    )
                }

                FileTypes.IMAGE -> {
                    val newIntent = Intent(context, ImageIntentScreen::class.java)
                    newIntent.data = ContentUris.withAppendedId(Helper.imageUri,arr[position].id)
                    context.startActivity(newIntent)
                }

                FileTypes.WORDX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx").toString()
                    )
                }

                FileTypes.PPTX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx").toString()
                    )
                }

                FileTypes.EXCELX -> {
                    Helper.launchDocSupportedIntent(
                        context, arr[holder.absoluteAdapterPosition].filePath,
                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx").toString()
                    )
                }

                else -> {
                    //Todo
//                    Helper.launchDocSupportedIntent(
//                        context, arr[holder.absoluteAdapterPosition].filePath,
//                        MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf").toString()
//                    )
                }
            }
            CoroutineScope(Dispatchers.IO).launch {
                RecentFileDB.getInstance(context).getRecentDao().insertRecent(
                    RecentFileEntity(
                        fileId = arr[holder.absoluteAdapterPosition].id,
                        fileName = arr[holder.absoluteAdapterPosition].fileName,
                        filePath = arr[holder.absoluteAdapterPosition].filePath,
                        openTime = Date().time,
                        fileType = arr[holder.absoluteAdapterPosition].fileType
                    )
                )
            }
        }
    }

    fun update(newData: List<NewFileModel>) {
        arr = newData
        notifyDataSetChanged()
    }
}