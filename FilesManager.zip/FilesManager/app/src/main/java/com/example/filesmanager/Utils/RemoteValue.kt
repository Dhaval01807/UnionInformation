package com.example.filesmanager.Utils

class RemoteValue {
    companion object{
        var rewardAdId: String = ""
        var appOpen: String =""
        var showAd: Boolean = true
        var showAppOpen: Boolean = true
        var privacyLink :String = ""
    }
}