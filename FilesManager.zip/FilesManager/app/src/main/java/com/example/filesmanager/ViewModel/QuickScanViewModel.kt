package com.example.filesmanager.ViewModel

import android.app.Application
import android.content.ContentResolver
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.webkit.MimeTypeMap
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.filesmanager.Model.QuickFileModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest

class QuickScanViewModel(application: Application) : ViewModel() {

    val applicationContext = application.applicationContext
    private final val TAG = "QuickScanViewModel"

    var quickScanDone: Boolean = false
    val singleFile: HashMap<String, QuickFileModel> = hashMapOf()

    var largeFileSearched: Boolean = false
    val largeFile: MutableLiveData<List<QuickFileModel>> = MutableLiveData(mutableListOf())
    var largeFileSize: Long = 0


    var duplicateFileSearched: Boolean = false
    val duplicateFile: MutableLiveData<HashMap<String, MutableList<QuickFileModel>>> = MutableLiveData(
        hashMapOf()
    )
    var duplicateFileSize: Long = 0
    var duplicateFileCount: Long = 0

    var installApkSearched: Boolean = false
    val installedApk : MutableLiveData<List<QuickFileModel>> = MutableLiveData(listOf())
    var installedApkSize: Long = 0

    var trashFileSearched: Boolean = false
    val trashFile : MutableLiveData<List<QuickFileModel>> = MutableLiveData(listOf())
    var trashFileSize : Long = 0


    val largeFileDelete : MutableLiveData<MutableList<QuickFileModel>> = MutableLiveData(
        mutableListOf()
    )
    var largeDeleteFileSize:MutableLiveData<Long> = MutableLiveData(0)

    val duplicateFileDelete: MutableLiveData<MutableList<QuickFileModel>> = MutableLiveData(
        mutableListOf()
    )
    var duplicateDeleteSize: MutableLiveData<Long> = MutableLiveData(0)

    val installedApkDelete: MutableLiveData<MutableList<QuickFileModel>> = MutableLiveData(
        mutableListOf()
    )
    var installedApkDeleteSize: MutableLiveData<Long> = MutableLiveData(0)


    val trashDelete: MutableLiveData<MutableList<QuickFileModel>> = MutableLiveData(
        mutableListOf()
    )
    var trashDeleteSize: MutableLiveData<Long> = MutableLiveData(0)




    fun quickScan(contentResolver: ContentResolver) {
        Log.e(TAG, "quickScan: Called", )
        searchForHiddenFile(contentResolver)

        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }
        val extension = arrayOf(
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("pdf"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("doc"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("docx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("xlsx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("txt"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("ppt"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("pptx"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("png"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpg"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("jpeg"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("gif"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp4"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("mkv"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("avi"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk"),
            MimeTypeMap.getSingleton().getMimeTypeFromExtension("mp3"),
        )
        val selectionArgs = extension
        val args = selectionArgs.joinToString { "?" }

        val selection =
            MediaStore.Files.FileColumns.MIME_TYPE + " IN (" + args + ")"
        val projections =
            arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DISPLAY_NAME,

            )

        val pointer = contentResolver.query(
            uri,
            projections,
            selection,
            selectionArgs,
            MediaStore.Files.FileColumns.SIZE + " DESC"
        )
        val allFileList: MutableList<QuickFileModel> = mutableListOf()
        val allApkList: MutableList<QuickFileModel> = mutableListOf()
        if (pointer != null) {
            while (pointer.moveToNext()) {
                val fileData = pointer.getString(1)
                val fileId = pointer.getLong(0)
                val fileType = pointer.getString(2)
                val fileSize = pointer.getLong(3)
                val fileName = pointer.getString(4)
                val filePath = pointer.getString(1)
                val file =QuickFileModel(fileId,fileName,filePath, fileSize,fileData,fileType)
                allFileList.add(file)
                if(MimeTypeMap.getSingleton().getMimeTypeFromExtension("apk") == fileType){
                    allApkList.add(file)

                }
            }
        }
        quickScanDone = true
        getLargeFile(allFileList)
        getDuplicate(allFileList)
        getInstalledApk(allApkList)
        allApkList.clear()
    }

    private fun getLargeFile(allFileList: List<QuickFileModel>) {
        val files: MutableList<QuickFileModel> = mutableListOf()
        CoroutineScope(Dispatchers.IO).launch {
            repeat(allFileList.size, {
                val fileSize= allFileList[it].fileSize
                if ( fileSize> 1024 * 1024 * 20) {
                    files.add(allFileList[it])
                    largeFileSize += fileSize
                }
            })
            largeFileSearched = true
            largeFile.postValue(files)
        }
    }


    private fun getDuplicate(allFileList: List<QuickFileModel>) {
        val duplicate: HashMap<String, MutableList<QuickFileModel>> = hashMapOf()
        CoroutineScope(Dispatchers.IO).launch {
            repeat(
                allFileList.size,
                {
                    try{
                        val md5Value = File(allFileList[it].fileData).calculateMD5()
                        if (!singleFile.containsKey(md5Value)) {
                            singleFile[md5Value] = allFileList[it]
                        } else {
                            if (duplicate[md5Value] == null) {
                                duplicate[md5Value] = mutableListOf(allFileList[it], singleFile[md5Value]!!)
                            } else {
                                duplicate[md5Value]!!.add(allFileList[it])
                            }
                            duplicateFileSize+=allFileList[it].fileSize
                            duplicateFileCount += 1
                        }
                    }catch (e:Exception){
                        Log.e(TAG, "getDuplicate: ${allFileList[it].fileData}", )
                    }
                },
            )
            duplicateFileSearched = true
            duplicateFile.postValue(duplicate)
        }
    }

    private fun File.calculateMD5(): String {
        val buffer = ByteArray(1024 * 1024)
        val md = MessageDigest.getInstance("MD5")
        FileInputStream(this).use { fis ->
            var bytesRead: Int
            while (fis.read(buffer).also { bytesRead = it } != -1) {
                md.update(buffer, 0, bytesRead)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun getInstalledApk(allApkList: List<QuickFileModel>){
        val mainIntent = Intent(Intent.ACTION_MAIN, null)
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER)

        CoroutineScope(Dispatchers.IO).launch {
            val pkgAppsList = applicationContext.packageManager.queryIntentActivities(mainIntent, 0)
            val allInstalledApp: MutableList<String> = mutableListOf()
            for (data in pkgAppsList) {
                allInstalledApp.add(data.activityInfo.packageName)
            }

            val installApkFound : MutableList<QuickFileModel> = mutableListOf()
            for(i in allApkList){
                val packageInfo = applicationContext.packageManager.getPackageArchiveInfo(i.filePath,0)

                if(allInstalledApp.contains(packageInfo?.packageName)){
                    installedApkSize+=i.fileSize
                    installApkFound.add(i)
                }
            }

            installApkSearched  = true
            installedApk.postValue(installApkFound)
        }

    }

    private fun searchForHiddenFile(contentResolver: ContentResolver){
        val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Files.getContentUri("external")
        }

        val projections =
            arrayOf(
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.IS_TRASHED
                )
        val bundle = Bundle()
        bundle.putInt("android:query-arg-match-trashed", 1)
        bundle.putString(
            "android:query-arg-sql-selection",
            "${MediaStore.MediaColumns.IS_TRASHED} = 1"
        )
        bundle.putString(
            "android:query-arg-sql-sort-order",
            "${MediaStore.MediaColumns.DATE_MODIFIED} DESC"
        )
        val pointer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                projections,
                bundle, null

            )
        } else {
            contentResolver.query(
                uri,
                projections,
                null,null,
                null
            )
        }
        

        val trashFiles :MutableList<QuickFileModel> = mutableListOf()
        if (pointer != null) {
            while (pointer.moveToNext()) {
                val fileData = pointer.getString(1)
                val fileId = pointer.getLong(0)
                val fileType = pointer.getString(2)
                val fileSize = pointer.getLong(3)
                val fileName = pointer.getString(4)
                val filePath = pointer.getString(1)
                trashFiles.add(QuickFileModel(fileId,fileName, filePath, fileSize, fileData, fileType))
                trashFileSize+=fileSize
            }
        }

        trashFileSearched = true
        trashFile.postValue(trashFiles)
    }
}


class QuickScanViewModelFactory(val context: Application) : ViewModelProvider.Factory{

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(QuickScanViewModel::class.java)) {
            return QuickScanViewModel(context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
//    override fun <T : ViewModel> create(modelClass: Class<T>): T {
//        return QuickScanViewModel(context) as T
//    }
}