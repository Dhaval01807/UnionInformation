package com.example.filesmanager.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filesmanager.Model.AppModel
import com.example.filesmanager.R

class AppListAdapter(val context: Context, val arr:List<AppModel>): RecyclerView.Adapter<AppListAdapter.AppListViewHolder>() {
    class AppListViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val appLayout = itemView.findViewById<LinearLayout>(R.id.ll_app)
        val appName = itemView.findViewById<TextView>(R.id.tv_app_name)
        val appPackageName = itemView.findViewById<TextView>(R.id.tv_app_packageName)
        val appIcon = itemView.findViewById<ImageView>(R.id.iv_app_icon)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): AppListViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.app_list_layout,parent,false)
        return AppListViewHolder(view)
    }

    override fun getItemCount(): Int {
        return arr.size
    }

    override fun onBindViewHolder(holder: AppListViewHolder, position: Int) {
        holder.appName.text = arr[position].appName
        holder.appPackageName.text = arr[position].packageName
//        holder.appPackageName.text = Helper.formatSize(arr[position].occupiedSize)
        Glide.with(holder.appIcon.context).load(context.packageManager.getApplicationIcon(arr[position].packageName)).into(holder.appIcon)
    }
}