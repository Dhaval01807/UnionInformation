package com.example.filesmanager.Adapter

import android.content.ContentUris
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.filesmanager.Model.ImageModel
import com.example.filesmanager.R
import com.example.filesmanager.Utils.Helper

class ImageAdapter(val imageList: List<ImageModel>, val rotateList: MutableList<Float>) : RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imageView = itemView.findViewById<ImageView>(R.id.iv_slider_image)
    }

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): ImageViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.image_layout,parent,false)
        return ImageViewHolder(view)
    }

    override fun getItemCount(): Int {
        return imageList.size
    }

    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        Glide.with(holder.imageView.context)
            .load(ContentUris.withAppendedId(Helper.imageUri, imageList[position].id))
            .into(holder.imageView)

        holder.imageView.rotation = rotateList[position]
    }

    fun rotateImage(angle:Float,index:Int){
        rotateList[index] = angle
        notifyItemChanged(index)
    }
}