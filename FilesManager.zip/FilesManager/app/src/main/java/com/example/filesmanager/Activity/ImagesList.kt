package com.example.filesmanager.Activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filesmanager.Adapter.ImageListAdapter
import com.example.filesmanager.Utils.Helper
import com.example.filesmanager.databinding.ActivityImagesListBinding

class ImagesList : AppCompatActivity() {
    private lateinit var binding: ActivityImagesListBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityImagesListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val imageListAdapter = ImageListAdapter(this, Helper.imageFolder)
        binding.rvImageList.adapter = imageListAdapter
        binding.rvImageList.layoutManager = GridLayoutManager(this,3,RecyclerView.VERTICAL,false)

    }
}