package com.example.filesmanager.Activity

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.example.filesmanager.databinding.ActivityMainBinding
import org.apache.ftpserver.FtpServer
import org.apache.ftpserver.FtpServerFactory
import org.apache.ftpserver.ftplet.UserManager
import org.apache.ftpserver.listener.ListenerFactory
import org.apache.ftpserver.usermanager.PropertiesUserManagerFactory
import org.apache.ftpserver.usermanager.impl.BaseUser
import org.apache.ftpserver.usermanager.impl.WritePermission
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val ftpServer: FtpServer
    }

////
//        binding.btnImage.setOnClickListener{
//                view->
//
//            val newIntent = Intent(this,GalleryImage::class.java)
//            startActivity(newIntent)
//        }
//
//        binding.btnVideo.setOnClickListener{
//                view->
//
//            val newIntent = Intent(this,GalleryVideos::class.java)
//            startActivity(newIntent)
//        }
//        binding.btnFiles.setOnClickListener{
//                view->
//
//            val newIntent = Intent(this, DashboardScreen::class.java)
//            startActivity(newIntent)
//        }


}