package com.example.financialcalc.Activitys

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class PermissionScreen : AppCompatActivity() {
    private lateinit var sharePref :SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_permission_screen)
        sharePref= applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)

        val notAllow: TextView = findViewById(R.id.btn_not_allow)
        val permission: Button = findViewById(R.id.btn_permission)

        notAllow.setOnClickListener {
            val newIntent = Intent(this, ProScreen::class.java)
            startActivity(newIntent)
            finish()
            sharePref.edit().putBoolean(AppConstant.onPermissionStatus,false).apply()
        }

        permission.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                if (ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.POST_NOTIFICATIONS
                    ) == PackageManager.PERMISSION_DENIED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 101)
                }
            }else{
                val newIntent = Intent(this, ProScreen::class.java)
                newIntent.putExtra("fromPro",false)
                startActivity(newIntent)
                finish()
                sharePref.edit().putBoolean(AppConstant.onPermissionStatus,false).apply()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            val newIntent = Intent(this, ProScreen::class.java)
            startActivity(newIntent)
            finish()
            sharePref.edit().putBoolean(AppConstant.onPermissionStatus,false).apply()
        }
    }
}