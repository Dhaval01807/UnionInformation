package com.example.financialcalc.Helper

data class AverageClass(val price:Double, val quantity:Double)