package com.example.financialcalc.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.R

class SavedAdapter(
    var context: Context,
    val savedData: MutableList<String>,
    val mAdapterCallback: AdapterCallback
) :
    RecyclerView.Adapter<SavedAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.save_list_adapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val saved = savedData[position]
        holder.fileName.text = saved

        holder.layout.setOnClickListener { mAdapterCallback.clicked(savedData[position], position) }
        holder.delete.setOnClickListener {
            mAdapterCallback.deleted(savedData[position])
            savedData.removeAt(position)
        }
    }

    interface AdapterCallback {
        fun clicked(fileName: String?, pos: Int)
        fun deleted(fileName: String?)
    }

    override fun getItemCount(): Int {
        return savedData.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var fileName: TextView = itemView.findViewById<TextView>(R.id.title)
        var category: TextView = itemView.findViewById<TextView>(R.id.category)
        var delete: ImageView = itemView.findViewById<ImageView>(R.id.delete)
        var layout: LinearLayout = itemView.findViewById<LinearLayout>(R.id.layout)
    }
}
