package com.example.financialcalc.Activitys

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class PrivacyScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_privacy_screen)

        val sharedPref: SharedPreferences = applicationContext.getSharedPreferences(
            AppConstant.PACKAGE_NAME,
            MODE_PRIVATE
        )
        val termText = findViewById<TextView>(R.id.tv_privacy_policy_text)
        val checkBox: CheckBox = findViewById(R.id.cb_privacy_policy)
        val startBtn: Button = findViewById(R.id.btn_privacy_start)


        val termSpanning: SpannableString = SpannableString(termText.text)
        val indexOfTerm = termText.text.indexOf("Term")
        val indexOfPrivacy = termText.text.indexOf("Privacy")

        termSpanning.setSpan(
            ForegroundColorSpan(getColor(R.color.colorBlue)),
            indexOfTerm,
            indexOfTerm + 16,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        termSpanning.setSpan(
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.setData(Uri.parse(AppConstant.privacyLink))
                    startActivity(intent)
                }

            },
            indexOfTerm,
            indexOfTerm + 16,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        termSpanning.setSpan(
            ForegroundColorSpan(getColor(R.color.colorBlue)),
            indexOfPrivacy,
            indexOfPrivacy + 14,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        termSpanning.setSpan(
            object : ClickableSpan() {
                override fun onClick(widget: View) {
                    val intent = Intent(Intent.ACTION_VIEW)
                    intent.setData(Uri.parse(AppConstant.privacyLink))
                    startActivity(intent)
                }

            },
            indexOfPrivacy,
            indexOfPrivacy + 14,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        termText.text = termSpanning

        checkBox.setOnCheckedChangeListener { buttonView, isChecked ->
            checkBox.error = null
        }

        startBtn.setOnClickListener {
            if (!checkBox.isChecked) {
                Toast.makeText(this, "Please Accept Our Term And Condition", Toast.LENGTH_SHORT)
                    .show()
            } else {
                sharedPref.edit().putBoolean(AppConstant.onPrivacyStatus,false).apply()
                val intent = Intent(this, PermissionScreen::class.java)
                startActivity(intent)
                finish()
            }
        }
    }
}