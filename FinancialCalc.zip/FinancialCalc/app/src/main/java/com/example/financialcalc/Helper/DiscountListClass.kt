package com.example.financialcalc.Helper

data class DiscountListClass(
    val actualValue: Double,
    val qty: Double,
    val discountValue: Double,
    val itemName: String
)