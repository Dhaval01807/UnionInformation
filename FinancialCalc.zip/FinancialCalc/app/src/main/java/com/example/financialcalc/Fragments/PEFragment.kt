package com.example.financialcalc.Fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class PEFragment : Fragment() {
    private var reset: LinearLayout? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var knowMore: TextView? = null
    private var pricePerShare: EditText? = null
    private var earningPerShare: EditText? = null
    private var ratio: EditText? = null
    private var lock1: ImageView? = null
    private var lock2: ImageView? = null
    private var lock3: ImageView? = null
    private var sectionCalculating: String = ""
    private var lock1Bool: Boolean = false
    private var lock2Bool: Boolean = false
    private var lock3Bol: Boolean = false
    private var decimals: DecimalClass? = null

    fun initializeView(view: View) {
        reset = view.findViewById(R.id.reset)

        c1 = view.findViewById(R.id.oneCurrency)
        c2 = view.findViewById(R.id.two)
        knowMore = view.findViewById(R.id.knowMore)

        pricePerShare = view.findViewById(R.id.price)
        earningPerShare = view.findViewById(R.id.earning)
        ratio = view.findViewById(R.id.ratio)

        lock1 = view.findViewById(R.id.lock1)
        lock2 = view.findViewById(R.id.lock2)
        lock3 = view.findViewById(R.id.lock3)
    }

    private fun calculateOne() {
        try {
            val loan =
                earningPerShare!!.text.toString().toDouble() / pricePerShare!!.text.toString()
                    .toDouble() * 100
            pricePerShare?.setText(java.lang.String.valueOf(decimals?.roundOfTo(loan)))
        } catch (e: Exception) {
        }
    }

    private fun calculateThree() {
        try {
            val rat = earningPerShare!!.text.toString().toDouble() / pricePerShare!!.text.toString()
                .toDouble() * 100
            ratio?.setText(java.lang.String.valueOf(decimals?.roundOfTo(rat)))
        } catch (e: Exception) {
        }
    }

    private fun calculateTwo() {
        try {
            val dep = pricePerShare!!.text.toString().toDouble() * ratio!!.text.toString()
                .toDouble() / 100
            earningPerShare?.setText (java.lang.String.valueOf(decimals?.roundOfTo(dep)))
        } catch (e: Exception) {
        }
    }

    fun textOnChangeListener() {
        pricePerShare!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (!lock2Bool || !lock3Bol) {
                    if (pricePerShare!!.hasFocus()) {
                        if (!pricePerShare!!.text.toString()
                                .isEmpty() && (!earningPerShare!!.text.toString()
                                .isEmpty() || !ratio!!.text.toString().isEmpty())
                        ) {
                            if (lock2Bool) {
                                sectionCalculating = "3"
                                calculateThree()
                            } else if (lock3Bol) {
                                sectionCalculating = "2"
                                calculateTwo()
                            } else {
                                if (sectionCalculating.isEmpty()) {
                                    if (ratio!!.text.toString().isEmpty()) {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    } else {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    }
                                } else if (sectionCalculating == "3") {
                                    if (!earningPerShare!!.text.toString().isEmpty()) {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                } else {
                                    if (!ratio!!.text.toString().isEmpty()) {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })

        earningPerShare!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (!lock1Bool || !lock3Bol) {
                    if (earningPerShare!!.hasFocus()) {
                        if (!earningPerShare!!.text.toString()
                                .isEmpty() && (!pricePerShare!!.text.toString()
                                .isEmpty() || !ratio!!.text.toString().isEmpty())
                        ) {
                            if (lock3Bol) {
                                sectionCalculating = "1"
                                calculateOne()
                            } else if (lock1Bool) {
                                sectionCalculating = "3"
                                calculateThree()
                            } else {
                                if (sectionCalculating.isEmpty()) {
                                    if (pricePerShare!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    }
                                } else if (sectionCalculating == "1") {
                                    if (!ratio!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                } else {
                                    if (!pricePerShare!!.text.toString().isEmpty()) {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })

        ratio!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (!lock1Bool || !lock2Bool) {
                    if (ratio!!.hasFocus()) {
                        if (!ratio!!.text.toString()
                                .isEmpty() && (!earningPerShare!!.text.toString()
                                .isEmpty() || !pricePerShare!!.text.toString().isEmpty())
                        ) {
                            if (lock1Bool) {
                                sectionCalculating = "2"
                                calculateTwo()
                            } else if (lock2Bool) {
                                sectionCalculating = "1"
                                calculateOne()
                            } else {
                                if (sectionCalculating.isEmpty()) {
                                    if (pricePerShare!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    }
                                } else if (sectionCalculating == "1") {
                                    if (!earningPerShare!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                } else {
                                    if (!pricePerShare!!.text.toString().isEmpty()) {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_p_e, container, false)

        initializeView(view)
        textOnChangeListener()
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED
        decimals = DecimalClass()
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", AppConstant.STOCK_TITLE_lIST.get(3))
            startActivity(intent)
        }

        reset!!.setOnClickListener {
            sectionCalculating = ""
            pricePerShare!!.setText("")
            earningPerShare!!.setText("")
            ratio!!.setText("")
            pricePerShare!!.isEnabled = true
            earningPerShare!!.isEnabled = true
            ratio!!.isEnabled = true
            lock1!!.isEnabled = true
            lock2!!.isEnabled = true
            lock3!!.isEnabled = true
            lock3Bol = false
            lock1Bool = false
            lock2Bool = false
            var buttonDrawable1 = lock1!!.background
            buttonDrawable1 = DrawableCompat.wrap(buttonDrawable1!!)
            DrawableCompat.setTint(buttonDrawable1, Color.parseColor("#c3c3c3"))
            var buttonDrawable2 = lock2!!.background
            buttonDrawable2 = DrawableCompat.wrap(buttonDrawable2!!)
            DrawableCompat.setTint(buttonDrawable2, Color.parseColor("#c3c3c3"))
            var buttonDrawable3 = lock3!!.background
            buttonDrawable3 = DrawableCompat.wrap(buttonDrawable3!!)
            DrawableCompat.setTint(buttonDrawable3, Color.parseColor("#c3c3c3"))
            lock1!!.background = buttonDrawable1
            lock2!!.background = buttonDrawable2
            lock3!!.background = buttonDrawable3
        }

        textOnChangeListener()

        lockClicked()
        return view
    }

    private fun lockClicked() {
        lock1!!.setOnClickListener {
            if (lock1Bool) {
                pricePerShare!!.isEnabled = true
                lock1Bool = false
                lock2!!.isEnabled = true
                lock3!!.isEnabled = true
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
                lock1!!.background = buttonDrawable
            } else {
                if (pricePerShare!!.text.toString().isEmpty()) {
                    pricePerShare!!.setText("0")
                }
                lock1Bool = true
                earningPerShare!!.isEnabled = true
                ratio!!.isEnabled = true
                pricePerShare!!.isEnabled = false
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.RED)
                lock1!!.background = buttonDrawable
                lockBackGround(1)
            }
        }
        lock2!!.setOnClickListener {
            if (lock2Bool) {
                lock2Bool = false
                earningPerShare!!.isEnabled = true
                lock1!!.isEnabled = true
                lock3!!.isEnabled = true
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#C3C3C3")
                )
                lock2!!.background = buttonDrawable
            } else {
                if (earningPerShare!!.text.toString().isEmpty()) {
                    earningPerShare!!.setText("0")
                }
                pricePerShare!!.isEnabled = true
                ratio!!.isEnabled = true
                lock2Bool = true
                earningPerShare!!.isEnabled = false
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable!!, Color.RED)
                lock2!!.background = buttonDrawable
                lockBackGround(2)
            }
        }
        lock3!!.setOnClickListener {
            if (lock3Bol) {
                lock3Bol = false
                ratio!!.isEnabled = true
                lock2!!.isEnabled = true
                lock1!!.isEnabled = true
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock3!!.background = buttonDrawable
            } else {
                if (ratio!!.text.toString().isEmpty()) {
                    ratio!!.setText("0")
                }
                pricePerShare!!.isEnabled = true
                earningPerShare!!.isEnabled = true
                lock3Bol = true
                ratio!!.isEnabled = false
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable!!, Color.RED)
                lock3!!.background = buttonDrawable
                lockBackGround(3)
            }
        }
    }

    private fun lockBackGround(i: Int) {
        //1
        if (i == 1) {
            var buttonDrawable = lock1!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock1!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock1!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock1!!.background = buttonDrawable
        }
        //2
        if (i == 2) {
            var buttonDrawable = lock2!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock2!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock2!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock2!!.background = buttonDrawable
        }
        //3
        if (i == 3) {
            var buttonDrawable = lock3!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock3!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock3!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock3!!.background = buttonDrawable
        }
    }
}