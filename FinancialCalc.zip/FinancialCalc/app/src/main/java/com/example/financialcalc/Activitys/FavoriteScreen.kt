package com.example.financialcalc.Activitys

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Adapter.CalculationListAdapter
import com.example.financialcalc.Adapter.FavouriteListAdapter
import com.example.financialcalc.Helper.FavoriteListClass
import com.example.financialcalc.Helper.ListAdapterModel
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.initialization.InitializationStatus
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback

class FavoriteScreen : AppCompatActivity(), CalculationListAdapter.AdapterCallback,
    FavouriteListAdapter.AdapterCallback {
    private var add: ImageView? = null
    private var back: ImageView? = null
    private var recyclerView: RecyclerView? = null
    private var allRecycler: RecyclerView? = null
    private var sharedPref: SharedPreferences? = null
    private var openedInInt: Int = 0
    private var mInterstitialAd: InterstitialAd? = null
    private var NUMBER_OF_TIME_OPENED: String = "NUMBER OF TIME"
    

    override fun onBackPressed() {
        if (openedInInt % 4 == 0) {
            
        } else {
            if (mInterstitialAd != null) {
                mInterstitialAd?.show(this)
            } else {
                Log.d("TAG", "The interstitial ad wasn't ready yet.")
            }
        }
        openedInInt++
        sharedPref!!.edit().putInt(NUMBER_OF_TIME_OPENED, openedInInt).apply()
        super.onBackPressed()
    }

    private fun addAllToList() {
        var listAdapter: FavoriteListClass?
        var addToFav: ListAdapterModel?
        AppConstant.FAVOURITE_LIST.clear()
        AppConstant.FAVOURITE_ALL_LIST.clear()
        val allPosition = stringToArray(sharedPref!!.getString(AppConstant.FAVOURITE, null))
        var total = 0
        for (i in 0 until AppConstant.BANK_TITLE_lIST.size) {
            listAdapter = FavoriteListClass(
                AppConstant.BANK_TITLE_lIST[i],
                AppConstant.BANK_INFO_lIST[i],
                AppConstant.BANK_ICON_LIST[i],
                allPosition[total + i] == 1
            )
            AppConstant.FAVOURITE_ALL_LIST.add(listAdapter)
            if (allPosition[i + total] == 1) {
                addToFav = ListAdapterModel(
                    AppConstant.BANK_TITLE_lIST[i],
                    AppConstant.BANK_INFO_lIST[i],
                    AppConstant.BANK_ICON_LIST[i]
                )
                AppConstant.FAVOURITE_LIST.add(addToFav)
            }
        }
        total += AppConstant.BANK_TITLE_lIST.size

        for (i in 0 until AppConstant.STOCK_TITLE_lIST.size) {
            listAdapter = FavoriteListClass(
                AppConstant.STOCK_TITLE_lIST[i],
                AppConstant.STOCK_INFO_lIST[i],
                AppConstant.STOCK_ICON_LIST[i],
                allPosition[total + i] == 1
            )
            AppConstant.FAVOURITE_ALL_LIST.add(listAdapter)
            if (allPosition[i + total] == 1) {
                addToFav = ListAdapterModel(
                    AppConstant.STOCK_TITLE_lIST[i],
                    AppConstant.STOCK_INFO_lIST[i],
                    AppConstant.STOCK_ICON_LIST[i]
                )
                AppConstant.FAVOURITE_LIST.add(addToFav)
            }
        }
        total += AppConstant.STOCK_TITLE_lIST.size
        for (i in 0 until AppConstant.BUSINESS_ICON_LIST.size) {
            listAdapter = FavoriteListClass(
                AppConstant.BUSINESS_TITLE_lIST[i],
                AppConstant.BUSINESS_INFO_lIST[i],
                AppConstant.BUSINESS_ICON_LIST[i],
                allPosition[total + i] == 1
            )
            AppConstant.FAVOURITE_ALL_LIST.add(listAdapter)
            if (allPosition[i + total] == 1) {
                addToFav = ListAdapterModel(
                    AppConstant.BUSINESS_TITLE_lIST[i],
                    AppConstant.BUSINESS_INFO_lIST[i],
                    AppConstant.BUSINESS_ICON_LIST[i]
                )
                AppConstant.FAVOURITE_LIST.add(addToFav)
            }
        }
        total += AppConstant.BUSINESS_ICON_LIST.size
        for (i in 0 until AppConstant.FINANCE_TITLE_lIST.size) {
            listAdapter = FavoriteListClass(
                AppConstant.FINANCE_TITLE_lIST[i],
                AppConstant.FINANCE_INFO_lIST[i],
                AppConstant.FINANCE_ICON_LIST[i],
                allPosition[total + i] == 1
            )
            AppConstant.FAVOURITE_ALL_LIST.add(listAdapter)
            if (allPosition[i + total] == 1) {
                addToFav = ListAdapterModel(
                    AppConstant.FINANCE_TITLE_lIST[i],
                    AppConstant.FINANCE_INFO_lIST[i],
                    AppConstant.FINANCE_ICON_LIST[i]
                )
                AppConstant.FAVOURITE_LIST.add(addToFav)
            }
        }
    }

    private fun stringToArray(string: String?): IntArray {
        if (string != null) {
            val ar: Array<String> =
                (string.split(AppConstant.DIVIDER.toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray())
            val array = IntArray(ar.size)
            for (i in ar.indices) {
                array[i] = ar[i].toInt()
            }
            return array
        } else {
            val array = IntArray(200)
            for (i in array.indices) {
                array[i] = 0
            }
            return array
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorite_screen)
        add = findViewById(R.id.add)
        back = findViewById(R.id.back)
        recyclerView = findViewById(R.id.recycler)
        allRecycler = findViewById(R.id.allRecycler)

        sharedPref = applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)





        if (!AppConstant.LIGHT_THEME) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        sharedPref =
            applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)

        addAllToList()

        updateRecyclerView(AppConstant.FAVOURITE_LIST)
        add?.setOnClickListener(View.OnClickListener {
            add ?.visibility = View.INVISIBLE
            updateAllRecyclerView(AppConstant.FAVOURITE_ALL_LIST)
        })

        back?.setOnClickListener {
            onBackPressed()
        }
    }

    private fun updateAllRecyclerView(allCalculators: List<FavoriteListClass>) {
        allRecycler!!.visibility = View.VISIBLE
        recyclerView!!.visibility = View.GONE
        val calculationListAdapter: FavouriteListAdapter = FavouriteListAdapter(
            this, allCalculators,
            this
        )
        val gridLayoutManager = GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false)
        allRecycler!!.layoutManager = gridLayoutManager
        allRecycler!!.adapter = calculationListAdapter
    }


    private fun updateRecyclerView(favouriteList: List<ListAdapterModel>) {
        allRecycler!!.visibility = View.GONE
        recyclerView!!.visibility = View.VISIBLE
        val calculationListAdapter: CalculationListAdapter = CalculationListAdapter(
            this, favouriteList,
            this
        )
        val gridLayoutManager = GridLayoutManager(this, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager
        recyclerView!!.adapter = calculationListAdapter
    }

    override fun onCalled(name: String?) {
        val intent = Intent(this, CalculationScreen::class.java)

        intent.putExtra("NAME_OF_APP", name)
        startActivity(intent)
    }

    override fun pressedFav() {
        updateAllRecyclerView(AppConstant.FAVOURITE_ALL_LIST)
    }


}