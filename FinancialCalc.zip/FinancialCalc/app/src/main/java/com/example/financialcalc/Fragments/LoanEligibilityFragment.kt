package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import kotlin.math.pow

class LoanEligibilityFragment : Fragment() {
    private var shareBtn: ShapeableImageView? = null
    private var monthlyIncome: EditText? = null
    private var monthlyEmi: EditText? = null
    private var loanAmount: EditText? = null
    private var annualInterest: EditText? = null
    private var tenure: EditText? = null
    private var areYouEligible: TextView? = null
    private var emiResult: TextView? = null
    private var loanThatEligible: TextView? = null
    private var emiThatEligible: TextView? = null
    private var monthToggle: TextView? = null
    private var currency1Symbol: TextView? = null
    private var currency2Symbol: TextView? = null
    private var currency3Symbol: TextView? = null
    private var knowMore: TextView? = null
    private var calculateBtn: TextView? = null
    private var monthlyToggleBoolean: Boolean = true
    private var answer: LinearLayout? = null
    private var resetBtn: LinearLayout? = null

    private fun initialize(view: View) {
        resetBtn = view.findViewById(R.id.reset)
        shareBtn = view.findViewById(R.id.share)
        calculateBtn = view.findViewById(R.id.calculate)

        monthlyIncome = view.findViewById(R.id.grossIncome)
        monthlyEmi = view.findViewById(R.id.monthlyEmi)
        loanAmount = view.findViewById(R.id.loan)
        annualInterest = view.findViewById(R.id.interst)
        tenure = view.findViewById(R.id.tenure)

        areYouEligible = view.findViewById(R.id.isEligible)
        emiResult = view.findViewById(R.id.emiForSpecLoan)
        loanThatEligible = view.findViewById(R.id.loanEligible)
        emiThatEligible = view.findViewById(R.id.emiEligible)
        monthToggle = view.findViewById(R.id.month)
        currency1Symbol = view.findViewById(R.id.oneCurrency)
        currency2Symbol = view.findViewById(R.id.twoCurrency)
        currency3Symbol = view.findViewById(R.id.threeCurrency)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer?.visibility = View.GONE
    }

    fun calculate() {
        val decimal = DecimalClass()
        answer!!.visibility = View.VISIBLE
        var foir = 0.0
        val eligibleemi: Double
        val eligbleloan: Double
        var loan: Double
        val givenemi: Double
        val tenureDouble = if (monthlyToggleBoolean) {
            tenure!!.text.toString().toDouble()
        } else {
            tenure!!.text.toString().toDouble() * 12
        }
        val income = monthlyIncome!!.text.toString().toDouble()
        var interest = annualInterest!!.text.toString().toDouble()
        interest = interest / 1200
        val preemi = monthlyEmi!!.text.toString().toDouble()
        val loanamout = loanAmount!!.text.toString().toDouble()
        if (income >= 8000 && income < 10000) {
            foir = 0.35
        } else if (income >= 10000 && income < 25000) {
            foir = 0.4
        } else if (income >= 25000 && income < 50000) {
            foir = 0.45
        } else if (income >= 50000 && income <= 100000) {
            foir = 0.5
        } else if (income > 100000) {
            foir = 0.55
        }
        eligibleemi = foir * income - preemi
        val total = eligibleemi * tenureDouble
        eligbleloan = (total * (1 - (1 + interest).pow(-tenureDouble))) / (tenureDouble * interest)

        if (loanamout <= eligbleloan) {
            areYouEligible!!.text = "Yes"
        } else {
            areYouEligible!!.text = "No"
        }
        val p = (1 + interest).pow(tenureDouble)
        givenemi = loanamout * interest * p / (p - 1)

        emiResult?.text = (decimal.round(givenemi) + " " + AppConstant.CURRENCY_SELECTED)

        loanThatEligible?.text = (decimal.round(eligbleloan) + " " + AppConstant.CURRENCY_SELECTED)

        emiResult?.text = (decimal.round(eligibleemi) + " " + AppConstant.CURRENCY_SELECTED)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_loan_eligibility, container, false)
        initialize(view)
        currency1Symbol?.text = AppConstant.CURRENCY_SELECTED
        currency2Symbol?.text = AppConstant.CURRENCY_SELECTED
        currency3Symbol?.text = AppConstant.CURRENCY_SELECTED

        resetBtn!!.setOnClickListener {
            monthlyEmi!!.setText("")
            monthlyIncome!!.setText("")
            loanAmount!!.setText("")
            annualInterest!!.setText("")
            monthToggle!!.text = "Monthly"
            monthlyToggleBoolean = true
            tenure!!.setText("")
            answer!!.visibility = View.GONE
        }
        monthToggle!!.setOnClickListener {
            if (monthlyToggleBoolean) {
                monthlyToggleBoolean = false
                monthToggle!!.text = "Yearly"
            } else {
                monthlyToggleBoolean = true
                monthToggle!!.text = "Monthly"
            }
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(context, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Loan Eligibility")
            startActivity(intent)
        }
        calculateBtn!!.setOnClickListener {
            if (monthlyIncome!!.text.toString().isEmpty() || monthlyEmi!!.text.toString().isEmpty()
                || loanAmount!!.text.toString().isEmpty() || tenure!!.text.toString()
                    .isEmpty() || annualInterest!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (annualInterest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
            }
        }
        shareBtn!!.setOnClickListener {
            if (monthlyIncome!!.text.toString().isEmpty() || monthlyEmi!!.text.toString().isEmpty()
                || loanAmount!!.text.toString().isEmpty() || annualInterest!!.text.toString()
                    .isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (annualInterest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I am eligible for the loan amount ${loanThatEligible!!.text}
 With EMI eligible for ${emiThatEligible!!.text}

 Check your Loan Eligibility using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }
        return view
    }
}