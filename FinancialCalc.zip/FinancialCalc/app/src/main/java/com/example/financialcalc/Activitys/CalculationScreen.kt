package com.example.financialcalc.Activitys

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.financialcalc.Ads.AdConstant
import com.example.financialcalc.Ads.AdLoad
import com.example.financialcalc.Ads.TemplateView
import com.example.financialcalc.Fragments.BondFragment
import com.example.financialcalc.Fragments.BreakEvenBusiness
import com.example.financialcalc.Fragments.BreakEvenFragment
import com.example.financialcalc.Fragments.BusinessForecastFragment
import com.example.financialcalc.Fragments.CompareLoanFragment
import com.example.financialcalc.Fragments.CostOfGoodFragment
import com.example.financialcalc.Fragments.CreditCardFragment
import com.example.financialcalc.Fragments.DepreciateFragment
import com.example.financialcalc.Fragments.DiscountFragment
import com.example.financialcalc.Fragments.EffectiveInterestRateFragment
import com.example.financialcalc.Fragments.EmiFragment
import com.example.financialcalc.Fragments.FdFragment
import com.example.financialcalc.Fragments.FibonacciFragment
import com.example.financialcalc.Fragments.GrossProfitFragment
import com.example.financialcalc.Fragments.IrrFragment
import com.example.financialcalc.Fragments.LoadToDeposit
import com.example.financialcalc.Fragments.LoanEligibilityFragment
import com.example.financialcalc.Fragments.LumpSum
import com.example.financialcalc.Fragments.MarginFragment
import com.example.financialcalc.Fragments.MortgageFragment
import com.example.financialcalc.Fragments.NPVFragment
import com.example.financialcalc.Fragments.OperativeMarginFragment
import com.example.financialcalc.Fragments.PEFragment
import com.example.financialcalc.Fragments.PPFFragment
import com.example.financialcalc.Fragments.PivotPointsFragment
import com.example.financialcalc.Fragments.RDFragment
import com.example.financialcalc.Fragments.SWPFragment
import com.example.financialcalc.Fragments.SalaryIncrement
import com.example.financialcalc.Fragments.SavingFragment
import com.example.financialcalc.Fragments.SimpleAndCompoundFragment
import com.example.financialcalc.Fragments.SipFragment
import com.example.financialcalc.Fragments.StockAverage
import com.example.financialcalc.Fragments.StockReturnFragment
import com.example.financialcalc.Fragments.TVMFragment
import com.example.financialcalc.Fragments.TaxFragment
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView


class CalculationScreen : AppCompatActivity() {
    var title: TextView? = null
    var titleIcon: ImageView? = null

    var sharePref: SharedPreferences? = null
    var openedInInt: Int = 0
    var nameOfAppp: String? = null
    var NUMBER_OF_TIME_OPENED: String = "NUMBER OF TIME"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculation_screen)
        title = findViewById(R.id.titleText)

        val intent = intent
        nameOfAppp = intent.getStringExtra("NAME_OF_APP")

        sharePref =
            applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)

        openedInInt = sharePref?.getInt(NUMBER_OF_TIME_OPENED, 0)!!

        title?.text = nameOfAppp

        if(!AppConstant.PURCHASE_STATUS){
            if(AdConstant.interstitialAdCount-1==AppConstant.interstitialAdCount){
                AdLoad.loadInterstitialAd(AdConstant.interstitialAdId,this)
            }
            if(AppConstant.interstitialAdCount == AdConstant.interstitialAdCount){
                AdLoad.interstitialAd?.show(this)
                AppConstant.interstitialAdCount=0
            }
            if(AdLoad.calculatorNativeAd != null){
                val templateNative: TemplateView = findViewById(R.id.nativeAds)
                templateNative.visibility = View.VISIBLE
                templateNative.setNativeAd(AdLoad.calculatorNativeAd)
            }
        }
        openFragment()
    }


    private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        try {
            val container = findViewById<FrameLayout>(R.id.nativeAds)
            container.visibility = View.VISIBLE
            val headlineView: TextView = adView.findViewById(R.id.heading)
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView


            val body: TextView = adView.findViewById(R.id.body)
            if (!nativeAd.body.equals(null)) {
                body.text = nativeAd.body
                adView.bodyView = body
            }

            val starRating: RatingBar = adView.findViewById(R.id.start_rating)
            if (nativeAd.starRating != null) {
                starRating.rating = nativeAd.starRating?.toFloat() ?: 0f
                adView.starRatingView = starRating
            }

            val advitisor: TextView = adView.findViewById(R.id.advertisername)
            if (nativeAd.advertiser != null) {
                advitisor.text = nativeAd.advertiser
                adView.advertiserView = advitisor
            }

            val icon: ImageView = adView.findViewById(R.id.adicon)
            if (nativeAd.icon != null) {
                icon.setImageDrawable(nativeAd.icon?.drawable)
                adView.iconView = icon
            }

            val button: Button = adView.findViewById(R.id.calltoaction)
            if (nativeAd.callToAction != null) {
                button.text = nativeAd.callToAction
                adView.callToActionView = button
            }

            val mediaView: MediaView = adView.findViewById(R.id.media_view)
            adView.mediaView = mediaView


            adView.setNativeAd(nativeAd)


            container.removeAllViews()


            container.addView(adView)
        } catch (e: Exception) {
        }
    }



    private fun openFragment() {
        AppConstant.interstitialAdCount+=1
        val fragmentMap = mapOf(
            AppConstant.BANK_TITLE_lIST[0] to LoanEligibilityFragment(),
            AppConstant.BANK_TITLE_lIST[1] to CompareLoanFragment(),
            AppConstant.BANK_TITLE_lIST[2] to FdFragment(),
            AppConstant.BANK_TITLE_lIST[3] to RDFragment(),
            AppConstant.BANK_TITLE_lIST[4] to SavingFragment(),
            AppConstant.BANK_TITLE_lIST[5] to LoadToDeposit(),
            AppConstant.BANK_TITLE_lIST[6] to CreditCardFragment(),

            AppConstant.STOCK_TITLE_lIST[0] to StockReturnFragment(),
            AppConstant.STOCK_TITLE_lIST[1] to BreakEvenFragment(),
            AppConstant.STOCK_TITLE_lIST[2] to StockAverage(),
            AppConstant.STOCK_TITLE_lIST[3] to PEFragment(),
            AppConstant.STOCK_TITLE_lIST[4] to PivotPointsFragment(),
            AppConstant.STOCK_TITLE_lIST[5] to FibonacciFragment(),

            AppConstant.BUSINESS_TITLE_lIST[0] to GrossProfitFragment(),
            AppConstant.BUSINESS_TITLE_lIST[1] to CostOfGoodFragment(),
            AppConstant.BUSINESS_TITLE_lIST[2] to DiscountFragment(),
            AppConstant.BUSINESS_TITLE_lIST[3] to BreakEvenBusiness(),
            AppConstant.BUSINESS_TITLE_lIST[4] to MarginFragment(),
            AppConstant.BUSINESS_TITLE_lIST[5] to OperativeMarginFragment(),
            AppConstant.BUSINESS_TITLE_lIST[6] to EffectiveInterestRateFragment(),
            AppConstant.BUSINESS_TITLE_lIST[7] to NPVFragment(),
            AppConstant.BUSINESS_TITLE_lIST[8] to BusinessForecastFragment(),

            AppConstant.FINANCE_TITLE_lIST[0] to PPFFragment(),
            AppConstant.FINANCE_TITLE_lIST[1] to SimpleAndCompoundFragment(),
            AppConstant.FINANCE_TITLE_lIST[2] to SWPFragment(),
            AppConstant.FINANCE_TITLE_lIST[3] to SipFragment(),
            AppConstant.FINANCE_TITLE_lIST[4] to LumpSum(),
            AppConstant.FINANCE_TITLE_lIST[5] to EmiFragment(),
            AppConstant.FINANCE_TITLE_lIST[6] to MortgageFragment(),
            AppConstant.FINANCE_TITLE_lIST[7] to TaxFragment(),
            AppConstant.FINANCE_TITLE_lIST[8] to TVMFragment(),
            AppConstant.FINANCE_TITLE_lIST[9] to BondFragment(),
            AppConstant.FINANCE_TITLE_lIST[10] to SalaryIncrement(),
            AppConstant.FINANCE_TITLE_lIST[11] to DepreciateFragment(),
            AppConstant.FINANCE_TITLE_lIST[12] to IrrFragment()
        )
        fragmentMap[nameOfAppp]?.let {
            supportFragmentManager.beginTransaction().replace(R.id.replace, it).commit()
        } ?: run {
            val intent = Intent(this, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", nameOfAppp)
            startActivity(intent)
            finish()
        }
    }


    override fun onBackPressed() {
        super.onBackPressed()
    }


    fun back(view: View?) {
        super.onBackPressed()
    }

}