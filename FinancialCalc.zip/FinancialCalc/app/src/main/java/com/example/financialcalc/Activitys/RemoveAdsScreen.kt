package com.example.financialcalc.Activitys

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.anjlab.android.iab.v3.BillingProcessor
import com.anjlab.android.iab.v3.TransactionDetails
import com.example.financialcalc.Broadcast.UpdateWorks
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.initialization.InitializationStatus
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener
import com.google.android.gms.ads.rewarded.RewardedAd
import java.util.concurrent.TimeUnit

class RemoveAdsScreen : AppCompatActivity(), BillingProcessor.IBillingHandler {
    var bp: BillingProcessor? = null
    var join: Button? = null
    var mRewardedAds: RewardedAd? = null
    var subscriptionTransactionDetails: TransactionDetails? = null
    var purchase: SharedPreferences? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_remove_ads_screen)
        if (!AppConstant.LIGHT_THEME) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
        MobileAds.initialize(this, object : OnInitializationCompleteListener {
            override fun onInitializationComplete(initializationStatus: InitializationStatus) {
//                loadRewardAds()
            }
        })
        join = findViewById(R.id.join)
        bp = BillingProcessor(this, AppConstant.GOOGLE_PLAY_LICENSE, this)
        bp?.initialize()
        purchase = applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)
    }

//    private fun loadRewardAds() {
//        val adRequest: AdRequest = AdRequest.Builder().build()
//
//        RewardedAd.load(
//            this, getString(R.string.rewards_ads),
//            adRequest, object : RewardedAdLoadCallback() {
//                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
//                    mRewardedAds = null
//                }
//
//                override fun onAdLoaded(rewardedAd: RewardedAd) {
//                    mRewardedAds = rewardedAd
//                    mRewardedAds?.setFullScreenContentCallback(object : FullScreenContentCallback() {
//                        override fun onAdShowedFullScreenContent() {
//
//                        }
//
//                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
//
//                        }
//
//                        override fun onAdDismissedFullScreenContent() {
//                            mRewardedAds = null
//                        }
//                    })
//                }
//            })
//    }

    fun rewardAds(view: View?) {
        if (mRewardedAds != null) {
            mRewardedAds?.show(this) { // Handle the reward.
                AppConstant.PURCHASE_STATUS = true
                purchase!!.edit().putBoolean("PURCHASE", true).apply()
                Toast.makeText(
                    this@RemoveAdsScreen,
                    "Successfully removed ads for 1 hours.",
                    Toast.LENGTH_SHORT
                ).show()
                Log.d("Rewards", "Earned Rewards")
                noAds()
            }
        } else {
            Toast.makeText(this, "Failed :(", Toast.LENGTH_LONG).show()
        }
    }

    private val handler = Handler()
    private val updateRunnable: Runnable = object : Runnable {
        override fun run() {
            handler.postDelayed(this, (60 * 60 * 1000).toLong()) // Schedule for every hour
            updateSharedPreferences()
        }
    }

    private fun updateSharedPreferences() {
        Log.d("Rewards", "Rewards Solved")
        AppConstant.PURCHASE_STATUS = false
        purchase!!.edit().putBoolean("PURCHASE", false).apply()
    }

    private fun noAds() {
        val workRequest: OneTimeWorkRequest = OneTimeWorkRequest.Builder(UpdateWorks::class.java).setInitialDelay(1, TimeUnit.MINUTES) // Delay before the first execution
                .build()

        WorkManager.getInstance(this).enqueue(workRequest)

    }


    private fun hassubsription(): Boolean {
        return if (subscriptionTransactionDetails != null) {
            subscriptionTransactionDetails?.purchaseInfo != null
        } else {
            false
        }
    }

    override fun onBillingInitialized() {
        subscriptionTransactionDetails = bp?.getPurchaseTransactionDetails(AppConstant.PRODUCT_ID)
        join!!.setOnClickListener {
            if (bp?.isOneTimePurchaseSupported()!!) {
                if (!hassubsription()) {
                    bp?.purchase(this@RemoveAdsScreen, AppConstant.PRODUCT_ID)
                }
            }
        }
        if (hassubsription()) {
            purchase!!.edit().putBoolean("PURCHASE", true).apply()
            Toast.makeText(
                this@RemoveAdsScreen,
                "You have purchased, Just restart the app.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onProductPurchased(productId: String, details: TransactionDetails?) {
        purchase!!.edit().putBoolean("PURCHASE", true).apply()
    }

    override fun onPurchaseHistoryRestored() {
    }

    override fun onBillingError(errorCode: Int, error: Throwable?) {
        Toast.makeText(this, ":(", Toast.LENGTH_SHORT).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (!bp?.handleActivityResult(requestCode, resultCode, data)!!) {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    public override fun onDestroy() {
        if (bp != null) {
            bp?.release()
        }
        super.onDestroy()
    }
}