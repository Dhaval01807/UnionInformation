package com.example.financialcalc.Helper


data class SalaryModel(val index: Int, val month: Double, val year: Double)
