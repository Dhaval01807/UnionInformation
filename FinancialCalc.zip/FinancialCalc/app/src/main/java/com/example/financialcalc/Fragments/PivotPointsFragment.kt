package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView

class PivotPointsFragment : Fragment() {
    private var share: ShapeableImageView? = null
    private var lowValue: EditText? = null
    private var highValue: EditText? = null
    private var previousClosed: EditText? = null
    private var r3: TextView? = null
    private var r2: TextView? = null
    private var r1: TextView? = null
    private var pp: TextView? = null
    private var s3: TextView? = null
    private var s2: TextView? = null
    private var s1: TextView? = null
    private var currency1: TextView? = null
    private var currency2: TextView? = null
    private var currency3: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var decimal: DecimalClass? = null
    private fun initialize(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        lowValue = view.findViewById(R.id.low)
        highValue = view.findViewById(R.id.high)
        previousClosed = view.findViewById(R.id.prev)


        r3 = view.findViewById(R.id.r3)
        r2 = view.findViewById(R.id.r2)
        r1 = view.findViewById(R.id.r1)
        s1 = view.findViewById(R.id.s1)
        s2 = view.findViewById(R.id.s2)
        s3 = view.findViewById(R.id.s3)
        pp = view.findViewById(R.id.pivotPoint)
        currency1 = view.findViewById(R.id.oneCurrency)
        currency2 = view.findViewById(R.id.twoCurrency)
        currency3 = view.findViewById(R.id.threeCurrency)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE
    }

    fun calculate() {
        decimal = DecimalClass()
        answer!!.visibility = View.VISIBLE
        var r3D = 0.0
        var r2D = 0.0
        var r1D = 0.0
        var ppD = 0.0
        var s3D = 0.0
        var s2D = 0.0
        var s1D = 0.0
        ppD = (lowValue!!.text.toString().toDouble() + highValue!!.text.toString()
            .toDouble() + previousClosed!!.text.toString().toDouble()) / 3
        pp?.text = (decimal?.round(ppD))
        r1D = (2 * ppD) - lowValue!!.text.toString().toDouble()
        r2D = ppD + (highValue!!.text.toString().toDouble() - lowValue!!.text.toString().toDouble())
        r3D = highValue!!.text.toString().toDouble() + 2 * (ppD - lowValue!!.text.toString()
            .toDouble())

        s1D = (2 * ppD) - highValue!!.text.toString().toDouble()
        s2D = ppD - (highValue!!.text.toString().toDouble() - lowValue!!.text.toString().toDouble())
        s3D = lowValue!!.text.toString().toDouble() - 2 * (highValue!!.text.toString()
            .toDouble() - ppD)

        r1?.text = (decimal?.round(r1D))
        r2?.text = (decimal?.round(r2D))
        r3?.text = (decimal?.round(r3D))

        s1?.text = (decimal?.round(s1D))
        s2?.text = (decimal?.round(s2D))
        s3?.text = (decimal?.round(s3D))
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_pivot_points, container, false)
        initialize(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED
        currency2?.text = AppConstant.CURRENCY_SELECTED
        currency3?.text = AppConstant.CURRENCY_SELECTED

        reset!!.setOnClickListener {
            lowValue!!.setText("")
            highValue!!.setText("")
            previousClosed!!.setText("")
            answer!!.visibility = View.GONE
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Pivot Points")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (lowValue!!.text.toString().isEmpty() || highValue!!.text.toString().isEmpty()
                || previousClosed!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (lowValue!!.text.toString().toDouble() > highValue!!.text.toString()
                    .toDouble()
            ) {
                Toast.makeText(
                    context,
                    "High Value should be greater than Low Value",
                    Toast.LENGTH_SHORT
                ).show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener { }
        return view
    }
}