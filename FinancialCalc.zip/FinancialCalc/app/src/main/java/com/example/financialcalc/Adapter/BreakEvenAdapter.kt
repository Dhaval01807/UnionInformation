package com.example.financialcalc.Adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.BreakEven
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import java.lang.String
import kotlin.Boolean
import kotlin.CharSequence
import kotlin.Int

class BreakEvenAdapter(
    var context: Context,
    val breakList: List<BreakEven>,
    callback: AdapterCallback
) :
    RecyclerView.Adapter<BreakEvenAdapter.ViewHolder>() {
    private val mAdapterCallback = callback
    var removeDiscount: Boolean = false

    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.break_event_element, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val breakEvenClass: BreakEven = breakList[holder.adapterPosition]

        holder.price.setText(String.valueOf(breakEvenClass.price))
        holder.fee.setText(String.valueOf(breakEvenClass.fee))

        if (breakEvenClass.purchase) {
            holder.purchaseToogle.text = "Purchase"
        } else {
            holder.purchaseToogle.text = "Sold"
        }

        holder.qty.setText(String.valueOf(breakEvenClass.quantity))

        holder.fee.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val value: BreakEven = breakList[holder.adapterPosition]
                if (holder.fee.text.toString().isEmpty()) {
                    val f = 0.0
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        value.quantity,
                        f,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                } else {
                    val f = holder.fee.text.toString().toDouble()
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        value.quantity,
                        f,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                }
            }

            override fun afterTextChanged(s: Editable) {
                val value: BreakEven = breakList[holder.adapterPosition]
                if (holder.fee.text.toString().isEmpty()) {
                    val f = 0.0
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        value.quantity,
                        f,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                } else {
                    val f = holder.fee.text.toString().toDouble()
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        value.quantity,
                        f,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                }
            }
        })
        holder.price.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val value: BreakEven = breakList[holder.adapterPosition]
                if (holder.price.text.toString().isEmpty()) {
                    val p = 0.0
                    val newBreak: BreakEven = BreakEven(
                        p,
                        value.quantity,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                } else {
                    val p = holder.price.text.toString().toDouble()
                    val newBreak: BreakEven = BreakEven(
                        p,
                        value.quantity,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                }
            }

            override fun afterTextChanged(s: Editable) {
                val value: BreakEven = breakList[holder.adapterPosition]
                if (holder.price.text.toString().isEmpty()) {
                    val p = 0.0
                    val newBreak: BreakEven = BreakEven(
                        p,
                        value.quantity,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                } else {
                    val p = holder.price.text.toString().toDouble()
                    val newBreak: BreakEven = BreakEven(
                        p,
                        value.quantity,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                }
            }
        })
        holder.purchaseToogle.setOnClickListener {
            val value: BreakEven = breakList[holder.adapterPosition]
            if (value.purchase) {
                holder.purchaseToogle.text = "Sold"
                val newBreak: BreakEven = BreakEven(
                    value.price,
                    value.quantity,
                    value.fee,
                    false
                )
                AppConstant.BREAK_LIST.set(holder.adapterPosition, newBreak)
            } else {
                holder.purchaseToogle.text = "Purchase"
                val newBreak: BreakEven = BreakEven(
                    value.price,
                    value.quantity,
                    value.fee,
                    true
                )
                AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
            }
        }
        holder.qty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val value: BreakEven = breakList[holder.adapterPosition]
                if (holder.qty.text.toString().isEmpty()) {
                    val q = 0.0
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        q,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                } else {
                    val q = holder.qty.text.toString().toDouble()
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        q,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                }
            }

            override fun afterTextChanged(s: Editable) {
                val value: BreakEven = breakList[holder.adapterPosition]
                if (holder.qty.text.toString().isEmpty()) {
                    val q = 0.0
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        q,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                } else {
                    val q = holder.qty.text.toString().toDouble()
                    val newBreak: BreakEven = BreakEven(
                        value.price,
                        q,
                        value.fee,
                        value.purchase
                    )
                    AppConstant.BREAK_LIST[holder.adapterPosition] = newBreak
                }
            }
        })


        holder.delete.setOnClickListener {
            AppConstant.BREAK_LIST.removeAt(position)
            mAdapterCallback.onMethodCallback()
        }
    }

    interface AdapterCallback {
        fun onMethodCallback()
    }

    override fun getItemCount(): Int {
        return breakList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var price: EditText = itemView.findViewById<EditText>(R.id.price)
        var qty: EditText = itemView.findViewById<EditText>(R.id.qty)
        var fee: EditText = itemView.findViewById<EditText>(R.id.fee)
        var currency1: TextView = itemView.findViewById<TextView>(R.id.currency1)
        var purchaseToogle: TextView = itemView.findViewById<TextView>(R.id.purchaseToogle)
        var delete: ImageButton = itemView.findViewById<ImageButton>(R.id.delete)

        init {
            currency1.text = AppConstant.CURRENCY_SELECTED
        }
    }
}