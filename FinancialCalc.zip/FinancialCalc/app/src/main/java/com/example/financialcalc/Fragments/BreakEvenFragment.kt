package com.example.financialcalc.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Adapter.BreakEvenAdapter
import com.example.financialcalc.Helper.BreakEven
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class BreakEvenFragment : Fragment(), BreakEvenAdapter.AdapterCallback {
    private var price: EditText? = null
    private var qty: EditText? = null
    private var fee: EditText? = null
    private var purchaseToogleBoolean: Boolean = true
    private var recyclerView: RecyclerView? = null
    private var ans: LinearLayout? = null
    private var addStocks: LinearLayout? = null
    private var resetBtn: LinearLayout? = null
    private var c1: TextView? = null
    private var calculate: TextView? = null
    private var breakEvenPrice: TextView? = null
    private var purchaseToogle: TextView? = null
    private var totalSaleValue: TextView? = null
    private var totalCost: TextView? = null
    private var totalProfit: TextView? = null
    private var shareSold: TextView? = null
    private var shareOwn: TextView? = null
    private var decimals: DecimalClass? = null
    private var gridLayoutManager1: GridLayoutManager? = null
    private var breakEvenAdapter: BreakEvenAdapter? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_break_even, container, false)
        initializeView(view)

        c1?.text = AppConstant.CURRENCY_SELECTED
        addStocks!!.setOnClickListener {
            val breakEvenClass: BreakEven = BreakEven(0.0, 1.0, 0.0, true)
            AppConstant.BREAK_LIST.add(breakEvenClass)
            addNewRecycler()
        }
        calculate!!.setOnClickListener {
            if (qty!!.text.toString().isEmpty()) {
                qty!!.setText("1")
            }
            if (price!!.text.toString().isNotEmpty() && fee!!.text.toString().isNotEmpty()) {
                calculate()
            } else {
                Toast.makeText(context, "Enter All the Value", Toast.LENGTH_LONG).show()
            }
        }
        resetBtn!!.setOnClickListener {
            price!!.setText("")
            purchaseToogle!!.text = "Purchase"
            purchaseToogleBoolean = true
            qty!!.setText("1")
            fee!!.setText("")
            ans!!.visibility = View.GONE
            AppConstant.BREAK_LIST.clear()
            addNewRecycler()
        }
        purchaseToogle!!.setOnClickListener {
            if (purchaseToogleBoolean) {
                purchaseToogle!!.text = "Sold"
                purchaseToogleBoolean = false
            } else {
                purchaseToogle!!.text = "Purchase"
                purchaseToogleBoolean = true
            }
        }

        return view
    }

    private fun calculate() {
        ans!!.visibility = View.VISIBLE
        val decimal = DecimalClass()
        var breakEvenP = 0.0
        var totalCost = 0.0
        var totalSale = 0.0
        var profit = 0.0
        val returnPer = 0.0
        var shareOwned: Double = 0.0
        var shareSold = 0.0
        if (purchaseToogleBoolean) {
            shareOwned += qty!!.text.toString().toDouble()
            shareOwned += qty!!.text.toString().toDouble()
            totalCost += price?.getText().toString().toDouble() * qty?.getText().toString()
                .toDouble()
            totalCost += fee?.getText().toString().toDouble()
            breakEvenP = totalCost / shareOwned
        } else {
            shareSold += qty!!.text.toString().toDouble()
            totalSale += price?.getText().toString().toDouble() * qty?.getText().toString()
                .toDouble()
            totalSale += fee?.getText().toString().toDouble()
        }
        for (breakEvenClass in AppConstant.BREAK_LIST) {
            if (breakEvenClass.purchase) {
                shareOwned += breakEvenClass.quantity
                totalCost += breakEvenClass.price * breakEvenClass.quantity
                totalCost += breakEvenClass.fee
                breakEvenP = totalCost / shareOwned
            } else {
                shareSold += qty!!.text.toString().toDouble()
                totalSale += price?.getText().toString().toDouble() * qty?.getText().toString()
                    .toDouble()
                totalSale += fee?.getText().toString().toDouble()
            }
        }
        profit = totalSale - totalCost

        breakEvenPrice?.text =
            "${decimal.roundOfToTwo(breakEvenP)} ${AppConstant.CURRENCY_SELECTED}"
        totalSaleValue?.text = "${decimal.roundOfToTwo(totalSale)} ${AppConstant.CURRENCY_SELECTED}"
        this.totalCost?.text = "${decimal.roundOfToTwo(totalCost)} ${AppConstant.CURRENCY_SELECTED}"
        totalProfit?.text = "${decimal.roundOfToTwo(profit)} ${AppConstant.CURRENCY_SELECTED}"
        this.shareSold?.text = "${decimal.roundOfToTwo(shareSold)} ${AppConstant.CURRENCY_SELECTED}"
        shareOwn?.text = "${decimal.roundOfToTwo(shareOwned)} ${AppConstant.CURRENCY_SELECTED}"
    }

    private fun addNewRecycler() {
        breakEvenAdapter = BreakEvenAdapter(requireContext(), AppConstant.BREAK_LIST, this)
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = breakEvenAdapter
    }

    private fun initializeView(view: View) {
        AppConstant.BREAK_LIST.clear()

        price = view.findViewById<EditText>(R.id.itemName)
        qty = view.findViewById<EditText>(R.id.qty)
        fee = view.findViewById<EditText>(R.id.fee)

        recyclerView = view.findViewById<RecyclerView>(R.id.recycler)

        ans = view.findViewById(R.id.answers)
        addStocks = view.findViewById<LinearLayout>(R.id.add)

        resetBtn = view.findViewById(R.id.reset)
        shareOwn = view.findViewById<TextView>(R.id.shareOwned)
        shareSold = view.findViewById<TextView>(R.id.sharesSold)
        totalProfit = view.findViewById<TextView>(R.id.totalProfit)
        totalCost = view.findViewById<TextView>(R.id.totalCost)
        totalSaleValue = view.findViewById<TextView>(R.id.totalSale)
        breakEvenPrice = view.findViewById<TextView>(R.id.breakEven)
        purchaseToogle = view.findViewById<TextView>(R.id.purchaseToogle)
        c1 = view.findViewById<TextView>(R.id.currency1)
        calculate = view.findViewById(R.id.calculate)
        ans?.visibility = View.GONE
    }

    override fun onMethodCallback() {
        addNewRecycler()
    }
}