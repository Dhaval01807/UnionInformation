package com.example.financialcalc.Fragments

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import java.text.DateFormatSymbols
import java.util.Calendar

class SWPFragment : Fragment() {
    private var share: ShapeableImageView? = null
    private var investAmount: EditText? = null
    private var rateOfInterest: EditText? = null
    private var tenure: EditText? = null
    private var monthlyWithdrawal: EditText? = null
    private var totalAns: TextView? = null
    private var withdrawalAns: TextView? = null
    private var finalValue: TextView? = null
    private var maturityDate: TextView? = null
    private var monthToggle: TextView? = null
    private var currency1: TextView? = null
    private var currency2: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var yourFirstInvestment: TextView? = null
    private var monthlyToggleBoolean: Boolean = true
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var calender: RelativeLayout? = null
    private var instalmentDate: Calendar? = null
    private var shortMonths: Array<String> = DateFormatSymbols().shortMonths
    private var setListener: OnDateSetListener? = null


    private fun intialize(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        monthlyWithdrawal = view.findViewById(R.id.monthlyWith)
        investAmount = view.findViewById(R.id.investAmount)
        rateOfInterest = view.findViewById(R.id.rateOfInterest)
        tenure = view.findViewById(R.id.tenure)

        currency2 = view.findViewById(R.id.c2)
        yourFirstInvestment = view.findViewById(R.id.yourFirsInvestment)
        maturityDate = view.findViewById(R.id.maturityDate)
        finalValue = view.findViewById(R.id.finalValue)
        withdrawalAns = view.findViewById(R.id.wihtdrawalAns)
        totalAns = view.findViewById(R.id.totalAns)
        monthToggle = view.findViewById(R.id.month)
        currency1 = view.findViewById(R.id.oneCurrency)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE

        calender = view.findViewById(R.id.calender)
    }

    fun calculate() {
        answer!!.visibility = View.VISIBLE
        val decimal= DecimalClass()
        val tenureValue = if (monthlyToggleBoolean) {
            tenure!!.text.toString().toDouble()
        } else {
            tenure!!.text.toString().toDouble() * 12
        }
        val monthlyWithdrawalValue = monthlyWithdrawal!!.text.toString().toDouble()
        var investmentAmountValue = investAmount!!.text.toString().toDouble()
        var expectedRate = rateOfInterest!!.text.toString().toDouble()
        expectedRate = expectedRate / 1200

        totalAns?.text = (decimal.round(investmentAmountValue) + " " + AppConstant.CURRENCY_SELECTED)
        withdrawalAns?.text = (decimal.round(monthlyWithdrawalValue * tenureValue) + "" + AppConstant.CURRENCY_SELECTED)
        var interestEarned = 0.0
        var i = 1
        while (i < tenureValue) {
            investmentAmountValue -= monthlyWithdrawalValue
            interestEarned = expectedRate * (investmentAmountValue)
            investmentAmountValue += interestEarned
            i++
        }
        finalValue?.text = (decimal.round(investmentAmountValue) + " " + AppConstant.CURRENCY_SELECTED)

        var finalDate: Calendar?
        if (monthlyToggleBoolean) {
            finalDate = instalmentDate
            finalDate!!.add(Calendar.MONTH, tenure!!.text.toString().toInt())
        } else {
            finalDate = instalmentDate
            finalDate!!.add(Calendar.YEAR, tenure!!.text.toString().toInt())
        }

        maturityDate!!.text = ((finalDate[Calendar.DATE]).toString() + " "
                + shortMonths[finalDate[Calendar.MONTH]] + " " + (finalDate[Calendar.YEAR]))
        if (monthlyToggleBoolean) {
            finalDate = instalmentDate
            finalDate!!.add(Calendar.MONTH, -tenure!!.text.toString().toInt())
        } else {
            finalDate = instalmentDate
            finalDate!!.add(Calendar.YEAR, -tenure!!.text.toString().toInt())
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_s_w_p, container, false)
        intialize(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED
        currency2?.text = AppConstant.CURRENCY_SELECTED
        instalmentDate = Calendar.getInstance()
        yourFirstInvestment!!.text =
            ("Your First Withdrawal: " + (instalmentDate!!.get(Calendar.DATE)) + " "
                    + shortMonths[instalmentDate!!.get(Calendar.MONTH)] + " " + (instalmentDate!!.get(
                Calendar.YEAR
            )))
        monthToggle!!.setOnClickListener {
            if (monthlyToggleBoolean) {
                monthlyToggleBoolean = false
                monthToggle!!.text = "Yearly"
            } else {
                monthlyToggleBoolean = true
                monthToggle!!.text = "Monthly"
            }
        }
        reset!!.setOnClickListener {
            investAmount!!.setText("")
            rateOfInterest!!.setText("")
            monthlyWithdrawal?.setText("")
            monthToggle!!.text = "Months"
            monthlyToggleBoolean = true
            tenure!!.setText("")
            instalmentDate = Calendar.getInstance()
            answer!!.visibility = View.GONE
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(context, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "SWP")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (investAmount!!.text.toString().isEmpty() || rateOfInterest!!.text.toString()
                    .isEmpty()
                || tenure!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (rateOfInterest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener {
            if (investAmount!!.text.toString().isEmpty() || rateOfInterest!!.text.toString()
                    .isEmpty()
                || tenure!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (rateOfInterest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my SWP which has Maturity Value ${finalValue!!.text}
 with total Investment of ${totalAns!!.text}

 Check your SWP using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }
        calender!!.setOnClickListener {
            val datePickerDialog = DatePickerDialog(
                requireContext(),
                android.R.style.Theme_Holo_Dialog_MinWidth,
                setListener,
                instalmentDate!!.get(Calendar.YEAR),
                instalmentDate!!.get(Calendar.MONTH),
                instalmentDate!!.get(Calendar.DATE)
            )
            datePickerDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            datePickerDialog.show()
        }
        setListener = OnDateSetListener { datePicker, i, i1, i2 ->
            instalmentDate!!.set(i, i1, i2)
            yourFirstInvestment!!.text =
                ("Your first Withdrawal: " + (instalmentDate!!.get(Calendar.DATE)) + " "
                        + shortMonths[instalmentDate!!.get(Calendar.MONTH)] + " " + (instalmentDate!!.get(
                    Calendar.YEAR
                )))
        }

        return view
    }
}