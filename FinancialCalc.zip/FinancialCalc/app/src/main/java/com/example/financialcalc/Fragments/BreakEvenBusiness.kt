package com.example.financialcalc.Fragments

import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class BreakEvenBusiness : Fragment() {
    private var fixedCost: EditText? = null
    private var variableCost: EditText? = null
    private var pricePerUnit: EditText? = null
    private var bePoint: EditText? = null
    private var reset: LinearLayout? = null
    private var lock1: ImageView? = null
    private var lock2: ImageView? = null
    private var lock3: ImageView? = null
    private var lock4: ImageView? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var c3: TextView? = null
    private var lockPressed: Boolean = false
    private var decimals = DecimalClass()
    private var calculatingPart: Int = 0
    private var whichLock: Int = 0


    private fun calculation1() {
        try {
            val vc = variableCost!!.text.toString().toDouble()
            val p = pricePerUnit!!.text.toString().toDouble()
            val b = bePoint!!.text.toString().toDouble()

            val f = b * (p - vc)

            fixedCost!!.setText("" + decimals.roundOfTo(f))
        } catch (e: Exception) {
        }
    }

    private fun calculation2() {
        try {
            val f = fixedCost!!.text.toString().toDouble()
            val p = pricePerUnit!!.text.toString().toDouble()
            val b = bePoint!!.text.toString().toDouble()

            val vc = p - f / b

            variableCost!!.setText("" + decimals.roundOfTo(vc))
        } catch (e: Exception) {
        }
    }

    private fun calculation3() {
        try {
            val vc = variableCost!!.text.toString().toDouble()
            val f = fixedCost!!.text.toString().toDouble()
            val b = bePoint!!.text.toString().toDouble()

            val p = f / b + vc

            pricePerUnit!!.setText("" + decimals.roundOfTo(p))
        } catch (e: Exception) {
        }
    }

    private fun calculation4() {
        try {
            val vc = variableCost!!.text.toString().toDouble()
            val p = pricePerUnit!!.text.toString().toDouble()
            val f = fixedCost!!.text.toString().toDouble()

            val b = f / (p - vc)

            bePoint!!.setText("" + decimals.roundOfTo(b))
        } catch (e: Exception) {
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        val view: View = inflater.inflate(R.layout.fragment_break_even_business, container, false)

        initializationView(view)
        reset!!.setOnClickListener {
            fixedCost!!.setText("")
            pricePerUnit!!.setText("")
            variableCost!!.setText("")
            bePoint!!.setText("")
            fixedCost!!.isEnabled = true
            pricePerUnit!!.isEnabled = true
            variableCost!!.isEnabled = true
            calculatingPart = 0
            whichLock = 0
            bePoint!!.isEnabled = true
            lockBackGround(0)
            lockPressed = false
        }
        lock()
        textChanger()
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED
        c3?.text = AppConstant.CURRENCY_SELECTED


        return view
    }


    private fun textChanger() {

        fixedCost!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = variableCost!!.text.toString()
                val e = pricePerUnit!!.text.toString()
                val c = bePoint!!.text.toString()
                val b = fixedCost!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (bI == 1 && fixedCost!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 2
                                calculation2()
                            } else if (whichLock == 2) {
                                calculatingPart = 4
                                calculation4()
                            } else if (whichLock == 3) {
                                calculatingPart = 4
                                calculation4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculation2()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculation3()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculation4()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (pI == 0) {
                            calculatingPart = 2
                            calculation2()
                        } else if (eI == 0) {
                            calculatingPart = 3
                            calculation3()
                        } else if (cI == 0) {
                            calculatingPart = 4
                            calculation4()
                        } else {
                            calculatingPart = 4
                            calculation4()
                        }
                    }
                }
            }
        })
        variableCost!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = variableCost!!.text.toString()
                val e = pricePerUnit!!.text.toString()
                val c = bePoint!!.text.toString()
                val b = fixedCost!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (pI == 1 && variableCost!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 1
                                calculation1()
                            } else if (whichLock == 1) {
                                calculatingPart = 4
                                calculation4()
                            } else if (whichLock == 3) {
                                calculatingPart = 4
                                calculation4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculation1()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculation3()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculation4()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (bI == 0) {
                            calculatingPart = 1
                            calculation1()
                        } else if (eI == 0) {
                            calculatingPart = 3
                            calculation3()
                        } else if (cI == 0) {
                            calculatingPart = 4
                            calculation4()
                        } else {
                            calculatingPart = 4
                            calculation4()
                        }
                    }
                }
            }
        })
        pricePerUnit!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = variableCost!!.text.toString()
                val e = pricePerUnit!!.text.toString()
                val c = bePoint!!.text.toString()
                val b = fixedCost!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (eI == 1 && pricePerUnit!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            calculatingPart = when (whichLock) {
                                4 -> {
                                    calculation2()
                                    2
                                }
                                2, 1 -> {
                                    calculation4()
                                    4
                                }
                                else -> calculatingPart // No change if `whichLock` is something else
                            }
                        } else if (calculatingPart != 0) {
                            calculatingPart = when (calculatingPart) {
                                1 -> {
                                    calculation1()
                                    1
                                }
                                2 -> {
                                    calculation2()
                                    2
                                }
                                4 -> {
                                    calculation4()
                                    4
                                }
                                else -> 0
                            }
                        } else if (pI == 0) {
                            calculatingPart = 2
                            calculation2()
                        } else if (bI == 0) {
                            calculatingPart = 1
                            calculation1()
                        } else if (cI == 0) {
                            calculatingPart = 4
                            calculation4()
                        } else {
                            calculatingPart = 4
                            calculation4()
                        }
                    }
                }
            }
        })
        bePoint!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = variableCost!!.text.toString()
                val e = pricePerUnit!!.text.toString()
                val c = bePoint!!.text.toString()
                val b = fixedCost!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (cI == 1 && bePoint!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            calculatingPart = when (whichLock) {
                                1 -> {
                                    calculation2()
                                    2
                                }
                                2, 3 -> {
                                    calculation1()
                                    1
                                }
                                else -> calculatingPart
                            }
                        } else if (calculatingPart != 0) {
                            calculatingPart = when (calculatingPart) {
                                1 -> {
                                    calculation1()
                                    1
                                }
                                2 -> {
                                    calculation2()
                                    2
                                }
                                3 -> {
                                    calculation3()
                                    3
                                }
                                else -> 0
                            }
                        } else if (pI == 0) {
                            calculatingPart = 2
                            calculation2()
                        } else if (eI == 0) {
                            calculatingPart = 3
                            calculation3()
                        } else if (bI == 0) {
                            calculatingPart = 1
                            calculation1()
                        } else {
                            calculatingPart = 1
                            calculation1()
                        }
                    }
                }
            }
        })
    }

    private fun lock() {
        //lock system
        lock1!!.setOnClickListener {
            if (whichLock == 1) {
                lockPressed = false
                whichLock = 0
                fixedCost!!.isEnabled = true
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
                lock1!!.background = buttonDrawable
            } else {
                whichLock = 1
                if (fixedCost!!.text.toString().isEmpty()) {
                    fixedCost!!.setText("0")
                }
                pricePerUnit!!.isEnabled = true
                variableCost!!.isEnabled = true
                bePoint!!.isEnabled = true
                lockPressed = true
                fixedCost!!.isEnabled = false

                lockBackGround(1)
            }
        }
        lock2!!.setOnClickListener {
            if (whichLock == 2) {
                lockPressed = false
                whichLock = 0
                variableCost!!.isEnabled = true
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock2!!.background = buttonDrawable
            } else {
                whichLock = 2
                if (variableCost!!.text.toString().isEmpty()) {
                    variableCost!!.setText("0")
                }
                fixedCost!!.isEnabled = true
                pricePerUnit!!.isEnabled = true
                bePoint!!.isEnabled = true
                lockPressed = true
                variableCost!!.isEnabled = false
                lockBackGround(2)
            }
        }
        lock3!!.setOnClickListener {
            if (whichLock == 3) {
                lockPressed = false
                whichLock = 0
                pricePerUnit!!.isEnabled = true
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock3!!.background = buttonDrawable
            } else {
                whichLock = 3
                if (pricePerUnit!!.text.toString().isEmpty()) {
                    pricePerUnit!!.setText("0")
                }
                variableCost!!.isEnabled = true
                fixedCost!!.isEnabled = true
                bePoint!!.isEnabled = true
                lockPressed = true
                pricePerUnit!!.isEnabled = false
                lockBackGround(3)
            }
        }
        lock4!!.setOnClickListener {
            if (whichLock == 4) {
                whichLock = 0
                lockPressed = false
                bePoint!!.isEnabled = true
                var buttonDrawable = lock4!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock4!!.background = buttonDrawable
            } else {
                whichLock = 4
                if (bePoint!!.text.toString().isEmpty()) {
                    bePoint!!.setText("0")
                }
                variableCost!!.isEnabled = true
                fixedCost!!.isEnabled = true
                pricePerUnit!!.isEnabled = true
                lockPressed = true
                bePoint!!.isEnabled = false
                lockBackGround(4)
            }
        }
    }

    private fun initializationView(view: View) {
        fixedCost = view.findViewById<EditText>(R.id.fixedCost)
        pricePerUnit = view.findViewById<EditText>(R.id.pricePerUnit)
        variableCost = view.findViewById<EditText>(R.id.variableCost)
        bePoint = view.findViewById<EditText>(R.id.bePoint)

        lock1 = view.findViewById<ImageView>(R.id.lock1)
        lock2 = view.findViewById<ImageView>(R.id.lock2)
        lock3 = view.findViewById<ImageView>(R.id.lock3)
        lock4 = view.findViewById<ImageView>(R.id.lock4)

        c1 = view.findViewById<TextView>(R.id.c1)
        c2 = view.findViewById<TextView>(R.id.c2)
        c3 = view.findViewById<TextView>(R.id.c3)

        reset = view.findViewById(R.id.reset)
    }

    private fun lockBackGround(i: Int) {

        val locks = listOf(lock1, lock2, lock3, lock4)

        locks.forEachIndexed { index, lock ->
            lock?.background?.let { drawable ->
                val buttonDrawable = DrawableCompat.wrap(drawable)
                val color = if (i == index + 1) Color.RED else Color.parseColor("#c3c3c3")
                DrawableCompat.setTint(buttonDrawable, color)
                lock.background = buttonDrawable
            }
        }
//        if (i == 1) {
//            var buttonDrawable = lock1!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.RED)
//            lock1!!.background = buttonDrawable
//        } else {
//            var buttonDrawable = lock1!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
//            lock1!!.background = buttonDrawable
//        }
//        if (i == 2) {
//            var buttonDrawable = lock2!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.RED)
//            lock2!!.background = buttonDrawable
//        } else {
//            var buttonDrawable = lock2!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
//            lock2!!.background = buttonDrawable
//        }
//        if (i == 3) {
//            var buttonDrawable = lock3!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.RED)
//            lock3!!.background = buttonDrawable
//        } else {
//            var buttonDrawable = lock3!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
//            lock3!!.background = buttonDrawable
//        }
//        if (i == 4) {
//            var buttonDrawable = lock4!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.RED)
//            lock4!!.background = buttonDrawable
//        } else {
//            var buttonDrawable = lock4!!.background
//            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
//            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
//            lock4!!.background = buttonDrawable
//        }

    }
}