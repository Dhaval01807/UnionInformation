package com.example.financialcalc.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Adapter.SalaryAdapter
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.Helper.SalaryModel
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class SalaryIncrement : Fragment() {
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var salary: EditText? = null
    private var noYears: EditText? = null
    private var increment: EditText? = null
    private var yearly: TextView? = null
    private var monthly: TextView? = null
    private var calculate: TextView? = null
    private var c1: TextView? = null
    private var recyclerView: RecyclerView? = null
    private var salaryList: MutableList<SalaryModel> = ArrayList<SalaryModel>()
    private var gridLayoutManager1: GridLayoutManager? = null
    private var salaryAdapter: SalaryAdapter? = null

    private fun initialize(view: View) {
        answer = view.findViewById(R.id.answers)
        reset = view.findViewById(R.id.reset)

        salary = view.findViewById(R.id.annualSalary)
        noYears = view.findViewById(R.id.noOfYears)
        increment = view.findViewById(R.id.annualIncrement)

        yearly = view.findViewById(R.id.yearly)
        monthly = view.findViewById(R.id.monthly)
        calculate = view.findViewById(R.id.calculate)
        c1 = view.findViewById(R.id.oneCurrency)

        recyclerView = view.findViewById(R.id.recycler)
        answer ?.visibility = View.GONE
    }

    fun calculte() {
        val decimal= DecimalClass()
        salaryList.clear()
        answer!!.visibility = View.VISIBLE
        val number = noYears!!.text.toString().toDouble()
        val incrementDouble = increment!!.text.toString().toDouble()
        var salaryDouble = salary!!.text.toString().toDouble()
        var sumYear = salaryDouble
        var sumMonth = salaryDouble / 12
        val salaryClass: SalaryModel = SalaryModel(0, salaryDouble / 12, salaryDouble)
        salaryList.add(salaryClass)
        var i = 1
        while (i <= number) {
            salaryDouble = salaryDouble + salaryDouble * incrementDouble / 100
            sumMonth += salaryDouble / 12
            sumYear += salaryDouble
            val salaryClassNew: SalaryModel = SalaryModel(i, salaryDouble / 12, salaryDouble)
            salaryList.add(salaryClassNew)
            i++
        }
        yearly?.text = ("${decimal.roundOfTo(sumYear / (number + 1))} ${AppConstant.CURRENCY_SELECTED}")
        monthly?.text = ("${decimal.roundOfTo(sumMonth / (number + 1))} ${AppConstant.CURRENCY_SELECTED}")
        addRecycler()
    }

    fun addRecycler() {
        salaryAdapter = SalaryAdapter(requireContext(), salaryList)
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = salaryAdapter
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_salaray_increment, container, false)
        initialize(view)

        c1?.text = AppConstant.CURRENCY_SELECTED

        reset!!.setOnClickListener {
            increment!!.setText("")
            salary!!.setText("")
            noYears!!.setText("")
            answer!!.visibility = View.GONE
            salaryList.clear()
        }

        calculate!!.setOnClickListener {
            if (salary!!.text.toString().isEmpty() || increment!!.text.toString()
                    .isEmpty() || noYears!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculte()
            }
        }

        return view
    }
}