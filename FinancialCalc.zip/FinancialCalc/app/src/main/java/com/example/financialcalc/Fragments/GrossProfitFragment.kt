package com.example.financialcalc.Fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class GrossProfitFragment : Fragment() {
    private var cost: EditText? = null
    private var markUp: EditText? = null
    private var margin: EditText? = null
    private var totalAmount: EditText? = null
    private var profit: EditText? = null
    private var reset: LinearLayout? = null
    private var lock1: ImageView? = null
    private var lock2: ImageView? = null
    private var lock3: ImageView? = null
    private var lock4: ImageView? = null
    private var lock5: ImageView? = null
    private var knowMore: TextView? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var c3: TextView? = null
    private var lockPressed: Boolean = false
    private var decimals= DecimalClass()
    private var calculatingPart: Int = 0
    private var whichLock: Int = 0

    private fun calculation1() {
        try {
            val costValue = cost!!.text.toString().toDouble()
            val markUpValue = markUp!!.text.toString().toDouble()
            val profitValue = costValue * markUpValue / 100
            val totalValue = profitValue + costValue
            val marginValue = profitValue / totalValue * 100

            profit!!.setText("" + decimals.roundOfTo(profitValue))
            totalAmount!!.setText("" + decimals.roundOfTo(totalValue))
            margin!!.setText("" + decimals.roundOfTo(marginValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation2() {
        try {
            val costValue = cost!!.text.toString().toDouble()
            val marginValue = margin!!.text.toString().toDouble()
            val profitValue = costValue / (100 / marginValue - 1)
            val totalValue = profitValue + costValue
            val markUpValue = profitValue / costValue * 100

            markUp!!.setText("" + decimals.roundOfTo(markUpValue))
            totalAmount!!.setText("" + decimals.roundOfTo(totalValue))
            profit!!.setText("" + decimals.roundOfTo(profitValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation3() {
        try {
            val costValue = cost!!.text.toString().toDouble()
            val totalValue = totalAmount!!.text.toString().toDouble()
            val profitValue = totalValue - costValue
            val markupValue = profitValue / costValue * 100
            val marginValue = profitValue / totalValue * 100

            markUp!!.setText("" + decimals.roundOfTo(markupValue))
            margin!!.setText("" + decimals.roundOfTo(marginValue))
            profit!!.setText("" + decimals.roundOfTo(profitValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation4() {
        try {
            val costValue = cost!!.text.toString().toDouble()
            val profitValue = profit!!.text.toString().toDouble()
            val totalValue = profitValue + costValue
            val markupValue = profitValue / costValue * 100
            val marginValue = profitValue / totalValue * 100

            markUp!!.setText("" + decimals.roundOfTo(markupValue))
            margin!!.setText("" + decimals.roundOfTo(marginValue))
            totalAmount!!.setText("" + decimals.roundOfTo(totalValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation5(focusOnMarkup: Boolean) {
        try {
            if (focusOnMarkup) {
                if (!cost!!.text.toString().isEmpty()) {
                    calculation1()
                } else if (!totalAmount!!.text.toString().isEmpty()) {
                    calculation6()
                } else if (!profit!!.text.toString().isEmpty()) {
                    calculation7()
                } else {
                    val markUpValue = markUp!!.text.toString().toDouble()
                    val marginValue = 100 / (100 / markUpValue + 1)

                    margin!!.setText("" + decimals.roundOfTo(marginValue))
                }
            } else {
                if (cost!!.text.toString().isNotEmpty()) {
                    calculation2()
                } else if (totalAmount!!.text.toString().isNotEmpty()) {
                    calculation8()
                } else if (profit!!.text.toString().isNotEmpty()) {
                    calculation9()
                } else {
                    val marginValue = markUp!!.text.toString().toDouble()
                    val markUpValue = 100 / (100 / marginValue - 1)

                    markUp!!.setText("" + decimals.roundOfTo(markUpValue))
                }
            }
        } catch (e: Exception) {
        }
    }

    private fun calculation6() {
        try {
            val markUpValue = markUp!!.text.toString().toDouble()
            val totalValue = totalAmount!!.text.toString().toDouble()
            val costValue = totalValue * 100 / (markUpValue + 100)
            val profitValue = totalValue - costValue
            val marginValue = profitValue / totalValue * 100

            cost!!.setText("" + decimals.roundOfTo(costValue))
            margin!!.setText("" + decimals.roundOfTo(marginValue))
            profit!!.setText("" + decimals.roundOfTo(profitValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation7() {
        try {
            val markupValue = markUp!!.text.toString().toDouble()
            val profitValue = profit!!.text.toString().toDouble()
            val costValue = 100 * profitValue / markupValue
            val totalValue = profitValue + costValue
            val marginValue = profitValue / totalValue * 100

            cost!!.setText("" + decimals.roundOfTo(costValue))
            totalAmount!!.setText("" + decimals.roundOfTo(totalValue))
            margin!!.setText("" + decimals.roundOfTo(marginValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation8() {
        try {
            val marginValue = margin!!.text.toString().toDouble()
            val totalValue = totalAmount!!.text.toString().toDouble()
            val profitValue = totalValue * marginValue / 100
            val costValue = totalValue - profitValue
            val markupValue = profitValue / costValue * 100

            markUp!!.setText("" + decimals.roundOfTo(markupValue))
            cost!!.setText("" + decimals.roundOfTo(costValue))
            profit!!.setText("" + decimals.roundOfTo(profitValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation9() {
        try {
            val marginValue = margin!!.text.toString().toDouble()
            val profitValue = profit!!.text.toString().toDouble()
            val costValue = profitValue / marginValue * 100
            val totalValue = profitValue + costValue
            val markupValue = profitValue / costValue * 100


            markUp!!.setText("" + decimals.roundOfTo(markupValue))
            cost!!.setText("" + decimals.roundOfTo(costValue))
            totalAmount!!.setText("" + decimals.roundOfTo(totalValue))
        } catch (e: Exception) {
        }
    }

    private fun calculation10() {
        try {
            val totalValue = cost!!.text.toString().toDouble()
            val profitValue = totalAmount!!.text.toString().toDouble()
            val costValue = totalValue - profitValue
            val markupValue = profitValue / costValue * 100
            val marginValue = profitValue / totalValue * 100

            cost!!.setText("" + decimals.roundOfTo(costValue))
            margin!!.setText("" + decimals.roundOfTo(marginValue))
            markUp!!.setText("" + decimals.roundOfTo(markupValue))
        } catch (e: Exception) {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_gross_profit, container, false)

        instailization(view)
        reset!!.setOnClickListener {
            cost!!.setText("")
            margin!!.setText("")
            markUp!!.setText("")
            totalAmount!!.setText("")
            cost!!.isEnabled = true
            margin!!.isEnabled = true
            markUp!!.isEnabled = true
            calculatingPart = 0
            whichLock = 0
            totalAmount!!.isEnabled = true
            profit!!.isEnabled = true
            lockBackGround(0)
            lockPressed = false
            profit!!.setText("")
        }
        lock()
        textChanger()
        c1?.text = AppConstant.CURRENCY_SELECTED
        c3?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED

        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", AppConstant.BUSINESS_TITLE_lIST.get(0))
            startActivity(intent)
        }
        return view
    }

    private fun textChanger() {
        //calculating system

        cost!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (cost!!.hasFocus()) {
                    if (!cost!!.text.toString().isEmpty() && (!margin!!.text.toString()
                            .isEmpty() || !markUp!!.text.toString()
                            .isEmpty() || !profit!!.text.toString()
                            .isEmpty() || !totalAmount!!.text.toString().isEmpty())
                    ) {
                        if (lockPressed) {
                            when (whichLock) {
                                2 -> {
                                    calculatingPart = 1
                                    calculation1()
                                }

                                3 -> {
                                    calculatingPart = 2
                                    calculation2()
                                }

                                4 -> {
                                    calculatingPart = 3
                                    calculation3()
                                }

                                5 -> {
                                    calculatingPart = 4
                                    calculation4()
                                }
                            }
                        } else {
                            if (calculatingPart == 0) {
                                if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 1
                                    calculation1()
                                } else if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 2
                                    calculation2()
                                } else if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 3
                                    calculation3()
                                } else if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 4
                                    calculation4()
                                }
                            } else if (calculatingPart == 1) {
                                if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 1
                                    calculation1()
                                } else {
                                    calculateForEmpty(1)
                                }
                            } else if (calculatingPart == 2) {
                                if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 2
                                    calculation2()
                                } else {
                                    calculateForEmpty(1)
                                }
                            } else if (calculatingPart == 3) {
                                if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 3
                                    calculation3()
                                } else {
                                    calculateForEmpty(1)
                                }
                            } else if (calculatingPart == 4) {
                                if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 4
                                    calculation4()
                                } else {
                                    calculateForEmpty(1)
                                }
                            } else {
                                calculateForEmpty(1)
                            }
                        }
                    }
                }
            }
        })
        markUp!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (markUp!!.hasFocus()) {
                    if (!markUp!!.text.toString().isEmpty() && (!margin!!.text.toString()
                            .isEmpty() || !cost!!.text.toString()
                            .isEmpty() || !profit!!.text.toString()
                            .isEmpty() || !totalAmount!!.text.toString().isEmpty())
                    ) {
                        if (lockPressed) {
                            when (whichLock) {
                                1 -> {
                                    calculatingPart = 1
                                    calculation1()
                                }

                                3 -> {
                                    calculatingPart = 5
                                    calculation5(true)
                                }

                                4 -> {
                                    calculatingPart = 6
                                    calculation6()
                                }

                                5 -> {
                                    calculatingPart = 7
                                    calculation7()
                                }
                            }
                        } else {
                            if (calculatingPart == 0) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 1
                                    calculation1()
                                } else if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 6
                                    calculation6()
                                } else if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 7
                                    calculation7()
                                } else if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 5
                                    calculation5(true)
                                }
                            } else if (calculatingPart == 1) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 1
                                    calculation1()
                                } else {
                                    calculateForEmpty(2)
                                }
                            } else if (calculatingPart == 5) {
                                if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 5
                                    calculation5(true)
                                } else {
                                    calculateForEmpty(2)
                                }
                            } else if (calculatingPart == 6) {
                                if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 6
                                    calculation6()
                                } else {
                                    calculateForEmpty(2)
                                }
                            } else if (calculatingPart == 7) {
                                if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 7
                                    calculation7()
                                } else {
                                    calculateForEmpty(2)
                                }
                            } else {
                                calculateForEmpty(2)
                            }
                        }
                    }
                }
            }
        })
        margin!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (margin!!.hasFocus()) {
                    if (!margin!!.text.toString().isEmpty() && (!markUp!!.text.toString()
                            .isEmpty() || !cost!!.text.toString()
                            .isEmpty() || !profit!!.text.toString()
                            .isEmpty() || !totalAmount!!.text.toString().isEmpty())
                    ) {
                        if (lockPressed) {
                            when (whichLock) {
                                1 -> {
                                    calculatingPart = 2
                                    calculation2()
                                }

                                2 -> {
                                    calculatingPart = 5
                                    calculation5(false)
                                }

                                4 -> {
                                    calculatingPart = 8
                                    calculation8()
                                }

                                5 -> {
                                    calculatingPart = 9
                                    calculation9()
                                }
                            }
                        } else {
                            if (calculatingPart == 0) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 2
                                    calculation2()
                                } else if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 8
                                    calculation8()
                                } else if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 9
                                    calculation9()
                                } else if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 5
                                    calculation5(false)
                                }
                            } else if (calculatingPart == 2) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 2
                                    calculation2()
                                } else {
                                    calculateForEmpty(3)
                                }
                            } else if (calculatingPart == 5) {
                                if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 5
                                    calculation5(true)
                                } else {
                                    calculateForEmpty(3)
                                }
                            } else if (calculatingPart == 8) {
                                if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 8
                                    calculation8()
                                } else {
                                    calculateForEmpty(3)
                                }
                            } else if (calculatingPart == 9) {
                                if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 9
                                    calculation9()
                                } else {
                                    calculateForEmpty(3)
                                }
                            } else {
                                calculateForEmpty(3)
                            }
                        }
                    }
                }
            }
        })
        totalAmount!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (totalAmount!!.hasFocus()) {
                    if (!totalAmount!!.text.toString().isEmpty() && (!margin!!.text.toString()
                            .isEmpty() || !cost!!.text.toString()
                            .isEmpty() || !profit!!.text.toString()
                            .isEmpty() || !markUp!!.text.toString().isEmpty())
                    ) {
                        if (lockPressed) {
                            when (whichLock) {
                                1 -> {
                                    calculatingPart = 3
                                    calculation3()
                                }

                                2 -> {
                                    calculatingPart = 6
                                    calculation6()
                                }

                                3 -> {
                                    calculatingPart = 8
                                    calculation8()
                                }

                                5 -> {
                                    calculatingPart = 10
                                    calculation10()
                                }
                            }
                        } else {
                            if (calculatingPart == 0) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 3
                                    calculation3()
                                } else if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 8
                                    calculation8()
                                } else if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 6
                                    calculation6()
                                } else if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 10
                                    calculation10()
                                }
                            } else if (calculatingPart == 3) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 3
                                    calculation3()
                                } else {
                                    calculateForEmpty(4)
                                }
                            } else if (calculatingPart == 8) {
                                if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 8
                                    calculation8()
                                } else {
                                    calculateForEmpty(4)
                                }
                            } else if (calculatingPart == 6) {
                                if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 6
                                    calculation6()
                                } else {
                                    calculateForEmpty(4)
                                }
                            } else if (calculatingPart == 10) {
                                if (!profit!!.text.toString().isEmpty()) {
                                    calculatingPart = 10
                                    calculation10()
                                } else {
                                    calculateForEmpty(4)
                                }
                            } else {
                                calculateForEmpty(4)
                            }
                        }
                    }
                }
            }
        })
        profit!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (profit!!.hasFocus()) {
                    if (!profit!!.text.toString().isEmpty() && (!margin!!.text.toString()
                            .isEmpty() || !cost!!.text.toString()
                            .isEmpty() || !markUp!!.text.toString()
                            .isEmpty() || !totalAmount!!.text.toString().isEmpty())
                    ) {
                        if (lockPressed) {
                            when (whichLock) {
                                1 -> {
                                    calculatingPart = 4
                                    calculation4()
                                }

                                2 -> {
                                    calculatingPart = 7
                                    calculation7()
                                }

                                3 -> {
                                    calculatingPart = 9
                                    calculation9()
                                }

                                4 -> {
                                    calculatingPart = 10
                                    calculation10()
                                }
                            }
                        } else {
                            if (calculatingPart == 0) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 4
                                    calculation4()
                                } else if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 9
                                    calculation9()
                                } else if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 10
                                    calculation10()
                                } else if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 7
                                    calculation7()
                                }
                            } else if (calculatingPart == 4) {
                                if (!cost!!.text.toString().isEmpty()) {
                                    calculatingPart = 4
                                    calculation4()
                                } else {
                                    calculateForEmpty(5)
                                }
                            } else if (calculatingPart == 9) {
                                if (!margin!!.text.toString().isEmpty()) {
                                    calculatingPart = 9
                                    calculation9()
                                } else {
                                    calculateForEmpty(5)
                                }
                            } else if (calculatingPart == 10) {
                                if (!totalAmount!!.text.toString().isEmpty()) {
                                    calculatingPart = 10
                                    calculation10()
                                } else {
                                    calculateForEmpty(5)
                                }
                            } else if (calculatingPart == 7) {
                                if (!markUp!!.text.toString().isEmpty()) {
                                    calculatingPart = 7
                                    calculation7()
                                } else {
                                    calculateForEmpty(5)
                                }
                            } else {
                                calculateForEmpty(5)
                            }
                        }
                    }
                }
            }
        })
    }

    private fun lock() {
        //lock system
        lock1!!.setOnClickListener {
            if (whichLock == 1) {
                lockPressed = false
                whichLock = 0
                cost!!.isEnabled = true
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
                lock1!!.background = buttonDrawable
            } else {
                whichLock = 1
                if (cost!!.text.toString().isEmpty()) {
                    cost!!.setText("0")
                }
                markUp!!.isEnabled = true
                margin!!.isEnabled = true
                profit!!.isEnabled = true
                totalAmount!!.isEnabled = true
                lockPressed = true
                cost!!.isEnabled = false

                lockBackGround(1)
            }
        }
        lock2!!.setOnClickListener {
            if (whichLock == 2) {
                lockPressed = false
                whichLock = 0
                markUp!!.isEnabled = true
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock2!!.background = buttonDrawable
            } else {
                whichLock = 2
                if (markUp!!.text.toString().isEmpty()) {
                    markUp!!.setText("0")
                }
                cost!!.isEnabled = true
                margin!!.isEnabled = true
                profit!!.isEnabled = true
                totalAmount!!.isEnabled = true
                lockPressed = true
                markUp!!.isEnabled = false
                lockBackGround(2)
            }
        }
        lock3!!.setOnClickListener {
            if (whichLock == 3) {
                lockPressed = false
                whichLock = 0
                margin!!.isEnabled = true
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock3!!.background = buttonDrawable
            } else {
                whichLock = 3
                if (margin!!.text.toString().isEmpty()) {
                    margin!!.setText("0")
                }
                cost!!.isEnabled = true
                markUp!!.isEnabled = true
                profit!!.isEnabled = true
                totalAmount!!.isEnabled = true
                lockPressed = true
                margin!!.isEnabled = false
                lockBackGround(3)
            }
        }
        lock4!!.setOnClickListener {
            if (whichLock == 4) {
                whichLock = 0
                lockPressed = false
                totalAmount!!.isEnabled = true
                var buttonDrawable = lock4!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock4!!.background = buttonDrawable
            } else {
                whichLock = 4
                if (totalAmount!!.text.toString().isEmpty()) {
                    totalAmount!!.setText("0")
                }
                cost!!.isEnabled = true
                markUp!!.isEnabled = true
                margin!!.isEnabled = true
                profit!!.isEnabled = true
                lockPressed = true
                totalAmount!!.isEnabled = false
                lockBackGround(4)
            }
        }
        lock5!!.setOnClickListener {
            if (whichLock == 5) {
                whichLock = 0
                lockPressed = false
                profit!!.isEnabled = true
                var buttonDrawable = lock5!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock5!!.background = buttonDrawable
            } else {
                whichLock = 5
                if (profit!!.text.toString().isEmpty()) {
                    profit!!.setText("0")
                }
                cost!!.isEnabled = true
                margin!!.isEnabled = true
                totalAmount!!.isEnabled = true
                markUp!!.isEnabled = true
                lockPressed = true
                profit!!.isEnabled = false
                lockBackGround(5)
            }
        }
    }

    private fun instailization(view: View) {
        cost = view.findViewById<EditText>(R.id.costPrice)
        margin = view.findViewById<EditText>(R.id.margin)
        markUp = view.findViewById<EditText>(R.id.markup)
        totalAmount = view.findViewById<EditText>(R.id.sellingPrice)
        profit = view.findViewById<EditText>(R.id.profit)

        lock1 = view.findViewById(R.id.lock1)
        lock2 = view.findViewById(R.id.lock2)
        lock3 = view.findViewById(R.id.lock3)
        lock4 = view.findViewById(R.id.lock4)
        lock5 = view.findViewById<ImageView>(R.id.lock5)

        c1 = view.findViewById(R.id.one)
        c2 = view.findViewById(R.id.two)
        c3 = view.findViewById(R.id.three)

        knowMore = view.findViewById(R.id.knowMore)
        reset = view.findViewById(R.id.reset)
    }


    private fun lockBackGround(i: Int) {
        //1
        if (i == 1) {
            var buttonDrawable = lock1!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock1!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock1!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock1!!.background = buttonDrawable
        }
        //2
        if (i == 2) {
            var buttonDrawable = lock2!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock2!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock2!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock2!!.background = buttonDrawable
        }
        //3
        if (i == 3) {
            var buttonDrawable = lock3!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock3!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock3!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock3!!.background = buttonDrawable
        }
        //4
        if (i == 4) {
            var buttonDrawable = lock4!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock4!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock4!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock4!!.background = buttonDrawable
        }
        //5
        if (i == 5) {
            var buttonDrawable = lock5!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock5!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock5!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock5!!.background = buttonDrawable
        }
    }

    private fun calculateForEmpty(position: Int) {
        val c = cost!!.text.toString().isEmpty()
        val mu = markUp!!.text.toString().isEmpty()
        val mg = margin!!.text.toString().isEmpty()
        val t = totalAmount!!.text.toString().isEmpty()
        val p = profit!!.text.toString().isEmpty()

        if (position == 1) {
            if (!mu) {
                calculatingPart = 1
                calculation1()
            } else if (!mg) {
                calculatingPart = 2
                calculation2()
            } else if (!t) {
                calculatingPart = 3
                calculation3()
            } else if (!p) {
                calculatingPart = 4
                calculation4()
            } else {
                calculatingPart = 0
            }
        } else if (position == 2) {
            if (!c) {
                calculatingPart = 1
                calculation1()
            } else if (!mg) {
                calculatingPart = 5
                calculation5(true)
            } else if (!t) {
                calculatingPart = 6
                calculation6()
            } else if (!p) {
                calculatingPart = 7
                calculation7()
            } else {
                calculatingPart = 0
            }
        } else if (position == 3) {
            if (!c) {
                calculatingPart = 2
                calculation2()
            } else if (!mu) {
                calculatingPart = 5
                calculation5(false)
            } else if (!t) {
                calculatingPart = 8
                calculation8()
            } else if (!p) {
                calculatingPart = 9
                calculation9()
            } else {
                calculatingPart = 0
            }
        } else if (position == 4) {
            if (!c) {
                calculatingPart = 3
                calculation3()
            } else if (!mu) {
                calculatingPart = 6
                calculation6()
            } else if (!mg) {
                calculatingPart = 8
                calculation8()
            } else if (!p) {
                calculatingPart = 10
                calculation10()
            } else {
                calculatingPart = 0
            }
        } else if (position == 5) {
            if (!c) {
                calculatingPart = 4
                calculation4()
            } else if (!mu) {
                calculatingPart = 7
                calculation7()
            } else if (!mg) {
                calculatingPart = 9
                calculation9()
            } else if (!t) {
                calculatingPart = 10
                calculation10()
            } else {
                calculatingPart = 0
            }
        }
    }
}