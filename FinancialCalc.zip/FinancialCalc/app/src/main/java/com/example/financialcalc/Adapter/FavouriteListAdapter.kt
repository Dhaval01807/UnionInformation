package com.example.financialcalc.Adapter

import android.content.Context
import android.content.SharedPreferences
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.FavoriteListClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class FavouriteListAdapter(
    val context: Context,
    val listAdapters: List<FavoriteListClass>,
    private val mAdapterCallback: AdapterCallback
) :
    RecyclerView.Adapter<FavouriteListAdapter.ViewHolder>() {
    private var sharedPreferences: SharedPreferences? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var inflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.favorite_list_adapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val information: FavoriteListClass = listAdapters[position]
        sharedPreferences =
            context.getSharedPreferences(AppConstant.PACKAGE_NAME, Context.MODE_PRIVATE)
        holder.titleText.text = information.title
        holder.infoText.text = information.description
        holder.icon.setBackgroundResource(information.icon)
        if (information.favourite) {
            holder.fav.setBackgroundResource(R.drawable.ic_favorite)
        } else {
            holder.fav.setBackgroundResource(R.drawable.ic_favorite_border)
        }
        holder.fav.setOnClickListener {
            val info: FavoriteListClass = listAdapters[position]
            val title: String = info.title
            val detail: String = info.description
            val icon: Int = info.icon
            val favBool: Boolean = info.favourite
            val info1: FavoriteListClass = FavoriteListClass(title, detail, icon, !favBool)
            AppConstant.FAVOURITE_ALL_LIST[position] = info1
            val allPosition =
                stringToArray(sharedPreferences?.getString(AppConstant.FAVOURITE, null))
            if (!info.favourite) {
                allPosition[position] = 1
                holder.fav.setBackgroundResource(R.drawable.ic_favorite)
            } else {
                allPosition[position] = 0
                holder.fav.setBackgroundResource(R.drawable.ic_favorite_border)
            }
            sharedPreferences?.edit()?.putString(AppConstant.FAVOURITE, arrayToString(allPosition))
                ?.apply()
        }
        holder.selectorLayout.setOnClickListener {
            val info: FavoriteListClass = listAdapters[position]
            val title: String = info.title
            val detail: String = info.description
            val icon: Int = info.icon
            val favBool: Boolean = info.favourite
            val info1: FavoriteListClass = FavoriteListClass(title, detail, icon, !favBool)
            AppConstant.FAVOURITE_ALL_LIST[position] = info1
            if (info1.favourite) {
                holder.fav.setBackgroundResource(R.drawable.ic_favorite)
                mAdapterCallback.pressedFav()
            } else {
                holder.fav.setBackgroundResource(R.drawable.ic_favorite_border)
                mAdapterCallback.pressedFav()
            }
            //sharedPreference
        }
    }

    private fun arrayToString(allPosition: IntArray): String {
        var string = ""
        for (a in allPosition) {
            string += a.toString() + AppConstant.DIVIDER
        }
        return string
    }

    private fun stringToArray(string: String?): IntArray {
        if (string != null) {
            val ar: Array<String> =
                (string.split(AppConstant.DIVIDER.toRegex()).dropLastWhile { it.isEmpty() }
                    .toTypedArray())
            val array = IntArray(ar.size)
            for (i in ar.indices) {
                array[i] = ar[i].toInt()
            }
            return array
        } else {
            val array = IntArray(200)
            for (i in array.indices) {
                array[i] = 0
            }
            return array
        }
    }

    interface AdapterCallback {
        fun pressedFav()
    }


    override fun getItemCount(): Int {
        return listAdapters.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var titleText: TextView = itemView.findViewById<TextView>(R.id.title)
        var infoText: TextView = itemView.findViewById<TextView>(R.id.shortDescription)
        var selectorLayout: RelativeLayout =
            itemView.findViewById<RelativeLayout>(R.id.selectorLayout)
        var icon: ImageView = itemView.findViewById<ImageView>(R.id.iconForCalculation)
        var fav: ImageView = itemView.findViewById<ImageView>(R.id.addFav)
    }
}