package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Adapter.IrrAdapter
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import kotlin.math.pow

class IrrFragment : Fragment(), IrrAdapter.AdapterCallback {
    private var intialInvestment: EditText? = null
    private var recyclerView: RecyclerView? = null
    private var ans: LinearLayout? = null
    private var addStocks: LinearLayout? = null
    private var resetBtn: LinearLayout? = null
    private var c1: TextView? = null
    private var calculate: TextView? = null
    private var irrValue: TextView? = null
    private var npv: TextView? = null
    private var knowMore: TextView? = null
    private var decimals: DecimalClass? = null
    private var gridLayoutManager1: GridLayoutManager? = null
    private var breakEvenAdapter: IrrAdapter? = null


    private fun initializeView(view: View) {
        AppConstant.IRR_LIST.clear()

        intialInvestment = view.findViewById(R.id.investment)

        recyclerView = view.findViewById(R.id.recycler)

        ans = view.findViewById(R.id.answers)
        addStocks = view.findViewById(R.id.add)

        c1 = view.findViewById(R.id.currency1)
        resetBtn = view.findViewById(R.id.reset)
        knowMore = view.findViewById(R.id.knowMore)
        irrValue = view.findViewById(R.id.irr)
        npv = view.findViewById(R.id.npv)
        calculate = view.findViewById(R.id.calculate)
        ans ?.visibility = View.GONE
    }


    override fun onMethodCallback() {
        addnewRecycler()
    }

    private fun func(x: Double, C: List<Double>, n: Double): Double {
        var f = 0 - C[0] * x.pow(n)
        var i = 1
        while (i <= n) {
            f += C[i] * x.pow(n - i)
            i++
        }

        Log.i("Value of f=", f.toString())
        return f
    }

    private fun der(x: Double, C: List<Double>, n: Double): Double {
        var f = 0 - C[0] * x.pow(n - 1) * n
        var i = 1
        while (i <= n - 1) {
            f += C[i] * x.pow(n - i - 1) * (n - i)
            i++
        }
        Log.i("Value of f=", f.toString())
        return f
    }


    private fun calculate() {
        ans!!.visibility = View.VISIBLE
        decimals = DecimalClass()
        val C = addToArray()

        val n: Int = AppConstant.IRR_LIST.size
        var j = 1.0
        var m = 0

        var x = func(j, C, n.toDouble()) / der(j, C, n.toDouble())
        while (x >= 0.01) {
            val FX = func(j, C, n.toDouble())
            val FdX = der(j, C, n.toDouble())

            x = FX / FdX
            j = j - x
            Log.i("Value of j=", j.toString())
            m++
        }
        Toast.makeText(context, m.toString() + "", Toast.LENGTH_SHORT).show()
        var npvDouble = 0.0
        val r = (j - 1)
        val irr = (j - 1) * 100
        irrValue?.text = "${decimals?.roundOfTo(irr)} %"
        for (i in n downTo 1) {
            npvDouble += C[i]
        }
        npvDouble -= C[0]
        npv?.text = "${ decimals?.roundOfTo(npvDouble) } ${ AppConstant.CURRENCY_SELECTED }"
    }

    private fun addToArray(): List<Double> {
        val array: MutableList<Double> = ArrayList()
        array.add(intialInvestment!!.text.toString().toDouble())
        for (d in AppConstant.IRR_LIST) {
            array.add(d)
        }
        return array
    }

    private fun addnewRecycler() {
        breakEvenAdapter = IrrAdapter(requireContext(), AppConstant.IRR_LIST, this)
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = breakEvenAdapter
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_irr, container, false)
        initializeView(view)
        addStocks!!.setOnClickListener {
            AppConstant.IRR_LIST.add(0.0)
            addnewRecycler()
        }
        c1?.text = AppConstant.CURRENCY_SELECTED
        calculate!!.setOnClickListener {
            if (intialInvestment!!.text.toString().isEmpty()) {
                intialInvestment!!.setText("0")
            }
            calculate()
        }
        resetBtn!!.setOnClickListener {
            intialInvestment!!.setText("")
            ans!!.visibility = View.GONE
            AppConstant.IRR_LIST.clear()
            addnewRecycler()
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "IRR Calculator")
            startActivity(intent)
        }
        return view
    }
}