package com.example.financialcalc.Activitys

import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Adapter.NewAppAdapter
import com.example.financialcalc.Helper.MyApp
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.initialization.InitializationStatus
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.firebase.firestore.FirebaseFirestore

class MoreAppScreen : AppCompatActivity() {
    private var moreAppView: RecyclerView? = null
    private var moreAppDatabase: FirebaseFirestore = FirebaseFirestore.getInstance()
    private var moreAppAdapter: NewAppAdapter? = null
    private var sharedPref: SharedPreferences? = null
    private var openedInInt: Int = 0
    private var mInterstitialAd: InterstitialAd? = null
    private var NUMBER_OF_TIME_OPENED: String = "NUMBER OF TIME"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_more_app_screen)
        moreAppView = findViewById(R.id.list)
        sharedPref =
            applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)
        openedInInt = sharedPref?.getInt(NUMBER_OF_TIME_OPENED, 0)?:0

        if (!AppConstant.LIGHT_THEME) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }

        MobileAds.initialize(this, object : OnInitializationCompleteListener {
            override fun onInitializationComplete(initializationStatus: InitializationStatus) {
                if (!AppConstant.PURCHASE_STATUS) {
                }
            }
        })


        moreAppClicked()
    }


    private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        try {
            // Locate the view that will hold the headline, set its text, and call the
            // NativeAdView's setHeadlineView method to register it.
            val container = findViewById<FrameLayout>(R.id.nativeAds)
            container.visibility = View.VISIBLE
            val headlineView: TextView = adView.findViewById(R.id.heading)
            headlineView.text=nativeAd.headline
            adView.headlineView = headlineView


            val body: TextView = adView.findViewById(R.id.body)
            if (!nativeAd.body.equals(null)) {
                body.text = nativeAd.body
                adView.bodyView = body
            }

            val starRating: RatingBar = adView.findViewById(R.id.start_rating)
            if (nativeAd.starRating != null) {
                starRating.rating = nativeAd.starRating?.toFloat()?:0f
                adView.starRatingView = starRating
            }

            val advitisor: TextView = adView.findViewById(R.id.advertisername)
            if (nativeAd.advertiser != null) {
                advitisor.text = nativeAd.advertiser
                adView.advertiserView = advitisor
            }

            val icon: ImageView = adView.findViewById(R.id.adicon)
            if (nativeAd.icon != null) {
                icon.setImageDrawable(nativeAd.icon?.drawable)
                adView.iconView = icon
            }

            val button: Button = adView.findViewById(R.id.calltoaction)
            if (nativeAd.callToAction != null) {
                button.text = nativeAd.callToAction
                adView.callToActionView = button
            }

            val mediaView: MediaView = adView.findViewById(R.id.media_view)
            adView.mediaView = mediaView

            adView.setNativeAd(nativeAd)

            container.removeAllViews()

            container.addView(adView)
        } catch (e: Exception) {
        }
    }

    private fun moreAppClicked() {
        val appList: MutableList<MyApp> = ArrayList<MyApp>()

        moreAppDatabase.collection("More Apps")
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    for (documentSnapshot in task.result!!) {
                        val newApp: MyApp = MyApp(
                            documentSnapshot.id.toString(),
                            documentSnapshot.get("playstoreLink").toString(),
                            documentSnapshot.get("icon").toString(),
                            documentSnapshot.get("shortDiscription").toString()
                        )
                        appList.add(newApp)
                    }
                    moreAppAdapter = NewAppAdapter(this@MoreAppScreen, appList)
                    val gridLayoutManager2 =
                        GridLayoutManager(this@MoreAppScreen, 1, GridLayoutManager.VERTICAL, false)

                    moreAppView!!.layoutManager = gridLayoutManager2
                    moreAppView!!.adapter = moreAppAdapter
                    moreAppView!!.visibility = View.VISIBLE
                } else {
                    Log.e("TAG", "Error getting documents.", task.exception)

                    Toast.makeText(
                        this@MoreAppScreen,
                        "Something went wrong !!",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            }
    }



    override fun onBackPressed() {
        super.onBackPressed()
    }
}