package com.example.financialcalc.Fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant


class OperativeMarginFragment : Fragment() {
    private var reset: LinearLayout? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var c3: TextView? = null
    private var knowMore: TextView? = null
    private var operatingIncome: EditText? = null
    private var revenue: EditText? = null
    private var operatingMargin: EditText? = null
    private var lock1: ImageView? = null
    private var lock2: ImageView? = null
    private var lock3: ImageView? = null
    private var sectionCalculating: String = ""
    private var lock1Bool: Boolean = false
    private var lock2Bool: Boolean = false
    private var lock3Bol: Boolean = false
    private var decimals: DecimalClass? = null

    fun initializeView(view: View) {
        reset = view.findViewById(R.id.reset)

        c1 = view.findViewById(R.id.oneCurrency)
        c2 = view.findViewById(R.id.two)
        c3 = view.findViewById(R.id.three)
        knowMore = view.findViewById(R.id.knowMore)

        operatingIncome = view.findViewById(R.id.operatingIncome)
        revenue = view.findViewById(R.id.revenue)
        operatingMargin = view.findViewById(R.id.operatingMargin)

        lock1 = view.findViewById(R.id.lock1)
        lock2 = view.findViewById(R.id.lock2)
        lock3 = view.findViewById(R.id.lock3)
    }

    private fun calculateOne() {
        try {
            val oi = revenue!!.text.toString().toDouble() * operatingIncome!!.text.toString()
                .toDouble() / 100
            operatingIncome?.setText (java.lang.String.valueOf(decimals?.roundOfTo(oi)))
        } catch (e: Exception) {
        }
    }

    private fun calculateThree() {
        try {
            val op = operatingIncome!!.text.toString().toDouble() / revenue!!.text.toString()
                .toDouble() * 100
            operatingMargin?.setText (java.lang.String.valueOf(decimals?.roundOfTo(op)))
        } catch (e: Exception) {
        }
    }

    private fun calculateTwo() {
        try {
            val r = operatingIncome!!.text.toString().toDouble() / operatingMargin!!.text.toString()
                .toDouble() * 100
            revenue?.setText(java.lang.String.valueOf(decimals?.roundOfTo(r)))
        } catch (e: Exception) {
        }
    }

    fun textOnChangeListener() {
        operatingIncome!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (!lock2Bool || !lock3Bol) {
                    if (operatingIncome!!.hasFocus()) {
                        if (!operatingIncome!!.text.toString()
                                .isEmpty() && (!revenue!!.text.toString()
                                .isEmpty() || !operatingMargin!!.text.toString().isEmpty())
                        ) {
                            if (lock2Bool) {
                                sectionCalculating = "3"
                                calculateThree()
                            } else if (lock3Bol) {
                                sectionCalculating = "2"
                                calculateTwo()
                            } else {
                                if (sectionCalculating.isEmpty()) {
                                    if (operatingMargin!!.text.toString().isEmpty()) {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    } else {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    }
                                } else if (sectionCalculating == "3") {
                                    if (!revenue!!.text.toString().isEmpty()) {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                } else {
                                    if (!operatingMargin!!.text.toString().isEmpty()) {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })

        revenue!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (!lock1Bool || !lock3Bol) {
                    if (revenue!!.hasFocus()) {
                        if (!revenue!!.text.toString()
                                .isEmpty() && (!operatingIncome!!.text.toString()
                                .isEmpty() || !operatingMargin!!.text.toString().isEmpty())
                        ) {
                            if (lock3Bol) {
                                sectionCalculating = "1"
                                calculateOne()
                            } else if (lock1Bool) {
                                sectionCalculating = "3"
                                calculateThree()
                            } else {
                                if (sectionCalculating.isEmpty()) {
                                    if (operatingIncome!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    }
                                } else if (sectionCalculating == "1") {
                                    if (!operatingMargin!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                } else {
                                    if (!operatingIncome!!.text.toString().isEmpty()) {
                                        sectionCalculating = "3"
                                        calculateThree()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })

        operatingMargin!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                if (!lock1Bool || !lock2Bool) {
                    if (operatingMargin!!.hasFocus()) {
                        if (!operatingMargin!!.text.toString()
                                .isEmpty() && (!revenue!!.text.toString()
                                .isEmpty() || !operatingIncome!!.text.toString().isEmpty())
                        ) {
                            if (lock1Bool) {
                                sectionCalculating = "2"
                                calculateTwo()
                            } else if (lock2Bool) {
                                sectionCalculating = "1"
                                calculateOne()
                            } else {
                                if (sectionCalculating.isEmpty()) {
                                    if (operatingIncome!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    }
                                } else if (sectionCalculating == "1") {
                                    if (!revenue!!.text.toString().isEmpty()) {
                                        sectionCalculating = "1"
                                        calculateOne()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                } else {
                                    if (!operatingIncome!!.text.toString().isEmpty()) {
                                        sectionCalculating = "2"
                                        calculateTwo()
                                    } else {
                                        sectionCalculating = ""
                                    }
                                }
                            }
                        }
                    }
                }
            }
        })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_operative_margin, container, false)
        initializeView(view)
        textOnChangeListener()
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED
        c3?.text = AppConstant.CURRENCY_SELECTED

        decimals = DecimalClass()
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Operating Margin")
            startActivity(intent)
        }

        reset!!.setOnClickListener {
            sectionCalculating = ""
            operatingIncome!!.setText("")
            revenue!!.setText("")
            operatingMargin!!.setText("")
            operatingIncome!!.isEnabled = true
            revenue!!.isEnabled = true
            operatingMargin!!.isEnabled = true
            lock1!!.isEnabled = true
            lock2!!.isEnabled = true
            lock3!!.isEnabled = true
            lock3Bol = false
            lock1Bool = false
            lock2Bool = false
            var buttonDrawable1 = lock1!!.background
            buttonDrawable1 = DrawableCompat.wrap(buttonDrawable1!!)
            DrawableCompat.setTint(buttonDrawable1, Color.parseColor("#c3c3c3"))
            var buttonDrawable2 = lock2!!.background
            buttonDrawable2 = DrawableCompat.wrap(buttonDrawable2!!)
            DrawableCompat.setTint(buttonDrawable2, Color.parseColor("#c3c3c3"))
            var buttonDrawable3 = lock3!!.background
            buttonDrawable3 = DrawableCompat.wrap(buttonDrawable3!!)
            DrawableCompat.setTint(buttonDrawable3, Color.parseColor("#c3c3c3"))
            lock1!!.background = buttonDrawable1
            lock2!!.background = buttonDrawable2
            lock3!!.background = buttonDrawable3
        }

        textOnChangeListener()

        lockClicked()



        return view
    }


    private fun lockClicked() {
        lock1!!.setOnClickListener {
            if (lock1Bool) {
                operatingIncome!!.isEnabled = true
                lock1Bool = false
                lock2!!.isEnabled = true
                lock3!!.isEnabled = true
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
                lock1!!.background = buttonDrawable
            } else {
                if (operatingIncome!!.text.toString().isEmpty()) {
                    operatingIncome!!.setText("0")
                }
                lock1Bool = true
                revenue!!.isEnabled = true
                operatingMargin!!.isEnabled = true
                operatingIncome!!.isEnabled = false
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.RED)
                lock1!!.background = buttonDrawable
                lockBackGround(1)
            }
        }
        lock2!!.setOnClickListener {
            if (lock2Bool) {
                lock2Bool = false
                revenue!!.isEnabled = true
                lock1!!.isEnabled = true
                lock3!!.isEnabled = true
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#C3C3C3")
                )
                lock2!!.background = buttonDrawable
            } else {
                if (revenue!!.text.toString().isEmpty()) {
                    revenue!!.setText("0")
                }
                operatingIncome!!.isEnabled = true
                operatingMargin!!.isEnabled = true
                lock2Bool = true
                revenue!!.isEnabled = false
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable!!, Color.RED)
                lock2!!.background = buttonDrawable
                lockBackGround(2)
            }
        }
        lock3!!.setOnClickListener {
            if (lock3Bol) {
                lock3Bol = false
                operatingMargin!!.isEnabled = true
                lock2!!.isEnabled = true
                lock1!!.isEnabled = true
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock3!!.background = buttonDrawable
            } else {
                if (operatingMargin!!.text.toString().isEmpty()) {
                    operatingMargin!!.setText("0")
                }
                operatingIncome!!.isEnabled = true
                revenue!!.isEnabled = true
                lock3Bol = true
                operatingMargin!!.isEnabled = false
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable!!, Color.RED)
                lock3!!.background = buttonDrawable
                lockBackGround(3)
            }
        }
    }


    private fun lockBackGround(i: Int) {
        //1
        val locks = listOf(lock1, lock2, lock3)
        val colors = listOf(Color.RED, Color.parseColor("#c3c3c3"))

        locks.forEachIndexed { index, lock ->
            val color = if (index + 1 == i) colors[0] else colors[1]
            val buttonDrawable = DrawableCompat.wrap(lock!!.background)
            DrawableCompat.setTint(buttonDrawable, color)
            lock.background = buttonDrawable
        }
    }
}