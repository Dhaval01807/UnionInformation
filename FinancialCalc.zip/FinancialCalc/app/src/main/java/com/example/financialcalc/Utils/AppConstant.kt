package com.example.financialcalc.Utils

import com.example.financialcalc.Helper.AverageClass
import com.example.financialcalc.Helper.BreakEven
import com.example.financialcalc.Helper.BusinessForecast
import com.example.financialcalc.Helper.DepreciationClass
import com.example.financialcalc.Helper.DiscountListClass
import com.example.financialcalc.Helper.FavoriteListClass
import com.example.financialcalc.Helper.ListAdapterModel
import com.example.financialcalc.R

class AppConstant {
   companion object{
       var EMAIL_ADDRESS: String = "appdesign327@gmail.com"
       var LIGHT_THEME: Boolean = true
       var PACKAGE_NAME: String = "com.Codecanyon.financialcalculator"
       var THEME: String = "Theme"
       var PLAYSTORE_LINK: String = "https://play.google.com/store/apps/details?id=com.Pro.Loan.finance.EMI.Calculator.appteam"
       var privacyLink :String = "https://google.com"
       var BANK_TITLE_lIST: Array<String> = arrayOf(
           "Loan Eligibility", "Compare Loan",
           "FD", "RD",
           "Saving", "Loan to Deposit Ratio",
           "Credit Card PayOff", "Accounting",
           "Types of Banks", "Auditing", "Loans"
       )

       var BANK_ICON_LIST: IntArray = intArrayOf(
           R.drawable.ic_load_hand,
           R.drawable.ic_exchange, R.drawable.ic_fd_icon,
           R.drawable.ic_rd_icon, R.drawable.ic_piggy_bank,
           R.drawable.ic_percentage, R.drawable.ic_atm_card,
           R.drawable.ic_load_hand, R.drawable.ic_bank_color,
           R.drawable.ic_aduting, R.drawable.ic_coin
       )

       var BANK_INFO_lIST: Array<String> = arrayOf(
           "Check your Loan eligibility by this calculator.",
           "Compare Between two loans",
           "Calculate your FD deposits Maturity",
           "Calculate your RD deposits Maturity",
           "Calculate your savings",
           "Check your loan to deposit ratio",
           "Check your credit car Payoff",
           "Theory",
           "Theory",
           "Theory",
           "Theory"
       )


       var BUSINESS_TITLE_lIST: Array<String> = arrayOf(
           "Gross Profit",
           "Cost of Goods Sold",
           "Discount Calculator",
           "Break Even Point",
           "Margin Calculator",
           "Operating Margin",
           "Effective Interest Rate",
           "NPV Calculator",
           "Business Forecast",
           "BCG Matrix",
           "SWOT Analysis",
           "Product Lifecycle",
           "Change Curve",
           "Pyramid of Result",
       )

       var BUSINESS_ICON_LIST: IntArray = intArrayOf(
           R.drawable.ic_aduting,
           R.drawable.ic_coin, R.drawable.ic_percentage,
           R.drawable.ic_weigh, R.drawable.ic_percentage,
           R.drawable.ic_percentage, R.drawable.ic_percentage,
           R.drawable.ic_npv, R.drawable.ic_stick,
           R.drawable.ic_bcg, R.drawable.ic_swot,
           R.drawable.ic_reset_black, R.drawable.ic_graphcurve, R.drawable.ic_pyramid
       )

       var BUSINESS_INFO_lIST: Array<String> = arrayOf(
           "Calculate the Gross Profit",
           "Calculate the direct costs related to the production of the goods sold in a company.",
           "Know how much discount you are giving",
           "Check the no profit no Loss Statement",
           "Check the Margin of the goods sold",
           "Calculate the Operating Margin",
           "Calculate the Effective Interest Rate",
           "Calculate the Net Present Value of an investment with an unlimited number of cash flows.",
           "Predict your Future Business Revenue",
           "Theory",
           "Theory",
           "Theory",
           "Theory",
           "Theory"
       )


       var FINANCE_TITLE_lIST: Array<String> = arrayOf(
           "PPF", "Simple & Compound Interest",
           "SWP", "SIP", "Lumpsum", "EMI",
           "Mortgage Calculator",
           "Tax", "TVM Calculator", "Bond Calculation",
           "Salary Increment", "Depreciation Calculation",
           "IRR Calculator", "Cash Flow", "Bond Valuation",
           "Security Market Efficiency & Return", "Capital Structure"
       )

       var FINANCE_ICON_LIST: IntArray = intArrayOf(
           R.drawable.ic_ppf, R.drawable.ic_percentage,
           R.drawable.ic_stick_reverse, R.drawable.ic_stick,
           R.drawable.ic_candle_sticl, R.drawable.ic_emi,
           R.drawable.ic_aduting, R.drawable.ic_tax,
           R.drawable.ic_tvm, R.drawable.ic_piggy_bank,
           R.drawable.ic_stick, R.drawable.ic_stick_reverse,
           R.drawable.ic_irr, R.drawable.ic_money,
           R.drawable.ic_coin, R.drawable.ic_shield,
           R.drawable.ic_bank_color, R.drawable.ic_bank
       )

       var FINANCE_INFO_lIST: Array<String> = arrayOf(
           "Calculate yor PPF Maturity Value",
           "Check the interest Value",
           "Check how to withdraw a certain amount of money at regular intervals",
           "Check the return value of mutual fund investment",
           "Calculate the future value of your lumpsum investment",
           "Calculate the EMI value for your loan",
           "Use this calculator to estimate monthly mortgage payments",
           "Calculate your tax",
           "Check the future value of your current amount",
           "Calculate Bond Price and the Yield-to-Maturity and Yield-to-Call on Bonds.",
           "Predict your salary",
           "Calculate your Depreciation",
           "Calculate the internal rate of return and measure the profitability of an investment.",
           "Theory",
           "Theory",
           "Theory",
           "Theory",
           "Theory"
       )


       var STOCK_TITLE_lIST: Array<String> = arrayOf(
           "Stock Return & Capital Gain", "Stock Break Even & Profit",
           "Stock Price Average Calculation", "PE Ratio",
           "Pivot Points", "Fibonacci Level",
           "Share Market", "What is Bull & Bear Market",
           "Top Down Bottom Up Approach"
       )

       var STOCK_ICON_LIST: IntArray = intArrayOf(
           R.drawable.ic_percentage, R.drawable.ic_weigh,
           R.drawable.ic_load_hand, R.drawable.ic_pe,
           R.drawable.ic_coin, R.drawable.ic_lever,
           R.drawable.ic_candle_sticl, R.drawable.ic_stick,
           R.drawable.ic_up_down
       )

       var STOCK_INFO_lIST: Array<String> = arrayOf(
           "Calculate the Stock Return & Capital Gain",
           "Calculate the no profit no loss point in Stock",
           "Check the Average value of your stocks ",
           "Calculate the Price to Earn ratio",
           "Calculate the Pivot Point",
           "Technical Analysis for determining support and resistance levels through Fibonacci retracement",
           "Theory",
           "Theory",
           "Theory"
       )


       var FAVOURITE_LIST: MutableList<ListAdapterModel> = mutableListOf<ListAdapterModel>()

       var FAVOURITE_ALL_LIST: MutableList<FavoriteListClass> = mutableListOf<FavoriteListClass>()

       var FAVOURITE: String = "FAVOURITE"

       var DIVIDER: String = ","



       var FIREBASE_LINK: String = "https://ghggh-c635d-default-rtdb.firebaseio.com/"


       var CURRENCY_SELECTED: String = "₹"

       var OnBoardingStatus : String  = "showOnBoarding"
       var onPrivacyStatus : String  = "showPrivacy"
       var onPermissionStatus : String  = "showPermission"

       var CURRENCY: String = "CURRENCY"

       //PURCHASE//

       var PRODUCT_ID: String = "remove_ads"

       var GOOGLE_PLAY_LICENSE: String =
           "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAgXmPGingTfiAaoWD1W3/SiXguXUuNMeicwfTAwEDrJfZ7SuHZKJLPYL51uOIR9hBkflQyqAkuJfwxHA+X+MPNbMxhlOEf/zWPndcrp0rohGabUemYm4C2g8/oaBnxrk8EjQi97PCt/c/oaVBQOohF+0bNdNw5QvmNsm7yjT9Y8bSS/mQ7BEntWWA4xTsOTLfmsTsEa6YPD/NOY7JfanrtFvERHyWJ1TcdOwUXps1YWYp96xrKJkD1AS30sREAgQa5YW+OsPAo2kAdcr63qm92mLm+oaVrapwqwyFruXIy7DpKN19MrpgO1VqEVpZFHsbdJIOYfe4n1l7/7D1b3uPlwIDAQAB"

       var PURCHASE_STATUS: Boolean = true



       var YOUTUBE_LINK: String = "https://www.youtube.com/channel/UCsejxapLU_Ia1NFpwNXto1Q"

       var INSTAGRAM_LINK: String = "https://www.instagram.com/_arpa_studio/"

       var LINKDIN_LINK: String = "https://www.linkedin.com/in/aneesh-anchan/"

       var FACEBOOK_LINK: String = "https://m.facebook.com/arpa1212/"

       var TWITTER_LINK: String = "https://twitter.com/ArpaLtd/"


       var IRR_LIST: MutableList<Double> = mutableListOf()

       var NPV_LiST: MutableList<Double> = mutableListOf()

       var BREAK_LIST: MutableList<BreakEven> = mutableListOf<BreakEven>()

       var DISCOUNT_LIST: MutableList<DiscountListClass> = mutableListOf<DiscountListClass>()

       var DEPRECIATION_LIST: MutableList<DepreciationClass> = mutableListOf<DepreciationClass>()

       var AVERAGE_CALCULATION: MutableList<AverageClass> = mutableListOf<AverageClass>()

       var BUISSNESS_FORECASTE_LIST: MutableList<BusinessForecast> = mutableListOf<BusinessForecast>()

       var interstitialAdCount:Int = 1
   }

}