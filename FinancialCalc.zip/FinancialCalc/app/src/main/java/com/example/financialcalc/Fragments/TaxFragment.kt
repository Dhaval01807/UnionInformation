package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView

class TaxFragment : Fragment(), AdapterView.OnItemSelectedListener {
    private var share: ShapeableImageView? = null
    private var amount: EditText? = null
    private var rateOfTax: EditText? = null
    private var netAmount: TextView? = null
    private var gstAmount: TextView? = null
    private var totalAmount: TextView? = null
    private var currency1: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var spiner: Spinner? = null
    private var spinner: MutableList<String> = ArrayList()
    private var choosen: String = "GST is Added"


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_tax, container, false)
        intitalize(view)

        spinner.add("GST is Added")
        spinner.add("GST is Removed")
        currency1?.text = AppConstant.CURRENCY_SELECTED
        val dataAdapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, spinner)
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spiner!!.adapter = dataAdapter
        spiner!!.onItemSelectedListener = this

        reset!!.setOnClickListener {
            amount!!.setText("")
            rateOfTax!!.setText("")
            answer!!.visibility = View.GONE
        }

        knowMore!!.setOnClickListener {
            val intent = Intent(context, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Tax")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (amount!!.text.toString().isEmpty() || rateOfTax!!.text.toString().isEmpty()) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (rateOfTax!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener {
            if (amount!!.text.toString().isEmpty() || rateOfTax!!.text.toString().isEmpty()) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (rateOfTax!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my Tax which has added ${spiner!!.transitionName}
 with GST Amount of ${gstAmount!!.text}

 Check your Tax using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }
        return view
    }

    fun intitalize(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        amount = view.findViewById(R.id.amount)
        rateOfTax = view.findViewById(R.id.interst)

        netAmount = view.findViewById(R.id.netAmount)
        gstAmount = view.findViewById(R.id.gstAmount)
        totalAmount = view.findViewById(R.id.totalAmount)
        spiner = view.findViewById(R.id.spinner)

        currency1 = view.findViewById(R.id.oneCurrency)
        knowMore = view.findViewById(R.id.knowMore)
        knowMore ?.visibility = View.GONE
        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE
    }

    fun calculate() {
        answer!!.visibility = View.VISIBLE
        var t = 0.0
        var gsta = 0.0
        var n = 0.0
        val am = amount!!.text.toString().toDouble()
        val gst = rateOfTax!!.text.toString().toDouble()
        if (choosen.contentEquals("GST is Added")) {
            t = am
            gsta = (gst * am) / (100 + gst)
            n = am - gsta
        } else {
            gsta = gst * am / 100
            n = am
            t = am + gsta
        }
        val decimal= DecimalClass()

        gstAmount?.text = (decimal.round(gsta) + " " + AppConstant.CURRENCY_SELECTED)

        netAmount?.text = (decimal.round(n) + " " + AppConstant.CURRENCY_SELECTED)

        totalAmount?.text = (decimal.round(t) + " " + AppConstant.CURRENCY_SELECTED)
    }


    override fun onItemSelected(adapterView: AdapterView<*>, view: View, i: Int, l: Long) {
        choosen = adapterView.getItemAtPosition(i).toString()
    }

    override fun onNothingSelected(adapterView: AdapterView<*>?) {
    }
}