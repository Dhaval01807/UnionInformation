package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Adapter.DepreciationAdapter
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.Helper.DepreciationClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class DepreciateFragment : Fragment(), AdapterView.OnItemSelectedListener {
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var depreciateLayout: LinearLayout? = null
    private var assetCost: EditText? = null
    private var salvageVale: TextView? = null
    private var depreciationYear: EditText? = null
    private var depreciationFactor: EditText? = null
    private var spinner: Spinner? = null
    private var yearly: TextView? = null
    private var monthly: TextView? = null
    private var calculate: TextView? = null
    private var knowMore: TextView? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var depreciationFactorTxt: TextView? = null
    private var recyclerView: RecyclerView? = null
    private var gridLayoutManager1: GridLayoutManager? = null
    private var depreciationClass: DepreciationClass? = null
    private var depreciationMethodArray: MutableList<String> = ArrayList()
    private var selected: Int = 0

    private fun initialize(view: View) {
        answer = view.findViewById(R.id.answers)
        reset = view.findViewById(R.id.reset)

        spinner = view.findViewById(R.id.method)

        salvageVale = view.findViewById(R.id.salvageValue)
        assetCost = view.findViewById(R.id.assetCost)
        depreciationFactor = view.findViewById(R.id.depreciationFactor)
        depreciationYear = view.findViewById(R.id.depreciationYears)

        yearly = view.findViewById<TextView>(R.id.yearly)
        monthly = view.findViewById<TextView>(R.id.monthly)
        calculate = view.findViewById(R.id.calculate)
        knowMore = view.findViewById(R.id.knowMore)
        c1 = view.findViewById(R.id.oneCurrency)
        c2 = view.findViewById(R.id.twoCurrency)
        depreciationFactorTxt = view.findViewById(R.id.depriciatingTxt)

        depreciateLayout = view.findViewById(R.id.depriciatingLayout)

        recyclerView = view.findViewById(R.id.recycler)
        answer ?.visibility = View.GONE
    }

    fun calculate() {
        val decimal= DecimalClass()
        AppConstant.DEPRECIATION_LIST.clear()
        answer!!.visibility = View.VISIBLE
        val assetsDouble = assetCost!!.text.toString().toDouble()
        val savlageDouble = salvageVale!!.text.toString().toDouble()
        val time = depreciationYear!!.text.toString().toDouble()
        var beginningDouble = assetCost!!.text.toString().toDouble()
        var endDouble = 0.0
        var depPerDouble = 0.0
        var depAccumDouble = 0.0
        var depAmountDouble = 0.0
        if (selected == 0) {
            depAmountDouble = (assetsDouble - savlageDouble) / time
            depPerDouble = depAmountDouble / 100
            beginningDouble += depAmountDouble
            var i = 1
            while (i <= time) {
                beginningDouble -= depAmountDouble
                endDouble = beginningDouble - depAmountDouble
                depAccumDouble += depAmountDouble
                val depreciationClass: DepreciationClass = DepreciationClass(
                    i,
                    beginningDouble,
                    endDouble,
                    depPerDouble,
                    depAmountDouble,
                    depAccumDouble
                )
                AppConstant.DEPRECIATION_LIST.add(depreciationClass)
                i++
            }
        } else if (selected == 1) {
            if (depreciationFactor!!.text.toString().isEmpty()) {
                depreciationFactor!!.setText("0")
            }
            val depFactor = depreciationFactor!!.text.toString().toDouble()
            depPerDouble = depFactor * 100 / time
            beginningDouble += depAmountDouble
            var i = 1
            while (i <= time) {
                beginningDouble -= depAmountDouble
                depAmountDouble = beginningDouble * depPerDouble / 100
                endDouble = beginningDouble - depAccumDouble
                depAccumDouble += depAmountDouble
                val depreciationClass: DepreciationClass = DepreciationClass(
                    i,
                    beginningDouble,
                    endDouble,
                    depPerDouble,
                    depAmountDouble,
                    depAccumDouble
                )
                AppConstant.DEPRECIATION_LIST.add(depreciationClass)
                i++
            }
        } else {
            beginningDouble += depAmountDouble
            var yearDenominator = 0
            run {
                var i = 1
                while (i <= time) {
                    yearDenominator += i
                    i++
                }
            }
            var i = 0
            while (i < time) {
                beginningDouble -= depAmountDouble
                depAmountDouble = (assetsDouble - savlageDouble) * (time - i) / yearDenominator
                depPerDouble = depAmountDouble / 100
                endDouble = beginningDouble - depAccumDouble
                depAccumDouble += depAmountDouble
                val depreciationClass: DepreciationClass = DepreciationClass(
                    i,
                    beginningDouble,
                    endDouble,
                    depPerDouble,
                    depAmountDouble,
                    depAccumDouble
                )
                AppConstant.DEPRECIATION_LIST.add(depreciationClass)
                i++
            }
        }
        addRecycler()
    }

    fun addRecycler() {
        val depreciationAdpater: DepreciationAdapter =
            DepreciationAdapter(requireContext(), AppConstant.DEPRECIATION_LIST)
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = depreciationAdpater
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view: View = inflater.inflate(R.layout.fragment_depreciate, container, false)
        initialize(view)
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED
        reset!!.setOnClickListener {
            assetCost!!.setText("")
            salvageVale!!.text = ""
            depreciationYear!!.setText("")
            depreciationFactor!!.setText("")
            salvageVale!!.text = ""
            AppConstant.DEPRECIATION_LIST.clear()
            answer!!.visibility = View.GONE
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Depreciation Calculation")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (salvageVale!!.text.toString().isEmpty() || assetCost!!.text.toString()
                    .isEmpty() || depreciationYear!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
            }
        }

        depreciationMethodArray.add("Straight Line")
        depreciationMethodArray.add("Declining Balance")
        depreciationMethodArray.add("Sum of the Years Digit")

        val dataAdapter =
            ArrayAdapter(requireActivity(), android.R.layout.simple_spinner_item, depreciationMethodArray)
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner!!.adapter = dataAdapter
        spinner!!.onItemSelectedListener = this

        return view
    }

    override fun onItemSelected(adapterView: AdapterView<*>?, view: View, i: Int, l: Long) {
        selected = i
        if (selected == 1) {
            depreciateLayout!!.visibility = View.VISIBLE
            depreciationFactorTxt!!.visibility = View.VISIBLE
        } else {
            depreciateLayout!!.visibility = View.GONE
            depreciationFactorTxt!!.visibility = View.GONE
        }
    }

    override fun onNothingSelected(adapterView: AdapterView<*>?) {
    }
}