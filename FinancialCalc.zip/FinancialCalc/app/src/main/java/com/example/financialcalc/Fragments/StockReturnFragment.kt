package com.example.financialcalc.Fragments

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import java.text.DateFormatSymbols
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.pow

class StockReturnFragment : Fragment() {
    private var shareBtn: ShapeableImageView? = null
    private var totalShareOwned: EditText? = null
    private var pricePurchase: EditText? = null
    private var priceSold: EditText? = null
    private var feePurchased: EditText? = null
    private var feeSold: EditText? = null
    private var taxInput: EditText? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var c3: TextView? = null
    private var c4: TextView? = null
    private var gainBefore: TextView? = null
    private var gainAfter: TextView? = null
    private var roiBefore: TextView? = null
    private var roiAfter: TextView? = null
    private var sroiBefore: TextView? = null
    private var sroiAfter: TextView? = null
    private var croiBefore: TextView? = null
    private var croiAfter: TextView? = null
    private var investmentPeriod: TextView? = null
    private var capitalGainTax: TextView? = null
    private var knowMore: TextView? = null
    private var calculateBtn: TextView? = null
    private var purchaseDate: TextView? = null
    private var soldDate: TextView? = null
    private var answer: LinearLayout? = null
    private var resetBtn: LinearLayout? = null
    private var calenderPurchase: RelativeLayout? = null
    private var calenderSell: RelativeLayout? = null
    private var purchaseCalender: Calendar? = null
    private var soldCalender: Calendar? = null
    private var shortMonths: Array<String> = DateFormatSymbols().shortMonths
    private var firstDate: Boolean = true
    private var setListener: OnDateSetListener? = null


    private fun initialize(view: View) {
        resetBtn = view.findViewById(R.id.reset)
        shareBtn = view.findViewById(R.id.share)
        calculateBtn = view.findViewById(R.id.calculate)

        totalShareOwned = view.findViewById(R.id.numberOfStocks)
        pricePurchase = view.findViewById(R.id.purchasePrice)
        priceSold = view.findViewById(R.id.soldPrice)
        feePurchased = view.findViewById(R.id.purchaseFee)
        feeSold = view.findViewById(R.id.soldfee)
        taxInput = view.findViewById(R.id.tax)

        croiAfter = view.findViewById(R.id.croiAfterTax)
        croiBefore = view.findViewById(R.id.croiBeforeTax)
        investmentPeriod = view.findViewById(R.id.investmentPeriod)
        capitalGainTax = view.findViewById(R.id.taxAns)
        purchaseDate = view.findViewById(R.id.purchaseDate)
        soldDate = view.findViewById(R.id.soldDate)
        gainAfter = view.findViewById(R.id.gainAfterTax)
        gainBefore = view.findViewById(R.id.gainBeforeTax)
        roiBefore = view.findViewById(R.id.roiBeforeTax)
        roiAfter = view.findViewById(R.id.roiAfterTax)
        sroiBefore = view.findViewById(R.id.sroiBeforeTax)
        sroiAfter = view.findViewById(R.id.sroiAfterTax)
        c1 = view.findViewById(R.id.c1)
        c2 = view.findViewById(R.id.c2)
        c3 = view.findViewById(R.id.c3)
        c4 = view.findViewById(R.id.c4)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE

        calenderPurchase = view.findViewById(R.id.calender1)
        calenderSell = view.findViewById(R.id.calender2)
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_stock_return, container, false)
        initialize(view)
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED
        c3?.text = AppConstant.CURRENCY_SELECTED
        c4?.text = AppConstant.CURRENCY_SELECTED
        purchaseCalender = Calendar.getInstance()
        purchaseDate!!.text = ("Purchase Date: " + (purchaseCalender!!.get(Calendar.DATE)) + " "
                + shortMonths[purchaseCalender!!.get(Calendar.MONTH)] + " " + (purchaseCalender!!.get(
            Calendar.YEAR
        )))

        soldCalender = Calendar.getInstance()
        soldCalender?.add(Calendar.MONTH, 12)
        soldDate!!.text = ("Sell Date: " + (soldCalender!!.get(Calendar.DATE)) + " "
                + shortMonths[soldCalender!!.get(Calendar.MONTH)] + " " + (soldCalender!!.get(Calendar.YEAR)))

        resetBtn!!.setOnClickListener {
            totalShareOwned!!.setText("")
            pricePurchase!!.setText("")
            priceSold!!.setText("")
            feePurchased!!.setText("")
            feeSold!!.setText("")
            taxInput!!.setText("")

            answer!!.visibility = View.GONE
            purchaseCalender = Calendar.getInstance()
            purchaseDate!!.text =
                ("Purchase Date: " + (purchaseCalender!!.get(Calendar.DATE)) + " "
                        + shortMonths[purchaseCalender!!.get(Calendar.MONTH)] + " " + (purchaseCalender!!.get(
                    Calendar.YEAR
                )))

            soldCalender = Calendar.getInstance()
            soldCalender!!.add(Calendar.MONTH, 12)
            soldDate!!.text = ("Sell Date: " + (soldCalender!!.get(Calendar.DATE)) + " "
                    + shortMonths[soldCalender!!.get(Calendar.MONTH)] + " " + (soldCalender!!.get(
                Calendar.YEAR
            )))
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", AppConstant.STOCK_TITLE_lIST[0])
            startActivity(intent)
        }
        calculateBtn!!.setOnClickListener {
            if (taxInput!!.text.toString().isEmpty() || totalShareOwned!!.text.toString()
                    .isEmpty() || feeSold!!.text.toString().isEmpty()
                || priceSold!!.text.toString().isEmpty() || pricePurchase!!.text.toString()
                    .isEmpty() || feePurchased!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
            }
        }
        shareBtn!!.setOnClickListener {
            if (taxInput!!.text.toString().isEmpty() || totalShareOwned!!.text.toString()
                    .isEmpty() || feeSold!!.text.toString().isEmpty()
                || priceSold!!.text.toString().isEmpty() || pricePurchase!!.text.toString()
                    .isEmpty() || feePurchased!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my Stock Return which has ROI of ${roiAfter!!.text}
 with total Gain of ${gainAfter!!.text}

 Check your Stock Return & Capital Gain using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }
        calenderPurchase!!.setOnClickListener {
            val datePickerDialog = DatePickerDialog(
                requireContext(),
                android.R.style.Theme_Holo_Dialog_MinWidth,
                setListener,
                purchaseCalender!!.get(Calendar.YEAR),
                purchaseCalender!!.get(Calendar.MONTH),
                purchaseCalender!!.get(Calendar.DATE)
            )
            datePickerDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            datePickerDialog.show()
            firstDate = true
        }
        val tempo = Calendar.getInstance()
        calenderSell!!.setOnClickListener {
            firstDate = false
            val datePickerDialog = DatePickerDialog(
                requireContext(),
                android.R.style.Theme_Holo_Dialog_MinWidth,
                { datePicker, i, i1, i2 ->
                    tempo[i, i1] = i2
                    if (tempo.compareTo(purchaseCalender) < 0) {
                        Toast.makeText(
                            context,
                            "The Sold Date must be higher than Purchase Date",
                            Toast.LENGTH_SHORT
                        ).show()
                        soldCalender = purchaseCalender
                        soldDate!!.text =
                            ("Sell Date: " + (soldCalender!![Calendar.DATE]) + " "
                                    + shortMonths[soldCalender!![Calendar.MONTH]] + " " + (soldCalender!![Calendar.YEAR]))
                    } else {
                        soldCalender!!.set(i, i1, i2)
                        soldDate!!.text =
                            ("Sell Date: " + (soldCalender!!.get(Calendar.DATE)) + " "
                                    + shortMonths[soldCalender!!.get(Calendar.MONTH)] + " " + (soldCalender!!.get(
                                Calendar.YEAR
                            )))
                    }
                },
                soldCalender!!.get(Calendar.YEAR),
                soldCalender!!.get(Calendar.MONTH),
                soldCalender!!.get(Calendar.DATE)
            )
            datePickerDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            datePickerDialog.show()
        }
        setListener = OnDateSetListener { datePicker, i, i1, i2 ->
            if (firstDate) {
                purchaseCalender!!.set(i, i1, i2)
                purchaseDate!!.text =
                    ("Purchase Date: " + (purchaseCalender!!.get(Calendar.DATE)) + " "
                            + shortMonths[purchaseCalender!!.get(Calendar.MONTH)] + " " + (purchaseCalender!!.get(
                        Calendar.YEAR
                    )))
            } else {
            }
        }


        return view
    }

    private fun calculate() {
        try {
            answer!!.visibility = View.VISIBLE
            var taxInt = 0.0
            var gainTax = 0.0
            val decimal= DecimalClass()
            var gain = totalShareOwned!!.text.toString().toDouble() * (priceSold!!.text.toString()
                .toDouble() - pricePurchase!!.text.toString().toDouble())
            gain -= feePurchased!!.text.toString().toDouble()
            gain -= feeSold!!.text.toString().toDouble()
            //1//
            gainBefore?.text = (decimal.roundOfToTwo(gain) + " " + AppConstant.CURRENCY_SELECTED)
            val roiDouble = gain / (totalShareOwned!!.text.toString()
                .toDouble() * pricePurchase!!.text.toString()
                .toDouble() + feePurchased!!.text.toString().toDouble()) * 100
            //2//
            roiBefore?.text = (decimal.roundOfToTwo(roiDouble) + "%")

            val d = daysBetween(purchaseCalender, soldCalender)
            //3//
            investmentPeriod!!.text = d[0].toString() + " yr  " + d[1] + " mo  " + d[2] + " d  "
            if (d[0] > 0) {
                if (taxInput!!.text.toString().toDouble() < 15) {
                    taxInt = 0.0
                } else if (taxInput!!.text.toString().toDouble() > 15 && taxInput!!.text.toString()
                        .toDouble() < 39.6
                ) {
                    taxInt = 15.0
                } else if (taxInput!!.text.toString().toDouble() > 39.6) {
                    taxInt = 20.0
                }
                //5//
                capitalGainTax?.text = (decimal.roundOfToTwo(taxInt) + "% (LongTerm)")
            } else {
                taxInt = taxInput!!.text.toString().toDouble()
                //5//
                capitalGainTax?.text = (decimal.roundOfToTwo(taxInt) + "% (ShortTerm)")
            }
            gainTax = gain - gain * taxInt / 100
            val decreasedSold =
                (-feeSold!!.text.toString().toDouble() + totalShareOwned!!.text.toString()
                    .toDouble() * priceSold!!.text.toString().toDouble()) - gain * taxInt / 100
            //4//
            gainAfter?.text = (decimal.roundOfToTwo(gainTax) + " " + AppConstant.CURRENCY_SELECTED)

            val roiAfterDouble = gainTax / (totalShareOwned!!.text.toString()
                .toDouble() * pricePurchase!!.text.toString()
                .toDouble() + feePurchased!!.text.toString().toDouble()) * 100
            //6//
            roiAfter?.text = (decimal.roundOfToTwo(roiAfterDouble) + "%")
            val sroiDouble = roiDouble / (d[3] / 365)
            //7//
            sroiBefore?.text = (decimal.roundOfToTwo(sroiDouble) + "%")

            val sroiAfterDouble = roiAfterDouble / (d[3] / 365)
            //8//
            sroiAfter?.text = (decimal.roundOfToTwo(sroiAfterDouble) + "%")

            val y = (totalShareOwned!!.text.toString().toDouble() * priceSold!!.text.toString()
                .toDouble() - feeSold!!.text.toString()
                .toDouble()) / (totalShareOwned!!.text.toString()
                .toDouble() * pricePurchase!!.text.toString()
                .toDouble() + feePurchased!!.text.toString().toDouble())
            val cRoiDouble = y.pow((d[3] / 365).toDouble()) - 1
            //9//
            croiBefore?.text = (decimal.roundOfToTwo(cRoiDouble) + "%")

            val yAfter = decreasedSold / (totalShareOwned!!.text.toString()
                .toDouble() * pricePurchase!!.text.toString()
                .toDouble() + feePurchased!!.text.toString().toDouble())
            val cRoiAfterDouble = yAfter.pow((d[3] / 365).toDouble()) - 1
            //10//
            croiAfter?.text = (decimal.roundOfToTwo(cRoiAfterDouble) + "%")
        } catch (e: Exception) {
            Toast.makeText(activity, "Enter the Valid Date", Toast.LENGTH_SHORT).show()
        }
    }


    fun daysBetween(startDate: Calendar?, endDate: Calendar?): IntArray {
        val end = endDate!!.timeInMillis
        val start = startDate!!.timeInMillis
        val diff = TimeUnit.MILLISECONDS.toDays(
            abs((end - start).toDouble())
                .toLong()
        )
        val date = IntArray(4)
        val year = diff.toInt() / 365
        val month = (diff % 365).toInt() / 30
        date[0] = (year)
        date[1] = (month)
        date[2] = (diff.toInt() - year * 365 - month * 30)
        date[3] = diff.toInt()
        return date
    }
}