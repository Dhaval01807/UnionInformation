package com.example.financialcalc.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.Helper.SalaryModel
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class SalaryAdapter(var context: Context,val itemNameList: List<SalaryModel>) :
    RecyclerView.Adapter<SalaryAdapter.ViewHolder>() {
    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.element_salary, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val salary: SalaryModel = itemNameList[position]
        val decimal = DecimalClass()
        holder.month.text = "${ decimal.roundOfTo(salary.month) } ${ AppConstant.CURRENCY_SELECTED }"
        holder.year.text = "${decimal.roundOfTo(salary.year)} +${ AppConstant.CURRENCY_SELECTED}"
        holder.no.text = decimal.roundOfToTwo(salary.index.toDouble())
    }


    override fun getItemCount(): Int {
        return itemNameList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var year: TextView = itemView.findViewById<TextView>(R.id.yearly)
        var no: TextView = itemView.findViewById<TextView>(R.id.index)
        var month: TextView = itemView.findViewById<TextView>(R.id.monthly)
    }
}
