package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import kotlin.math.pow

class EffectiveInterestRateFragment : Fragment() {
    private var share: ShapeableImageView? = null
    private var normalRate: EditText? = null
    private var compoundingPerPeriod: EditText? = null
    private var period: EditText? = null
    private var effectiveRate: TextView? = null
    private var effectiveRate5: TextView? = null
    private var rate: TextView? = null
    private var currency1: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var monthlyToggleBoolean: Boolean = true
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null

    private fun initialize(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        normalRate = view.findViewById<EditText>(R.id.nomialRate)
        compoundingPerPeriod = view.findViewById<EditText>(R.id.compoundingPerPeriod)
        period = view.findViewById<EditText>(R.id.period)

        effectiveRate = view.findViewById<TextView>(R.id.ePerPeriod)
        effectiveRate5 = view.findViewById<TextView>(R.id.ePer5)
        rate = view.findViewById(R.id.rate)
        currency1 = view.findViewById(R.id.oneCurrency)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE
    }

    fun calculate() {
        val decimals= DecimalClass()
        answer!!.visibility = View.VISIBLE
        val nString = normalRate!!.text.toString()
        val cString = compoundingPerPeriod!!.text.toString()
        val pString = period!!.text.toString()

        if (nString.isEmpty() || cString.isEmpty() || pString.isEmpty()) {
            Toast.makeText(activity, "Enter all the value", Toast.LENGTH_SHORT).show()
        } else {
            val o = 1 + nString.toDouble() / (cString.toDouble() * 100)
            val I = (o.pow(cString.toDouble()) - 1) * 100
            val It = ((1 + I / 100).pow(5.0) - 1) * 100
            val p = nString.toDouble() / cString.toDouble()

            effectiveRate?.text = decimals.roundOfToTwo(I) + " %"
            effectiveRate5?.text = decimals.roundOfToTwo(It) + " %"
            rate?.text = decimals.roundOfToTwo(p) + " "
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view: View =
            inflater.inflate(R.layout.fragment_effective, container, false)

        initialize(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED

        reset!!.setOnClickListener {
            normalRate!!.setText("")
            compoundingPerPeriod!!.setText("")
            period!!.setText("")
            monthlyToggleBoolean = true
            answer!!.visibility = View.GONE
        }
        knowMore!!.setOnClickListener { }
        calculate!!.setOnClickListener {
            if (normalRate!!.text.toString().isEmpty() || compoundingPerPeriod!!.text.toString()
                    .isEmpty()
                || period!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener {
            if (normalRate!!.text.toString().isEmpty() || compoundingPerPeriod!!.text.toString()
                    .isEmpty()
                || period!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    ("""I have calculated my Effective interest which has effective Rate Per Period ${effectiveRate!!.text}

 Check your FD using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}""")
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }

        return view
    }
}