package com.example.financialcalc.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Adapter.BusinessForecastAdapter
import com.example.financialcalc.Helper.BusinessForecast
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class BusinessForecastFragment : Fragment() {
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var revenue: EditText? = null
    private var revenueGrowth: EditText? = null
    private var year: EditText? = null
    private var costOfRevenue: EditText? = null
    private var costGrowth: EditText? = null
    private var calculate: TextView? = null
    private var c1: TextView? = null
    private var recyclerView: RecyclerView? = null
    private var gridLayoutManager1: GridLayoutManager? = null

    fun initializeView(view: View) {
        answer = view.findViewById(R.id.answers)
        reset = view.findViewById(R.id.reset)

        revenue = view.findViewById<EditText>(R.id.revenue)
        revenueGrowth = view.findViewById<EditText>(R.id.revenueGrowth)
        year = view.findViewById<EditText>(R.id.noOfYears)
        costOfRevenue = view.findViewById<EditText>(R.id.costOfRevenue)
        costGrowth = view.findViewById<EditText>(R.id.costIncrease)

        calculate = view.findViewById(R.id.calculate)
        c1 = view.findViewById(R.id.oneCurrency)

        recyclerView = view.findViewById(R.id.recycler)
        answer ?.visibility = View.GONE
    }

    fun calculte() {
        val decimal= DecimalClass()
        answer!!.visibility = View.VISIBLE
        val r = revenue!!.text.toString().toDouble()
        var c = costOfRevenue!!.text.toString().toDouble()
        val cG = costGrowth!!.text.toString().toDouble()
        val rG = revenueGrowth!!.text.toString().toDouble()
        val n = year!!.text.toString().toDouble()

        val c0 = r * c / 100
        val p0 = r - c0
        val m0 = p0 / c0 * 100
        c += cG
        val b0: BusinessForecast = BusinessForecast(1, r, c0, p0, m0)
        AppConstant.BUISSNESS_FORECASTE_LIST.add(b0)
        var i = 1
        while (i < n) {
            val bPervious: BusinessForecast = AppConstant.BUISSNESS_FORECASTE_LIST.get(i - 1)
            val re: Double = bPervious.revenue + bPervious.revenue * rG / 100
            val cost = re * c / 100
            val p = re - cost
            val m = p / re * 100
            val b: BusinessForecast = BusinessForecast(i + 1, re, cost, p, m)
            AppConstant.BUISSNESS_FORECASTE_LIST.add(b)
            c += cG
            i++
        }

        addRecycler()
    }

    fun addRecycler() {
        val depreciationAdpater: BusinessForecastAdapter =
            BusinessForecastAdapter(requireContext(), AppConstant.BUISSNESS_FORECASTE_LIST)
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = depreciationAdpater
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_business_forcast, container, false)
        initializeView(view)
        reset!!.setOnClickListener {
            revenue!!.setText("")
            costOfRevenue!!.setText("")
            costGrowth!!.setText("")
            year!!.setText("")
            costOfRevenue!!.setText("")
            answer!!.visibility = View.GONE
            AppConstant.BUISSNESS_FORECASTE_LIST.clear()
        }
        c1?.text = AppConstant.CURRENCY_SELECTED

        calculate!!.setOnClickListener {
            if (revenue!!.text.toString().isEmpty() || costOfRevenue!!.text.toString()
                    .isEmpty() || revenueGrowth!!.text.toString().isEmpty()
                || year!!.text.toString().isEmpty() || costGrowth!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                AppConstant.NPV_LiST.clear()
                calculte()
            }
        }
        return view
    }
}