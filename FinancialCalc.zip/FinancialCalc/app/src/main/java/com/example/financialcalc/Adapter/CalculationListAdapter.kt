package com.example.financialcalc.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.ListAdapterModel
import com.example.financialcalc.R

class CalculationListAdapter(
    context: Context?,
    val listAdapters: List<ListAdapterModel>,
    private val mAdapterCallback: AdapterCallback
) :
    RecyclerView.Adapter<CalculationListAdapter.ViewHolder>() {
    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.calculation_list_adapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val information: ListAdapterModel = listAdapters[position]
        holder.titleText.text = information.title
        holder.infoText.text = information.description
        holder.icon.setBackgroundResource(information.icon)
        holder.selectorLayout.setOnClickListener {
            val info: ListAdapterModel = listAdapters[position]
            mAdapterCallback.onCalled(info.title)
        }
    }

    interface AdapterCallback {
        fun onCalled(name: String?)
    }


    override fun getItemCount(): Int {
        return listAdapters.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var titleText: TextView = itemView.findViewById<TextView>(R.id.title)
        var infoText: TextView = itemView.findViewById<TextView>(R.id.shortDescription)
        var selectorLayout: LinearLayout = itemView.findViewById<LinearLayout>(R.id.selectorLayout)
        var icon: ImageView = itemView.findViewById<ImageView>(R.id.iconForCalculation)
    }
}