package com.example.financialcalc.Helper

data class MyApp(val appName: String, val playStoreLink: String?,val icon: String,val shortDescription: String)