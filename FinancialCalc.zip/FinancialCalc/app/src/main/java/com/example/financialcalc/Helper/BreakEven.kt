package com.example.financialcalc.Helper

data class BreakEven(val price: Double,val quantity: Double,val fee: Double,val purchase: Boolean)