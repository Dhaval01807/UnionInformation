package com.example.financialcalc.Adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.AverageClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import java.lang.String
import kotlin.CharSequence
import kotlin.Int

class AverageAdapter(
    var context: Context,
    val breakList: List<AverageClass>,
    callback: AdapterCallback
) :
    RecyclerView.Adapter<AverageAdapter.ViewHolder>() {

    private val mAdapterCallback = callback

    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.average_element, parent, false)
        return ViewHolder(view)
    }
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val breakEvenClass: AverageClass = breakList[holder. getAdapterPosition()]

        holder.price.setText(String.valueOf(breakEvenClass.price))


        holder.qty.setText(String.valueOf(breakEvenClass.quantity))


        holder.price.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val value: AverageClass = breakList[holder.adapterPosition]
                if (holder.price.text.toString().isEmpty()) {
                    val p = 0.0
                    val newBreak: AverageClass = AverageClass(p, value.quantity)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                } else {
                    val p = holder.price.text.toString().toDouble()
                    val newBreak: AverageClass = AverageClass(p, value.quantity)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                }
            }

            override fun afterTextChanged(s: Editable) {
                val value: AverageClass = breakList[holder.adapterPosition]
                if (holder.price.text.toString().isEmpty()) {
                    val p = 0.0
                    val newBreak: AverageClass = AverageClass(p, value.quantity)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                } else {
                    val p = holder.price.text.toString().toDouble()
                    val newBreak: AverageClass = AverageClass(p, value.quantity)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                }
            }
        })
        holder.qty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                val values: AverageClass = breakList[holder.adapterPosition]
                if (holder.qty.text.toString().isEmpty()) {
                    val q = 0.0
                    val newBreak: AverageClass = AverageClass(values.price, q)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                } else {
                    val q = holder.qty.text.toString().toDouble()
                    val newBreak: AverageClass = AverageClass(values.price, q)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                }
            }

            override fun afterTextChanged(s: Editable) {
                val values: AverageClass = breakList[holder.adapterPosition]
                if (holder.qty.text.toString().isEmpty()) {
                    val q = 0.0
                    val newBreak: AverageClass = AverageClass(values.price, q)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                } else {
                    val q = holder.qty.text.toString().toDouble()
                    val newBreak: AverageClass = AverageClass(values.price, q)
                    AppConstant.AVERAGE_CALCULATION[holder.adapterPosition] = newBreak
                }
            }
        })


        holder.delete.setOnClickListener {
            AppConstant.AVERAGE_CALCULATION.removeAt(holder.adapterPosition)
            mAdapterCallback.onMethodCallback()
        }
    }

    interface AdapterCallback {
        fun onMethodCallback()
    }

    override fun getItemCount(): Int {
        return breakList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var price: EditText = itemView.findViewById<EditText>(R.id.itemName)
        var qty: EditText = itemView.findViewById<EditText>(R.id.qty)
        var delete: ImageButton = itemView.findViewById<ImageButton>(R.id.delete)
    }
}