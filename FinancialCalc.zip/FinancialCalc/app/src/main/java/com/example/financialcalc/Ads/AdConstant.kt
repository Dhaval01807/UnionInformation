package com.example.financialcalc.Ads

class AdConstant {

    companion object{
        var showAd: Boolean = false
        var showAppOpen: Boolean = false
        var appOpen: String= ""
        var onBoardingNative: String = ""
        var homeBanner:String = ""

        var interstitialAdCount: Int = 3
        var interstitialAdId : String = ""

        var calculatorNativeAd:String = ""

        var rewardAdId :String = ""
    }
}