package com.example.financialcalc.Activitys

import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.webkit.WebView
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.RatingBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdView

class TheoryScreen : AppCompatActivity() {
    private var title: TextView? = null
    private var sharePref: SharedPreferences? = null
    private var openedInInt: Int = 0
    private var nameOfApp: String? = null
    private var mInterstitialAd: InterstitialAd? = null
    private var NUMBER_OF_TIME_OPENED: String = "NUMBER OF TIME"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_theory_screen)
        initializeView()
        val intent = intent
        nameOfApp = intent.getStringExtra("NAME_OF_APP")

        sharePref =
            applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)
        openedInInt = sharePref?.getInt(NUMBER_OF_TIME_OPENED, 0) ?: 0




        title!!.text = nameOfApp


        openFragment()
    }

    private fun initializeView() {
        title = findViewById(R.id.titleText)
    }

    fun back(view: View?) {

        super.onBackPressed()
    }

    private fun populateNativeAdView(nativeAd: NativeAd, adView: NativeAdView) {
        try {
            val container = findViewById<FrameLayout>(R.id.nativeAds)
            container.visibility = View.VISIBLE
            val headlineView: TextView = adView.findViewById(R.id.heading)
            headlineView.text = nativeAd.headline
            adView.headlineView = headlineView


            val body: TextView = adView.findViewById(R.id.body)
            if (!nativeAd.body.equals(null)) {
                body.text = nativeAd.body
                adView.bodyView = body
            }

            val starRating: RatingBar = adView.findViewById(R.id.start_rating)
            if (nativeAd.starRating != null) {
                starRating.rating = nativeAd.starRating?.toFloat() ?: 0f
                adView.starRatingView = starRating
            }

            val advertiser: TextView = adView.findViewById(R.id.advertisername)
            if (nativeAd.advertiser != null) {
                advertiser.text = nativeAd.advertiser
                adView.advertiserView = advertiser
            }

            val icon: ImageView = adView.findViewById(R.id.adicon)
            if (nativeAd.icon != null) {
                icon.setImageDrawable(nativeAd.icon?.drawable)
                adView.iconView = icon
            }

            val button: Button = adView.findViewById(R.id.calltoaction)
            if (nativeAd.callToAction != null) {
                button.text = nativeAd.callToAction
                adView.callToActionView = button
            }

            val mediaView: MediaView = adView.findViewById(R.id.media_view)
            adView.mediaView = mediaView
            adView.setNativeAd(nativeAd)

            container.removeAllViews()

            container.addView(adView)
        } catch (e: Exception) {
        }
    }


    private fun openFragment() {
        val web = findViewById<WebView>(R.id.webView)

        val urlMap = mapOf(
            AppConstant.BANK_TITLE_lIST[0] to "file:///android_asset/loan.html",
            AppConstant.BANK_TITLE_lIST[1] to "file:///android_asset/loan.html",
            AppConstant.BANK_TITLE_lIST[2] to "file:///android_asset/fd.html",
            AppConstant.BANK_TITLE_lIST[3] to "file:///android_asset/rd.html",
            AppConstant.BANK_TITLE_lIST[4] to "file:///android_asset/saving.html",
            AppConstant.BANK_TITLE_lIST[5] to "file:///android_asset/loan.html",
            AppConstant.BANK_TITLE_lIST[6] to "file:///android_asset/CreditCard.html",
            AppConstant.BANK_TITLE_lIST[7] to "file:///android_asset/accounting.html",
            AppConstant.BANK_TITLE_lIST[8] to "file:///android_asset/TypeOfBank.html",
            AppConstant.BANK_TITLE_lIST[9] to "file:///android_asset/Auditing.html",
            AppConstant.BANK_TITLE_lIST[10] to "file:///android_asset/loan.html",

            AppConstant.FINANCE_TITLE_lIST[0] to "file:///android_asset/ppf.html",
            AppConstant.FINANCE_TITLE_lIST[1] to "file:///android_asset/simple_and_coumpound_interest.html",
            AppConstant.FINANCE_TITLE_lIST[2] to "file:///android_asset/swp.html",
            AppConstant.FINANCE_TITLE_lIST[3] to "file:///android_asset/sip.html",
            AppConstant.FINANCE_TITLE_lIST[4] to "file:///android_asset/lumpsum.html",
            AppConstant.FINANCE_TITLE_lIST[5] to "file:///android_asset/loan.html",
            AppConstant.FINANCE_TITLE_lIST[6] to "file:///android_asset/mortage.html",
            AppConstant.FINANCE_TITLE_lIST[7] to "file:///android_asset/tax.html",
            AppConstant.FINANCE_TITLE_lIST[8] to "file:///android_asset/tvm.html",
            AppConstant.FINANCE_TITLE_lIST[9] to "file:///android_asset/bondVakuation.html",
            AppConstant.FINANCE_TITLE_lIST[10] to "file:///android_asset/salary_increment.html",
            AppConstant.FINANCE_TITLE_lIST[11] to "file:///android_asset/depreciation.html",
            AppConstant.FINANCE_TITLE_lIST[12] to "file:///android_asset/irr.html",
            AppConstant.FINANCE_TITLE_lIST[13] to "file:///android_asset/cashFlow.html",
            AppConstant.FINANCE_TITLE_lIST[14] to "file:///android_asset/bondVakuation.html",
            AppConstant.FINANCE_TITLE_lIST[15] to "file:///android_asset/securityMarket.html",
            AppConstant.FINANCE_TITLE_lIST[16] to "file:///android_asset/capitalStructure.html",

            AppConstant.BUSINESS_TITLE_lIST[0] to "file:///android_asset/gross_profit.html",
            AppConstant.BUSINESS_TITLE_lIST[1] to "file:///android_asset/cost_of_good.html",
            AppConstant.BUSINESS_TITLE_lIST[2] to "file:///android_asset/discount.html",
            AppConstant.BUSINESS_TITLE_lIST[3] to "file:///android_asset/break_even.html",
            AppConstant.BUSINESS_TITLE_lIST[4] to "file:///android_asset/margin.html",
            AppConstant.BUSINESS_TITLE_lIST[5] to "file:///android_asset/operating_margin.html",
            AppConstant.BUSINESS_TITLE_lIST[6] to "file:///android_asset/effective_interest.html",
            AppConstant.BUSINESS_TITLE_lIST[7] to "file:///android_asset/npv.html",
            AppConstant.BUSINESS_TITLE_lIST[8] to "file:///android_asset/buisness_forecast.html",
            AppConstant.BUSINESS_TITLE_lIST[9] to "file:///android_asset/bcg.html",
            AppConstant.BUSINESS_TITLE_lIST[10] to "file:///android_asset/swot.html",
            AppConstant.BUSINESS_TITLE_lIST[11] to "file:///android_asset/product_lifecycle.html",
            AppConstant.BUSINESS_TITLE_lIST[12] to "file:///android_asset/change_curve.html",
            AppConstant.BUSINESS_TITLE_lIST[13] to "file:///android_asset/pyramid.html",

            AppConstant.STOCK_TITLE_lIST[0] to "file:///android_asset/stock_return.html",
            AppConstant.STOCK_TITLE_lIST[1] to "file:///android_asset/stock_break.html",
            AppConstant.STOCK_TITLE_lIST[2] to "file:///android_asset/stock_average.html",
            AppConstant.STOCK_TITLE_lIST[3] to "file:///android_asset/pe.html",
            AppConstant.STOCK_TITLE_lIST[4] to "file:///android_asset/pivot_point.html",
            AppConstant.STOCK_TITLE_lIST[5] to "file:///android_asset/fibonacci_level.html",
            AppConstant.STOCK_TITLE_lIST[6] to "file:///android_asset/share_market.html",
            AppConstant.STOCK_TITLE_lIST[7] to "file:///android_asset/bull_bear.html",
            AppConstant.STOCK_TITLE_lIST[8] to "file:///android_asset/top_down_bottom_up.html"
        )


        urlMap[nameOfApp]?.let { web.loadUrl(it) }
        if (!AppConstant.LIGHT_THEME) {
            val settings = web.settings
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(settings, WebSettingsCompat.FORCE_DARK_ON)
            }
        }
    }
}