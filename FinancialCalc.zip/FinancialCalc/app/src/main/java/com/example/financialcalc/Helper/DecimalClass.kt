package com.example.financialcalc.Helper

import java.math.BigDecimal
import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.Locale

class DecimalClass{
    fun roundOfToTwo(number: Double): String {
        val a = BigDecimal(number)
        val roundOff = a.setScale(2, BigDecimal.ROUND_HALF_EVEN)
        val s = roundOff.toLong().toString()
        return s
    }

    fun roundOfTo(number: Double): Double {
        val a = BigDecimal(number)
        val roundOff = a.setScale(2, BigDecimal.ROUND_HALF_EVEN)
        return roundOff.toDouble()
    }

    fun isInteger(number: Double): Boolean {
        return number == number.toInt().toDouble()
    }

    fun round(number: Double): String {
        val anotherFormat = NumberFormat.getNumberInstance(Locale.US)
        val df = anotherFormat as DecimalFormat
        return df.format(number)
    }
}
