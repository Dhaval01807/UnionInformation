package com.example.financialcalc.Broadcast

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.example.financialcalc.Utils.AppConstant

class UpdateWorks(
    context: Context,
    params: WorkerParameters
) : Worker(context, params) {
    var purchase: SharedPreferences? = null

    override fun doWork(): Result {
        // Perform the update task here
        updateSharedPreferences()
        return Result.success()
    }

    private fun updateSharedPreferences() {
        purchase = applicationContext.getSharedPreferences(
            AppConstant.PACKAGE_NAME,
            Context.MODE_PRIVATE
        )

        Log.d("Rewards", "Rewards Solved")
        AppConstant.PURCHASE_STATUS = false
        purchase!!.edit().putBoolean("PURCHASE", false).apply()
    }
}
