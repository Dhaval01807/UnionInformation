package com.example.financialcalc.Fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import java.lang.String
import kotlin.Boolean
import kotlin.CharSequence
import kotlin.Exception
import kotlin.Int
import kotlin.math.ln
import kotlin.math.pow

class TVMFragment : Fragment() {
    private var presentValue: EditText? = null
    private var futureValue: EditText? = null
    private var tenure: EditText? = null
    private var interestRate: EditText? = null
    private var payment: EditText? = null
    private var share: ShapeableImageView? = null
    private var knowMore: TextView? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var c3: TextView? = null
    private var reset: LinearLayout? = null
    private var lockPressed: Boolean = false
    private var decimals= DecimalClass()
    private var calculatingPart: Int = 0
    private var whichLock: Int = 0
    private var lock1: ImageView? = null
    private var lock2: ImageView? = null
    private var lock3: ImageView? = null
    private var lock4: ImageView? = null
    private var lock5: ImageView? = null
    private var bgm: Int = 0

    fun calculate1() {
        try {
            val decimal= DecimalClass()
            val fv = futureValue!!.text.toString().toDouble()
            val t = tenure!!.text.toString().toDouble()
            val r = interestRate!!.text.toString().toDouble() / 100
            val p = payment!!.text.toString().toDouble()

            val denominator = (1 + r).pow(t)
            val cc = (denominator - 1) / r
            val numerator = -fv - p * cc * (1 + r * bgm)

            val pv = numerator / denominator

            presentValue?.setText(String.valueOf(decimal.roundOfTo(pv)))
        } catch (e: Exception) {
        }
    }

    fun calculate2() {
        try {
            val decimal= DecimalClass()
            val pv = presentValue!!.text.toString().toDouble()
            val t = tenure!!.text.toString().toDouble()
            val r = interestRate!!.text.toString().toDouble() / 100
            val p = payment!!.text.toString().toDouble()


            val ddd = (1 + r).pow(t)
            val cc = (ddd - 1) / r

            val fv = (pv * ddd + p * cc * (1 + r * bgm))

            futureValue?.setText (String.valueOf(decimal.roundOfTo(fv)))
        } catch (e: Exception) {
        }
    }

    fun calculate3() {
        try {
            val decimal= DecimalClass()
            val pv = presentValue!!.text.toString().toDouble()
            val t = tenure!!.text.toString().toDouble()
            val r = interestRate!!.text.toString().toDouble() / 100
            val fv = futureValue!!.text.toString().toDouble()


            val ddd = (1 + r).pow(t)
            val cc = (ddd - 1) / r

            val numerator = fv + pv * ddd
            val denominator = cc * (1 + r * bgm)
            val p = numerator / denominator

            payment?.setText(String.valueOf(decimal.roundOfTo(p)))
        } catch (e: Exception) {
        }
    }

    fun calculate4() {
        try {
            val decimal= DecimalClass()
            val pv = presentValue!!.text.toString().toDouble()
            val t = tenure!!.text.toString().toDouble()
            val fv = futureValue!!.text.toString().toDouble()
            val p = payment!!.text.toString().toDouble()


            val r = (fv / pv).pow(1 / t) - 1

            interestRate?.setText(String.valueOf(decimal.roundOfTo(r * 100)))
        } catch (e: Exception) {
        }
    }

    fun calculate5() {
        try {
            val decimal= DecimalClass()
            val pv = presentValue!!.text.toString().toDouble()
            val fv = futureValue!!.text.toString().toDouble()
            val r = interestRate!!.text.toString().toDouble() / 100
            val p = payment!!.text.toString().toDouble()


            val denominator = ln(1 + r)
            val numerator = ln(fv) - ln(pv)

            val t = numerator / denominator

            tenure?.setText(String.valueOf(decimal.roundOfTo(t)))
        } catch (e: Exception) {
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_t_v_m, container, false)
        intitalize(view)
        textChange()
        reset!!.setOnClickListener {
            presentValue!!.setText("")
            futureValue!!.setText("")
            payment!!.setText("")
            interestRate!!.setText("")
            tenure!!.setText("")
            calculatingPart = 0
            whichLock = 0
            lockPressed = false
            presentValue!!.isEnabled = true
            futureValue!!.isEnabled = true
            tenure!!.isEnabled = true
            interestRate!!.isEnabled = true
            payment!!.isEnabled = true
            lockBackGround(0)
        }
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED
        c3?.text = AppConstant.CURRENCY_SELECTED
        share!!.setOnClickListener {
            if (presentValue!!.text.toString().isEmpty() || futureValue!!.text.toString()
                    .isEmpty() || tenure!!.text.toString().isEmpty() ||
                payment!!.text.toString().isEmpty() || interestRate!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the value", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my TVM which has Present Value ${presentValue!!.text}
 having Future Value of ${futureValue!!.text}

 Check the TVM calculation using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }
        lockClickListner()
        knowMore!!.setOnClickListener {
            val intent = Intent(context, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "TVM Calculator")
            startActivity(intent)
        }
        return view
    }

    private fun lockClickListner() {
        //lock system
        lock1!!.setOnClickListener {
            if (whichLock == 1) {
                lockPressed = false
                whichLock = 0
                presentValue!!.isEnabled = true
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
                lock1!!.background = buttonDrawable
            } else {
                whichLock = 1
                if (presentValue!!.text.toString().isEmpty()) {
                    presentValue!!.setText("0")
                }
                futureValue!!.isEnabled = true
                payment!!.isEnabled = true
                tenure!!.isEnabled = true
                interestRate!!.isEnabled = true
                lockPressed = true
                presentValue!!.isEnabled = false

                lockBackGround(1)
            }
        }
        lock2!!.setOnClickListener {
            if (whichLock == 2) {
                lockPressed = false
                whichLock = 0
                futureValue!!.isEnabled = true
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock2!!.background = buttonDrawable
            } else {
                whichLock = 2
                if (futureValue!!.text.toString().isEmpty()) {
                    futureValue!!.setText("0")
                }
                presentValue!!.isEnabled = true
                payment!!.isEnabled = true
                tenure!!.isEnabled = true
                interestRate!!.isEnabled = true
                lockPressed = true
                futureValue!!.isEnabled = false
                lockBackGround(2)
            }
        }
        lock3!!.setOnClickListener {
            if (whichLock == 3) {
                lockPressed = false
                whichLock = 0
                payment!!.isEnabled = true
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock3!!.background = buttonDrawable
            } else {
                whichLock = 3
                if (payment!!.text.toString().isEmpty()) {
                    payment!!.setText("0")
                }
                presentValue!!.isEnabled = true
                futureValue!!.isEnabled = true
                tenure!!.isEnabled = true
                interestRate!!.isEnabled = true
                lockPressed = true
                payment!!.isEnabled = false
                lockBackGround(3)
            }
        }
        lock4!!.setOnClickListener {
            if (whichLock == 4) {
                whichLock = 0
                lockPressed = false
                interestRate!!.isEnabled = true
                var buttonDrawable = lock4!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock4!!.background = buttonDrawable
            } else {
                whichLock = 4
                if (interestRate!!.text.toString().isEmpty()) {
                    interestRate!!.setText("0")
                }
                presentValue!!.isEnabled = true
                futureValue!!.isEnabled = true
                payment!!.isEnabled = true
                tenure!!.isEnabled = true
                lockPressed = true
                interestRate!!.isEnabled = false
                lockBackGround(4)
            }
        }
        lock5!!.setOnClickListener {
            if (whichLock == 5) {
                whichLock = 0
                lockPressed = false
                tenure!!.isEnabled = true
                var buttonDrawable = lock5!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock5!!.background = buttonDrawable
            } else {
                whichLock = 5
                if (tenure!!.text.toString().isEmpty()) {
                    tenure!!.setText("0")
                }
                presentValue!!.isEnabled = true
                payment!!.isEnabled = true
                interestRate!!.isEnabled = true
                futureValue!!.isEnabled = true
                lockPressed = true
                tenure!!.isEnabled = false
                lockBackGround(5)
            }
        }
    }

    private fun textChange() {
        presentValue!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = payment!!.text.toString()
                val fv = futureValue!!.text.toString()
                val pv = presentValue!!.text.toString()
                val t = tenure!!.text.toString()
                val i = interestRate!!.text.toString()


                val pI = if (p.isEmpty()) 0 else 1
                val fI = if (fv.isEmpty()) 0 else 1
                val iI = if (i.isEmpty()) 0 else 1
                val tI = if (t.isEmpty()) 0 else 1
                val pvI = if (pv.isEmpty()) 0 else 1

                if (pvI == 1 && presentValue!!.hasFocus()) {
                    if ((pI + fI + iI + tI + pvI) >= 4) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 2
                                calculate2()
                            } else if (whichLock == 2) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 3) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 5) {
                                calculatingPart = 4
                                calculate4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculate2()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculate3()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculate4()
                            } else if (calculatingPart == 5) {
                                calculatingPart = 5
                                calculate5()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (fI == 0) {
                            calculatingPart = 2
                            calculate2()
                        } else if (pI == 0) {
                            calculatingPart = 3
                            calculate3()
                        } else if (iI == 0) {
                            calculatingPart = 4
                            calculate4()
                        } else if (tI == 0) {
                            calculatingPart = 5
                            calculate5()
                        } else {
                            calculatingPart = 4
                            calculate4()
                        }
                    }
                }
            }
        })
        futureValue!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = payment!!.text.toString()
                val fv = futureValue!!.text.toString()
                val pv = presentValue!!.text.toString()
                val t = tenure!!.text.toString()
                val i = interestRate!!.text.toString()


                val pI = if (p.isEmpty()) 0 else 1
                val fI = if (fv.isEmpty()) 0 else 1
                val iI = if (i.isEmpty()) 0 else 1
                val tI = if (t.isEmpty()) 0 else 1
                val pvI = if (pv.isEmpty()) 0 else 1


                if (fI == 1 && futureValue!!.hasFocus()) {
                    if ((pI + fI + iI + tI + pvI) >= 4) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 1
                                calculate1()
                            } else if (whichLock == 1) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 3) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 5) {
                                calculatingPart = 4
                                calculate4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculate1()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculate3()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculate4()
                            } else if (calculatingPart == 5) {
                                calculatingPart = 5
                                calculate5()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (pvI == 0) {
                            calculatingPart = 1
                            calculate1()
                        } else if (pI == 0) {
                            calculatingPart = 3
                            calculate3()
                        } else if (iI == 0) {
                            calculatingPart = 4
                            calculate4()
                        } else if (tI == 0) {
                            calculatingPart = 5
                            calculate5()
                        } else {
                            calculatingPart = 4
                            calculate4()
                        }
                    }
                }
            }
        })
        payment!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = payment!!.text.toString()
                val fv = futureValue!!.text.toString()
                val pv = presentValue!!.text.toString()
                val t = tenure!!.text.toString()
                val i = interestRate!!.text.toString()


                val pI = if (p.isEmpty()) 0 else 1
                val fI = if (fv.isEmpty()) 0 else 1
                val iI = if (i.isEmpty()) 0 else 1
                val tI = if (t.isEmpty()) 0 else 1
                val pvI = if (pv.isEmpty()) 0 else 1


                if (pI == 1 && payment!!.hasFocus()) {
                    if ((pI + fI + iI + tI + pvI) >= 4) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 2
                                calculate2()
                            } else if (whichLock == 2) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 1) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 5) {
                                calculatingPart = 4
                                calculate4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculate2()
                            } else if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculate1()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculate4()
                            } else if (calculatingPart == 5) {
                                calculatingPart = 5
                                calculate5()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (fI == 0) {
                            calculatingPart = 2
                            calculate2()
                        } else if (pvI == 0) {
                            calculatingPart = 1
                            calculate1()
                        } else if (iI == 0) {
                            calculatingPart = 4
                            calculate4()
                        } else if (tI == 0) {
                            calculatingPart = 5
                            calculate5()
                        } else {
                            calculatingPart = 4
                            calculate4()
                        }
                    }
                }
            }
        })
        tenure!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = payment!!.text.toString()
                val fv = futureValue!!.text.toString()
                val pv = presentValue!!.text.toString()
                val t = tenure!!.text.toString()
                val i = interestRate!!.text.toString()


                val pI = if (p.isEmpty()) 0 else 1
                val fI = if (fv.isEmpty()) 0 else 1
                val iI = if (i.isEmpty()) 0 else 1
                val tI = if (t.isEmpty()) 0 else 1
                val pvI = if (pv.isEmpty()) 0 else 1


                if (tI == 1 && tenure!!.hasFocus()) {
                    if ((pI + fI + iI + tI + pvI) >= 4) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 2
                                calculate2()
                            } else if (whichLock == 2) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 3) {
                                calculatingPart = 4
                                calculate4()
                            } else if (whichLock == 1) {
                                calculatingPart = 4
                                calculate4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculate2()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculate3()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculate4()
                            } else if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculate1()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (fI == 0) {
                            calculatingPart = 2
                            calculate2()
                        } else if (pI == 0) {
                            calculatingPart = 3
                            calculate3()
                        } else if (iI == 0) {
                            calculatingPart = 4
                            calculate4()
                        } else if (pvI == 0) {
                            calculatingPart = 1
                            calculate1()
                        } else {
                            calculatingPart = 4
                            calculate4()
                        }
                    }
                }
            }
        })
        interestRate!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = payment!!.text.toString()
                val fv = futureValue!!.text.toString()
                val pv = presentValue!!.text.toString()
                val t = tenure!!.text.toString()
                val i = interestRate!!.text.toString()


                val pI = if (p.isEmpty()) 0 else 1
                val fI = if (fv.isEmpty()) 0 else 1
                val iI = if (i.isEmpty()) 0 else 1
                val tI = if (t.isEmpty()) 0 else 1
                val pvI = if (pv.isEmpty()) 0 else 1

                if (iI == 1 && interestRate!!.hasFocus()) {
                    if ((pI + fI + iI + tI + pvI) >= 4) {
                        if (lockPressed) {
                            if (whichLock == 1) {
                                calculatingPart = 2
                                calculate2()
                            } else if (whichLock == 2) {
                                calculatingPart = 1
                                calculate1()
                            } else if (whichLock == 3) {
                                calculatingPart = 1
                                calculate1()
                            } else if (whichLock == 5) {
                                calculatingPart = 1
                                calculate1()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculate2()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculate3()
                            } else if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculate1()
                            } else if (calculatingPart == 5) {
                                calculatingPart = 5
                                calculate5()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (fI == 0) {
                            calculatingPart = 2
                            calculate2()
                        } else if (pI == 0) {
                            calculatingPart = 3
                            calculate3()
                        } else if (pvI == 0) {
                            calculatingPart = 1
                            calculate1()
                        } else if (tI == 0) {
                            calculatingPart = 5
                            calculate5()
                        } else {
                            calculatingPart = 1
                            calculate1()
                        }
                    }
                }
            }
        })
    }

    private fun intitalize(view: View) {
        presentValue = view.findViewById(R.id.presentValue)
        interestRate = view.findViewById(R.id.interest)
        futureValue = view.findViewById(R.id.futureValue)
        tenure = view.findViewById(R.id.tenure)
        payment = view.findViewById(R.id.payment)

        c1 = view.findViewById(R.id.one)
        c2 = view.findViewById(R.id.two)
        c3 = view.findViewById(R.id.three)
        knowMore = view.findViewById(R.id.knowMore)

        lock1 = view.findViewById(R.id.lock1)
        lock2 = view.findViewById(R.id.lock2)
        lock3 = view.findViewById(R.id.lock3)
        lock4 = view.findViewById(R.id.lock4)
        lock5 = view.findViewById(R.id.lock5)

        reset = view.findViewById(R.id.reset)

        share = view.findViewById(R.id.share)
    }

    private fun lockBackGround(i: Int) {
        //1
        if (i == 1) {
            var buttonDrawable = lock1!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock1!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock1!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock1!!.background = buttonDrawable
        }
        //2
        if (i == 2) {
            var buttonDrawable = lock2!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock2!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock2!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock2!!.background = buttonDrawable
        }
        //3
        if (i == 3) {
            var buttonDrawable = lock3!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock3!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock3!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock3!!.background = buttonDrawable
        }
        //4
        if (i == 4) {
            var buttonDrawable = lock4!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock4!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock4!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock4!!.background = buttonDrawable
        }
        //5
        if (i == 5) {
            var buttonDrawable = lock5!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.RED)
            lock5!!.background = buttonDrawable
        } else {
            var buttonDrawable = lock5!!.background
            buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
            DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
            lock5!!.background = buttonDrawable
        }
    }
}