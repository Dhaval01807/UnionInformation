package com.example.financialcalc.Fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.drawable.DrawableCompat
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class CostOfGoodFragment : Fragment() {
    private var beginningInventory: EditText? = null
    private var purchase: EditText? = null
    private var endingInventory: EditText? = null
    private var costOfGoodSold: EditText? = null
    private var reset: LinearLayout? = null
    private var lock1: ImageView? = null
    private var lock2: ImageView? = null
    private var lock3: ImageView? = null
    private var lock4: ImageView? = null
    private var knowMore: TextView? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var lockPressed: Boolean = false
    private var decimals= DecimalClass()
    private var calculatingPart: Int = 0
    private var whichLock: Int = 0


    private fun calculation1() {
        try {
            val p = purchase!!.text.toString().toDouble()
            val e = endingInventory!!.text.toString().toDouble()
            val c = costOfGoodSold!!.text.toString().toDouble()

            val b = p - e - c

            beginningInventory!!.setText("" + decimals.roundOfTo(b))
        } catch (e: Exception) {
        }
    }

    private fun calculation2() {
        try {
            val b = beginningInventory!!.text.toString().toDouble()
            val e = endingInventory!!.text.toString().toDouble()
            val c = costOfGoodSold!!.text.toString().toDouble()

            val p = b + e + c

            purchase!!.setText("" + decimals.roundOfTo(p))
        } catch (e: Exception) {
        }
    }

    private fun calculation3() {
        try {
            val p = purchase!!.text.toString().toDouble()
            val b = beginningInventory!!.text.toString().toDouble()
            val c = costOfGoodSold!!.text.toString().toDouble()

            val e = p - b - c

            endingInventory!!.setText("" + decimals.roundOfTo(e))
        } catch (e: Exception) {
        }
    }

    private fun calculation4() {
        try {
            val p = purchase!!.text.toString().toDouble()
            val e = endingInventory!!.text.toString().toDouble()
            val b = beginningInventory!!.text.toString().toDouble()

            val c = b - p - e

            costOfGoodSold!!.setText("" + decimals.roundOfTo(c))
        } catch (e: Exception) {
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_cost_of_good, container, false)


        instailization(view)
        reset!!.setOnClickListener {
            beginningInventory!!.setText("")
            endingInventory!!.setText("")
            purchase!!.setText("")
            costOfGoodSold!!.setText("")
            beginningInventory!!.isEnabled = true
            endingInventory!!.isEnabled = true
            purchase!!.isEnabled = true
            calculatingPart = 0
            whichLock = 0
            costOfGoodSold!!.isEnabled = true
            lockBackGround(0)
            lockPressed = false
        }
        lock()
        textChanger()
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED

        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", AppConstant.BUSINESS_TITLE_lIST.get(1))
            startActivity(intent)
        }

        return view
    }


    private fun textChanger() {
        //calculating system

        beginningInventory!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = purchase!!.text.toString()
                val e = endingInventory!!.text.toString()
                val c = costOfGoodSold!!.text.toString()
                val b = beginningInventory!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (bI == 1 && beginningInventory!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 2
                                calculation2()
                            } else if (whichLock == 2) {
                                calculatingPart = 4
                                calculation4()
                            } else if (whichLock == 3) {
                                calculatingPart = 4
                                calculation4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculation2()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculation3()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculation4()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (pI == 0) {
                            calculatingPart = 2
                            calculation2()
                        } else if (eI == 0) {
                            calculatingPart = 3
                            calculation3()
                        } else if (cI == 0) {
                            calculatingPart = 4
                            calculation4()
                        } else {
                            calculatingPart = 4
                            calculation4()
                        }
                    }
                }
            }
        })
        purchase!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = purchase!!.text.toString()
                val e = endingInventory!!.text.toString()
                val c = costOfGoodSold!!.text.toString()
                val b = beginningInventory!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (bI == 1 && beginningInventory!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 3
                                calculation3()
                            } else if (whichLock == 1) {
                                calculatingPart = 4
                                calculation4()
                            } else if (whichLock == 3) {
                                calculatingPart = 4
                                calculation4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculation1()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculation3()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculation4()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (bI == 0) {
                            calculatingPart = 1
                            calculation1()
                        } else if (eI == 0) {
                            calculatingPart = 3
                            calculation3()
                        } else if (cI == 0) {
                            calculatingPart = 4
                            calculation4()
                        } else {
                            calculatingPart = 4
                            calculation4()
                        }
                    }
                }
            }
        })
        endingInventory!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = purchase!!.text.toString()
                val e = endingInventory!!.text.toString()
                val c = costOfGoodSold!!.text.toString()
                val b = beginningInventory!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (eI == 1 && endingInventory!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            if (whichLock == 4) {
                                calculatingPart = 2
                                calculation2()
                            } else if (whichLock == 2) {
                                calculatingPart = 4
                                calculation4()
                            } else if (whichLock == 1) {
                                calculatingPart = 4
                                calculation4()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculation2()
                            } else if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculation1()
                            } else if (calculatingPart == 4) {
                                calculatingPart = 4
                                calculation4()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (pI == 0) {
                            calculatingPart = 2
                            calculation2()
                        } else if (bI == 0) {
                            calculatingPart = 1
                            calculation1()
                        } else if (cI == 0) {
                            calculatingPart = 4
                            calculation4()
                        } else {
                            calculatingPart = 4
                            calculation4()
                        }
                    }
                }
            }
        })
        costOfGoodSold!!.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                val p = purchase!!.text.toString()
                val e = endingInventory!!.text.toString()
                val c = costOfGoodSold!!.text.toString()
                val b = beginningInventory!!.text.toString()

                val pI = if (p.isEmpty()) 0 else 1
                val eI = if (e.isEmpty()) 0 else 1
                val cI = if (c.isEmpty()) 0 else 1
                val bI = if (b.isEmpty()) 0 else 1

                if (cI == 1 && costOfGoodSold!!.hasFocus()) {
                    if ((pI + eI + cI + bI) >= 3) {
                        if (lockPressed) {
                            if (whichLock == 1) {
                                calculatingPart = 2
                                calculation2()
                            } else if (whichLock == 2) {
                                calculatingPart = 1
                                calculation1()
                            } else if (whichLock == 3) {
                                calculatingPart = 1
                                calculation1()
                            }
                        } else if (calculatingPart != 0) {
                            if (calculatingPart == 2) {
                                calculatingPart = 2
                                calculation2()
                            } else if (calculatingPart == 3) {
                                calculatingPart = 3
                                calculation3()
                            } else if (calculatingPart == 1) {
                                calculatingPart = 1
                                calculation1()
                            } else {
                                calculatingPart = 0
                            }
                        } else if (pI == 0) {
                            calculatingPart = 2
                            calculation2()
                        } else if (eI == 0) {
                            calculatingPart = 3
                            calculation3()
                        } else if (bI == 0) {
                            calculatingPart = 1
                            calculation1()
                        } else {
                            calculatingPart = 1
                            calculation1()
                        }
                    }
                }
            }
        })
    }

    private fun lock() {
        //lock system
        lock1!!.setOnClickListener {
            if (whichLock == 1) {
                lockPressed = false
                whichLock = 0
                beginningInventory!!.isEnabled = true
                var buttonDrawable = lock1!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(buttonDrawable, Color.parseColor("#c3c3c3"))
                lock1!!.background = buttonDrawable
            } else {
                whichLock = 1
                if (beginningInventory!!.text.toString().isEmpty()) {
                    beginningInventory!!.setText("0")
                }
                endingInventory!!.isEnabled = true
                purchase!!.isEnabled = true
                costOfGoodSold!!.isEnabled = true
                lockPressed = true
                beginningInventory!!.isEnabled = false

                lockBackGround(1)
            }
        }
        lock2!!.setOnClickListener {
            if (whichLock == 2) {
                lockPressed = false
                whichLock = 0
                purchase!!.isEnabled = true
                var buttonDrawable = lock2!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock2!!.background = buttonDrawable
            } else {
                whichLock = 2
                if (purchase!!.text.toString().isEmpty()) {
                    purchase!!.setText("0")
                }
                beginningInventory!!.isEnabled = true
                endingInventory!!.isEnabled = true
                costOfGoodSold!!.isEnabled = true
                lockPressed = true
                purchase!!.isEnabled = false
                lockBackGround(2)
            }
        }
        lock3!!.setOnClickListener {
            if (whichLock == 3) {
                lockPressed = false
                whichLock = 0
                endingInventory!!.isEnabled = true
                var buttonDrawable = lock3!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock3!!.background = buttonDrawable
            } else {
                whichLock = 3
                if (endingInventory!!.text.toString().isEmpty()) {
                    endingInventory!!.setText("0")
                }
                purchase!!.isEnabled = true
                beginningInventory!!.isEnabled = true
                costOfGoodSold!!.isEnabled = true
                lockPressed = true
                endingInventory!!.isEnabled = false
                lockBackGround(3)
            }
        }
        lock4!!.setOnClickListener {
            if (whichLock == 4) {
                whichLock = 0
                lockPressed = false
                costOfGoodSold!!.isEnabled = true
                var buttonDrawable = lock4!!.background
                buttonDrawable = DrawableCompat.wrap(buttonDrawable!!)
                DrawableCompat.setTint(
                    buttonDrawable!!,
                    Color.parseColor("#c3c3c3")
                )
                lock4!!.background = buttonDrawable
            } else {
                whichLock = 4
                if (costOfGoodSold!!.text.toString().isEmpty()) {
                    costOfGoodSold!!.setText("0")
                }
                purchase!!.isEnabled = true
                beginningInventory!!.isEnabled = true
                endingInventory!!.isEnabled = true
                lockPressed = true
                costOfGoodSold!!.isEnabled = false
                lockBackGround(4)
            }
        }
    }

    private fun instailization(view: View) {
        beginningInventory = view.findViewById<EditText>(R.id.beginningInventory)
        endingInventory = view.findViewById<EditText>(R.id.endingInventory)
        purchase = view.findViewById<EditText>(R.id.purchase)
        costOfGoodSold = view.findViewById<EditText>(R.id.costOfGoodSold)

        lock1 = view.findViewById(R.id.lock1)
        lock2 = view.findViewById(R.id.lock2)
        lock3 = view.findViewById(R.id.lock3)
        lock4 = view.findViewById(R.id.lock4)

        c1 = view.findViewById<TextView>(R.id.one)
        c2 = view.findViewById(R.id.two)

        knowMore = view.findViewById(R.id.knowMore)
        reset = view.findViewById(R.id.reset)
    }

    private fun lockBackGround(i: Int) {
        val locks = listOf(lock1, lock2, lock3, lock4)
        val lockIndex = i - 1

        locks.forEachIndexed { index, lock ->
            val color = if (index == lockIndex) Color.RED else Color.parseColor("#c3c3c3")
            val buttonDrawable = DrawableCompat.wrap(lock!!.background)
            DrawableCompat.setTint(buttonDrawable, color)
            lock.background = buttonDrawable
        }
    }
}