package com.example.financialcalc.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.BusinessForecast
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class BusinessForecastAdapter(
    var context: Context,
    private val itemNameList: List<BusinessForecast>
) :
    RecyclerView.Adapter<BusinessForecastAdapter.ViewHolder>() {

    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.business_forecaste_element, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val depricatiom: BusinessForecast = itemNameList[position]
        val decimal = DecimalClass()
        holder.year.text = "${depricatiom.year} "
        holder.margin.text = "${decimal.roundOfToTwo(depricatiom.margin)} %"
        holder.revenue.text =
            "${decimal.roundOfToTwo(depricatiom.revenue)} ${AppConstant.CURRENCY_SELECTED}"
        holder.cost.text =
            "${ decimal.roundOfToTwo(depricatiom.cost) } ${ AppConstant.CURRENCY_SELECTED }"

        holder.profit.text =
            "${decimal.roundOfToTwo(depricatiom.profit)} ${AppConstant.CURRENCY_SELECTED}"
    }


    override fun getItemCount(): Int {
        return itemNameList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var year: TextView = itemView.findViewById<TextView>(R.id.year)
        var revenue: TextView = itemView.findViewById<TextView>(R.id.revenue)
        var cost: TextView = itemView.findViewById<TextView>(R.id.cost)
        var profit: TextView = itemView.findViewById<TextView>(R.id.profit)
        var margin: TextView = itemView.findViewById<TextView>(R.id.margin)
    }
}