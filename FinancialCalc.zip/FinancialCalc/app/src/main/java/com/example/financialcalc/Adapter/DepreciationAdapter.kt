package com.example.financialcalc.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.Helper.DepreciationClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class DepreciationAdapter(var context: Context, private val itemNameList: List<DepreciationClass>) :
    RecyclerView.Adapter<DepreciationAdapter.ViewHolder>() {
    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.depreciation_element, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val depreciationValue: DepreciationClass = itemNameList[position]
        val decimal = DecimalClass()
        holder.depPer.text = "${decimal.roundOfToTwo(depreciationValue.depPercentage)} %"
        holder.year.text = decimal.roundOfToTwo(depreciationValue.year.toDouble())
        holder.deepCumulative.text = "${decimal.roundOfToTwo(depreciationValue.depAccumlated)} ${AppConstant.CURRENCY_SELECTED}"
        holder.depAmount.text = "${decimal.roundOfToTwo(depreciationValue.depAMount)} ${AppConstant.CURRENCY_SELECTED}"
        holder.depPer.text = "${decimal.roundOfToTwo(depreciationValue.depAccumlated)} ${AppConstant.CURRENCY_SELECTED}"

        holder.begin.text = "${decimal.roundOfToTwo(depreciationValue.beginning)} ${AppConstant.CURRENCY_SELECTED}"
        holder.end.text = "${decimal.roundOfToTwo(depreciationValue.ending)} ${AppConstant.CURRENCY_SELECTED}"
    }


    override fun getItemCount(): Int {
        return itemNameList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var year: TextView = itemView.findViewById<TextView>(R.id.year)
        var depPer: TextView = itemView.findViewById<TextView>(R.id.depPer)
        var depAmount: TextView = itemView.findViewById<TextView>(R.id.depAmount)
        var deepCumulative: TextView = itemView.findViewById<TextView>(R.id.depAccumlated)
        var begin: TextView = itemView.findViewById<TextView>(R.id.beginning)
        var end: TextView = itemView.findViewById<TextView>(R.id.ending)
    }
}