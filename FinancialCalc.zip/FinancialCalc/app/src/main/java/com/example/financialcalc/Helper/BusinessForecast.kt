package com.example.financialcalc.Helper

data class BusinessForecast(
    val year: Int,
    val revenue: Double,
    val cost: Double,
    val profit: Double,
    val margin: Double
)
