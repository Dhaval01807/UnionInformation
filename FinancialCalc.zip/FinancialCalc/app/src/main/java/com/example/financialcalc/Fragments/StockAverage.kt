package com.example.financialcalc.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Adapter.AverageAdapter
import com.example.financialcalc.Helper.AverageClass
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class StockAverage : Fragment(), AverageAdapter.AdapterCallback {
    private var purchasePrice: EditText? = null
    private var qty: EditText? = null
    private var recyclerView: RecyclerView? = null
    private var ans: LinearLayout? = null
    private var addStocks: LinearLayout? = null
    private var resetBtn: LinearLayout? = null
    private var calculate: TextView? = null
    private var stockAveragePrice: TextView? = null
    private var totalShares: TextView? = null
    private var totalStockCost: TextView? = null
    private var decimals: DecimalClass? = null
    private var gridLayoutManager1: GridLayoutManager? = null
    private var breakEvenAdapter: AverageAdapter? = null


    private fun initializeView(view: View) {
        AppConstant.BREAK_LIST.clear()

        purchasePrice = view.findViewById(R.id.itemName)
        qty = view.findViewById(R.id.qty)

        recyclerView = view.findViewById(R.id.recycler)

        ans = view.findViewById(R.id.answers)
        addStocks = view.findViewById(R.id.add)

        resetBtn = view.findViewById(R.id.reset)
        stockAveragePrice = view.findViewById(R.id.average)
        totalShares = view.findViewById(R.id.totalShares)
        totalStockCost = view.findViewById(R.id.totalStockCost)
        calculate = view.findViewById(R.id.calculate)
        ans ?.visibility = View.GONE
    }


    override fun onMethodCallback() {
        addNewRecycler()
    }

    private fun calculate() {
        ans!!.visibility = View.VISIBLE
        val decimal= DecimalClass()
        var tShare = 0.0
        var stockAverage = 0.0
        var totalCost = 0.0
        tShare = qty!!.text.toString().toDouble()
        totalCost = purchasePrice!!.text.toString().toDouble()
        for (averageClass in AppConstant.AVERAGE_CALCULATION) {
            tShare += averageClass.quantity
            totalCost += averageClass.price
        }
        stockAverage = totalCost / tShare
        stockAveragePrice?.text = (decimal.roundOfToTwo(stockAverage) + " " + AppConstant.CURRENCY_SELECTED)
        totalStockCost?.text = (decimal.roundOfToTwo(totalCost) + " " + AppConstant.CURRENCY_SELECTED)
        totalShares?.text = decimal.roundOfToTwo(tShare)
    }

    private fun addNewRecycler() {
        breakEvenAdapter = AverageAdapter(requireContext(), AppConstant.AVERAGE_CALCULATION, this)
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = breakEvenAdapter
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_stock_avarage, container, false)
        initializeView(view)
        addStocks!!.setOnClickListener {
            val avgClass: AverageClass = AverageClass(0.0, 1.0)
            AppConstant.AVERAGE_CALCULATION.add(avgClass)
            addNewRecycler()
        }
        calculate!!.setOnClickListener {
            if (qty!!.text.toString().isEmpty()) {
                qty!!.setText("1")
            }
            if (!purchasePrice!!.text.toString().isEmpty()) {
                calculate()
            } else {
                Toast.makeText(context, "Enter All the Value", Toast.LENGTH_LONG).show()
            }
        }
        resetBtn!!.setOnClickListener {
            purchasePrice!!.setText("")
            qty!!.setText("1")
            ans!!.visibility = View.GONE
            AppConstant.AVERAGE_CALCULATION.clear()
            addNewRecycler()
        }
        return view
    }
}