package com.example.financialcalc.Adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.MyApp
import com.example.financialcalc.R
import com.squareup.picasso.Picasso

class NewAppAdapter(val context: Context,val moreApps: List<MyApp>) :
    RecyclerView.Adapter<NewAppAdapter.ViewHolder>() {
    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.new_app_addapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app: MyApp = moreApps[position]
        holder.appName.text = app.appName
        holder.shortDiscription.text = app.shortDescription
        val image: String = app.icon
        try {
            Picasso.get().load(image).into(holder.icon)
        } catch (e: Exception) {
        }
        holder.layout.setOnClickListener {
            val newApp: MyApp = moreApps[position]
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setData(Uri.parse(newApp.playStoreLink))
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        return moreApps.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var icon: ImageView = itemView.findViewById<ImageView>(R.id.appIcon)
        var appName: TextView = itemView.findViewById<TextView>(R.id.appName)
        var shortDiscription: TextView = itemView.findViewById<TextView>(R.id.shortDiscription)
        var layout: LinearLayout = itemView.findViewById<LinearLayout>(R.id.layout)
    }
}