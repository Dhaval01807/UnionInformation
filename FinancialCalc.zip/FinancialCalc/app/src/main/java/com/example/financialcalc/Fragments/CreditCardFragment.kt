package com.example.financialcalc.Fragments

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import java.text.DateFormatSymbols
import java.util.Calendar
import kotlin.math.ln
import kotlin.math.pow


class CreditCardFragment : Fragment() {
    private var share: ShapeableImageView? = null
    private var balance: EditText? = null
    private var interest: EditText? = null
    private var payPerMonth: EditText? = null
    private var totalAns: TextView? = null
    private var payName: TextView? = null
    private var interestAns: TextView? = null
    private var everyMonthAns: TextView? = null
    private var maturityDate: TextView? = null
    private var currency1: TextView? = null
    private var currency2: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var yourFirstInvestment: TextView? = null
    private var payPerBoolean: Boolean = true
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var extraAns: LinearLayout? = null
    private var calender: RelativeLayout? = null
    private var installment: Calendar? = null
    private var change: ImageView? = null
    private var shortMonths: Array<String> = DateFormatSymbols().shortMonths

    var setListener: OnDateSetListener? = null

    private fun initializeView(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        balance = view.findViewById<EditText>(R.id.creditAmount)
        interest = view.findViewById<EditText>(R.id.rate)
        payPerMonth = view.findViewById<EditText>(R.id.payPerMonth)

        payName = view.findViewById<TextView>(R.id.payName)
        yourFirstInvestment = view.findViewById<TextView>(R.id.YourFirsInvestment)
        maturityDate = view.findViewById<TextView>(R.id.maturityDate)
        interestAns = view.findViewById<TextView>(R.id.interestAns)
        totalAns = view.findViewById<TextView>(R.id.totalAns)
        currency1 = view.findViewById(R.id.oneCurrency)
        knowMore = view.findViewById(R.id.knowMore)
        currency2 = view.findViewById(R.id.two)
        everyMonthAns = view.findViewById<TextView>(R.id.everyMonthAns)

        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE
        extraAns = view.findViewById<LinearLayout>(R.id.extraAns)

        change = view.findViewById<ImageView>(R.id.change)

        calender = view.findViewById<RelativeLayout>(R.id.calender)
    }

    private fun calculate() {
        answer!!.visibility = View.VISIBLE

        val decimal= DecimalClass()
        var m = 0.0
        val payMonthlyDouble: Double
        val balanceDouble = balance!!.text.toString().toDouble()
        val interestDouble = interest!!.text.toString().toDouble()
        val paymentDouble = payPerMonth!!.text.toString().toDouble()
        try {
            m = interestDouble / 1200
            if (payPerBoolean) {
                extraAns!!.visibility = View.GONE

                val n = balanceDouble * m / paymentDouble

                val numerator = 0 - ln(1 - n)
                val denominator = ln(1 + m)
                val numberOfMonth = numerator / denominator
                val t = numberOfMonth * paymentDouble
                totalAns?.text = decimal.round(t) + " " + AppConstant.CURRENCY_SELECTED
                interestAns?.text = decimal.round(t - balanceDouble) + " " + AppConstant.CURRENCY_SELECTED
                val finalDate = installment
                finalDate!!.add(Calendar.MONTH, numberOfMonth.toInt())
                maturityDate!!.text = ((finalDate[Calendar.DATE]).toString() + " "
                        + shortMonths[finalDate[Calendar.MONTH]] + " " + (finalDate[Calendar.YEAR]))
                finalDate.add(Calendar.MONTH, -numberOfMonth.toInt())
            } else {
                extraAns!!.visibility = View.VISIBLE

                val numerator = balanceDouble * m
                val n = 0 - paymentDouble
                val denominator = 1 - (1 + m).pow(n)
                payMonthlyDouble = numerator / denominator
                val total = paymentDouble * payMonthlyDouble
                totalAns?.text = decimal.round(total) + " " + AppConstant.CURRENCY_SELECTED
                everyMonthAns?.text = decimal.round(payMonthlyDouble) + " " + AppConstant.CURRENCY_SELECTED
                interestAns?.text = decimal.round(total - balanceDouble) + " " + AppConstant.CURRENCY_SELECTED
                val finalDate = installment
                finalDate!!.add(Calendar.MONTH, paymentDouble.toInt())
                maturityDate!!.text = ((finalDate[Calendar.DATE]).toString() + " "
                        + shortMonths[finalDate[Calendar.MONTH]] + " " + (finalDate[Calendar.YEAR]))
                finalDate.add(Calendar.MONTH, -paymentDouble.toInt())
            }
        } catch (e: Exception) {
            totalAns!!.text = "NaN"
            interestAns!!.text = "NaN"
            everyMonthAns!!.text = "NaN"
            maturityDate!!.text = "NaN"
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_credit_card, container, false)
        initializeView(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED
        currency2?.text = AppConstant.CURRENCY_SELECTED
        installment = Calendar.getInstance()
        yourFirstInvestment!!.text =
            ("Your First Investment: " + (installment?.get(Calendar.DATE)) + " "
                    + shortMonths[installment?.get(Calendar.MONTH)!!] + " " + (installment?.get(
                Calendar.YEAR
            )))

        reset!!.setOnClickListener {
            balance!!.setText("")
            interest!!.setText("")
            payPerBoolean = true
            payPerMonth!!.setText("")
            installment = Calendar.getInstance()
            answer!!.visibility = View.GONE
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(context, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Credit Card PayOff")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (balance!!.text.toString().isEmpty() || interest!!.text.toString().isEmpty()
                || payPerMonth!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (interest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener {
            if (balance!!.text.toString().isEmpty() || interest!!.text.toString().isEmpty()
                || payPerMonth!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (interest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my Credit Card Payoff which has a total Payment ${totalAns!!.text}
 with total Interest of ${interestAns!!.text}

 Check your Credit Card Payoff using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }
        change!!.setOnClickListener {
            if (payPerBoolean) {
                payPerBoolean = false
                currency2!!.visibility = View.INVISIBLE
                payName!!.text = "Desired Months until Debt Free*"
            } else {
                payPerBoolean = true
                currency2!!.visibility = View.VISIBLE
                payName!!.text = "Payment Per Month*"
            }
        }
        calender!!.setOnClickListener {
            val datePickerDialog = DatePickerDialog(
                requireContext(),
                android.R.style.Theme_Holo_Dialog_MinWidth,
                setListener,
                installment!!.get(Calendar.YEAR),
                installment!!.get(Calendar.MONTH),
                installment!!.get(Calendar.DATE)
            )
            datePickerDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            datePickerDialog.show()
        }
        setListener = OnDateSetListener { datePicker, i, i1, i2 ->
            installment?.set(i, i1, i2)
            yourFirstInvestment!!.text =
                ("Current Date: " + (installment?.get(Calendar.DATE)) + " "
                        + shortMonths[installment!!.get(Calendar.MONTH)] + " " + (installment!!.get(
                    Calendar.YEAR
                )))
        }

        return view
    }
}