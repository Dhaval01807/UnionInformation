package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView

class FibonacciFragment : Fragment() {
   private var share: ShapeableImageView? = null
   private var low: EditText? = null
   private var high: EditText? = null
   private var uptrend: TextView? = null
   private var rt1: TextView? = null
   private var rt2: TextView? = null
   private var rt3: TextView? = null
   private var rt4: TextView? = null
   private var rt5: TextView? = null
   private var rt6: TextView? = null
   private var rt7: TextView? = null
   private var rt8: TextView? = null
   private var r1: TextView? = null
   private var r2: TextView? = null
   private var r3: TextView? = null
   private var r4: TextView? = null
   private var r5: TextView? = null
   private var r6: TextView? = null
   private var r7: TextView? = null
   private var r8: TextView? = null
   private var et1: TextView? = null
   private var et2: TextView? = null
   private var et3: TextView? = null
   private var et4: TextView? = null
   private var et5: TextView? = null
   private var et6: TextView? = null
   private var et7: TextView? = null
   private var et8: TextView? = null
   private var et9: TextView? = null
   private var e1: TextView? = null
   private var e2: TextView? = null
   private var e3: TextView? = null
   private var e4: TextView? = null
   private var e5: TextView? = null
   private var e6: TextView? = null
   private var e7: TextView? = null
   private var e8: TextView? = null
   private var e9: TextView? = null
   private var currency1: TextView? = null
   private var currency2: TextView? = null
   private var knowMore: TextView? = null
   private var calculate: TextView? = null
   private var uptrendBoolean: Boolean = true
   private var answer: LinearLayout? = null
   private var reset: LinearLayout? = null
   private var ur: DoubleArray = doubleArrayOf(0.0, 0.236, 0.382, 0.50, 0.618, 0.764, 1.00, 1.382)
   private var ue: DoubleArray = doubleArrayOf(2.618, 2.00, 1.618, 1.382, 1.00, 0.618, 0.50, 0.382, 0.236)
   private var ansur: DoubleArray = DoubleArray(8)
   private var ansue: DoubleArray = DoubleArray(9)
   private var ansdr: DoubleArray = DoubleArray(8)
   private var ansde: DoubleArray = DoubleArray(9)

    private fun initialize(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        low = view.findViewById<EditText>(R.id.low)
        high = view.findViewById<EditText>(R.id.high)

        uptrend = view.findViewById<TextView>(R.id.uptrendToggle)
        rt1 = view.findViewById<TextView>(R.id.retText1)
        rt2 = view.findViewById<TextView>(R.id.retText2)
        rt3 = view.findViewById<TextView>(R.id.retText3)
        rt4 = view.findViewById<TextView>(R.id.retText4)
        rt5 = view.findViewById<TextView>(R.id.retText5)
        rt6 = view.findViewById<TextView>(R.id.retText6)
        rt7 = view.findViewById<TextView>(R.id.retText7)
        rt8 = view.findViewById<TextView>(R.id.retText8)
        r1 = view.findViewById<TextView>(R.id.retAns1)
        r2 = view.findViewById<TextView>(R.id.retAns2)
        r3 = view.findViewById<TextView>(R.id.retAns3)
        r4 = view.findViewById<TextView>(R.id.retAns4)
        r5 = view.findViewById<TextView>(R.id.retAns5)
        r6 = view.findViewById<TextView>(R.id.retAns6)
        r7 = view.findViewById<TextView>(R.id.retAns7)
        r8 = view.findViewById<TextView>(R.id.retAns8)
        e1 = view.findViewById<TextView>(R.id.extAns1)
        e2 = view.findViewById<TextView>(R.id.extAns2)
        e3 = view.findViewById<TextView>(R.id.extAns3)
        e4 = view.findViewById<TextView>(R.id.extAns4)
        e5 = view.findViewById<TextView>(R.id.extAns5)
        e6 = view.findViewById<TextView>(R.id.extAns6)
        e7 = view.findViewById<TextView>(R.id.extAns7)
        e8 = view.findViewById<TextView>(R.id.extAns8)
        e9 = view.findViewById<TextView>(R.id.extAns9)
        et1 = view.findViewById<TextView>(R.id.extText1)
        et2 = view.findViewById<TextView>(R.id.extText2)
        et3 = view.findViewById<TextView>(R.id.extText3)
        et4 = view.findViewById<TextView>(R.id.extText4)
        et5 = view.findViewById<TextView>(R.id.extText5)
        et6 = view.findViewById<TextView>(R.id.extText6)
        et7 = view.findViewById<TextView>(R.id.extText7)
        et8 = view.findViewById<TextView>(R.id.extText8)
        et9 = view.findViewById<TextView>(R.id.extText9)


        currency1 = view.findViewById(R.id.oneCurrency)
        currency2 = view.findViewById(R.id.twoCurrency)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer?.visibility =View.GONE
    }

    fun calculate() {
        val decimal= DecimalClass()
        answer!!.visibility = View.VISIBLE
        if (uptrendBoolean) {
            rt1!!.text = "0% (b)"
            rt2!!.text = "23.6%"
            rt3!!.text = "38.2%"
            rt4!!.text = "50%"
            rt5!!.text = "61.8%"
            rt6!!.text = "76.4%"
            rt7!!.text = "100% (a)"
            rt8!!.text = "138.2%"

            et1!!.text = "261.8%"
            et2!!.text = "200%"
            et3!!.text = "161.8%"
            et4!!.text = "138.2%"
            et5!!.text = "100%"
            et6!!.text = "61.8%"
            et7!!.text = "50%"
            et8!!.text = "38.2%"
            et9!!.text = "23.6%"

            for (i in 0..7) {
                ansur[i] = high!!.text.toString().toDouble() - ((high!!.text.toString()
                    .toDouble() - low!!.text.toString().toDouble()) * ur[i])
                ansue[i] = high!!.text.toString().toDouble() + ((high!!.text.toString()
                    .toDouble() - low!!.text.toString().toDouble()) * ue[i])
            }
            ansue[8] = high!!.text.toString().toDouble() + ((high!!.text.toString()
                .toDouble() - low!!.text.toString().toDouble()) * ue[8])
        } else {
            rt8!!.text = "0% (b)"
            rt7!!.text = "23.6%"
            rt6!!.text = "38.2%"
            rt5!!.text = "50%"
            rt4!!.text = "61.8%"
            rt3!!.text = "76.4%"
            rt2!!.text = "100% (a)"
            rt1!!.text = "138.2%"

            et9!!.text = "261.8%"
            et8!!.text = "200%"
            et7!!.text = "161.8%"
            et6!!.text = "138.2%"
            et5!!.text = "100%"
            et4!!.text = "61.8%"
            et3!!.text = "50%"
            et2!!.text = "38.2%"
            et1!!.text = "23.6%"


            for (i in 0..7) {
                ansur[i] = low!!.text.toString().toDouble() + ((high!!.text.toString()
                    .toDouble() - low!!.text.toString().toDouble()) * ur[7 - i])
                ansue[i] = low!!.text.toString().toDouble() - ((high!!.text.toString()
                    .toDouble() - low!!.text.toString().toDouble()) * ue[8 - i])
            }
            ansue[8] = low!!.text.toString().toDouble() - ((high!!.text.toString()
                .toDouble() - low!!.text.toString().toDouble()) * ue[0])
        }
        r1?.text = decimal.roundOfTo(ansur[0]).toString()
        r2?.text = decimal.roundOfTo(ansur[1]).toString()
        r3?.text = decimal.roundOfTo(ansur[2]).toString()
        r4?.text = decimal.roundOfTo(ansur[3]).toString()
        r5?.text = decimal.roundOfTo(ansur[4]).toString()
        r6?.text = decimal.roundOfTo(ansur[5]).toString()
        r7?.text = decimal.roundOfTo(ansur[6]).toString()
        r8?.text = decimal.roundOfTo(ansur[7]).toString()
        e1?.text = decimal.roundOfTo(ansue[0]).toString()
        e2?.text = decimal.roundOfTo(ansue[1]).toString()
        e3?.text = decimal.roundOfTo(ansue[2]).toString()
        e4?.text = decimal.roundOfTo(ansue[3]).toString()
        e5?.text = decimal.roundOfTo(ansue[4]).toString()
        e6?.text = decimal.roundOfTo(ansue[5]).toString()
        e7?.text = decimal.roundOfTo(ansue[6]).toString()
        e8?.text = decimal.roundOfTo(ansue[7]).toString()
        e9?.text = decimal.roundOfTo(ansue[8]).toString()
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_fibonacci, container, false)
        initialize(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED
        currency2?.text = AppConstant.CURRENCY_SELECTED

        reset!!.setOnClickListener {
            low!!.setText("")
            high!!.setText("")
            uptrend!!.text = "Uptrend"
            uptrendBoolean = true
            answer!!.visibility = View.GONE
        }
        uptrend!!.setOnClickListener {
            if (uptrendBoolean) {
                uptrendBoolean = false
                uptrend!!.text = "Downtrend"
            } else {
                uptrendBoolean = true
                uptrend!!.text = "Uptrend"
            }
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Fibonacci Level")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (low!!.text.toString().isEmpty() || high!!.text.toString().isEmpty()) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener { }
        return view
    }
}