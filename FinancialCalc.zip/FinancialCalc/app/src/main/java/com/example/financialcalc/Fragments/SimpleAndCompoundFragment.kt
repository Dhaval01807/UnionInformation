package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import kotlin.math.pow

class SimpleAndCompoundFragment : Fragment(), AdapterView.OnItemSelectedListener {
    private var share: ShapeableImageView? = null
    private var investAmount: EditText? = null
    private var rateOfInterest: EditText? = null
    private var tenure: EditText? = null
    private var totalAns: TextView? = null
    private var interestAns: TextView? = null
    private var maturityValue: TextView? = null
    private var monthToggle: TextView? = null
    private var currency1: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var yourFirstInvestment: TextView? = null
    private var monthlyToggleBoolean: Boolean = true
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null
    private var spinner: Spinner? = null
    private var spinnerArray: MutableList<String> = ArrayList()
    private var choose: String = "Compound interest"


    private fun initialize(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        investAmount = view.findViewById(R.id.investAmount)
        rateOfInterest = view.findViewById(R.id.rateOfInterest)
        tenure = view.findViewById(R.id.tenure)

        spinner = view.findViewById(R.id.spinner)

        yourFirstInvestment = view.findViewById(R.id.yourFirsInvestment)
        maturityValue = view.findViewById(R.id.maturityValue)
        interestAns = view.findViewById(R.id.interestAns)
        totalAns = view.findViewById(R.id.totalAns)
        monthToggle = view.findViewById(R.id.month)
        currency1 = view.findViewById(R.id.oneCurrency)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE



        spinnerArray.add("Compound interest")
        spinnerArray.add("Simple interest")

        val dataAdapter =
            ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, spinnerArray)
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner?.setAdapter(dataAdapter)
        spinner?.setOnItemSelectedListener(this)
    }

    fun calculate() {
        answer!!.visibility = View.VISIBLE
        val totalInterest: Double
        val totalInvest: Double
        val maturityVal: Double

        val tenureValue = if (monthlyToggleBoolean) {
            tenure!!.text.toString().toDouble()
        } else {
            tenure!!.text.toString().toDouble() * 12
        }

        val investmentAmountValue = investAmount!!.text.toString().toDouble()
        var expectedRate = rateOfInterest!!.text.toString().toDouble()
        val decimal= DecimalClass()


        expectedRate = expectedRate / 1200
        maturityVal = if (choose == "Compound interest") {
            investmentAmountValue * ((1 + expectedRate).pow(tenureValue))
        } else {
            investmentAmountValue + investmentAmountValue * expectedRate * tenureValue
        }
        totalInvest = investmentAmountValue
        totalInterest = maturityVal - totalInvest

        interestAns?.text = (decimal.round(totalInterest) + " " + AppConstant.CURRENCY_SELECTED)

        totalAns?.text = (decimal.round(totalInvest) + " " + AppConstant.CURRENCY_SELECTED)

        maturityValue?.text = (decimal.round(maturityVal) + " " + AppConstant.CURRENCY_SELECTED)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_simple_and_compound, container, false)
        initialize(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED
        monthToggle!!.setOnClickListener {
            if (monthlyToggleBoolean) {
                monthlyToggleBoolean = false
                monthToggle!!.text = "Yearly"
            } else {
                monthlyToggleBoolean = true
                monthToggle!!.text = "Monthly"
            }
        }
        reset!!.setOnClickListener {
            investAmount!!.setText("")
            rateOfInterest!!.setText("")
            monthToggle!!.text = "Months"
            monthlyToggleBoolean = true
            tenure!!.setText("")
            answer!!.visibility = View.GONE
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(context, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Simple & Compound Interest")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (investAmount!!.text.toString().isEmpty() || rateOfInterest!!.text.toString()
                    .isEmpty()
                || tenure!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (rateOfInterest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener {
            if (investAmount!!.text.toString().isEmpty() || rateOfInterest!!.text.toString()
                    .isEmpty()
                || tenure!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (rateOfInterest!!.text.toString().toDouble() > 50) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my $choose which has Maturity Value ${maturityValue!!.text}
 with total Investment of ${totalAns!!.text}

 Check your $choose using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }

        return view
    }

    override fun onItemSelected(adapterView: AdapterView<*>, view: View, i: Int, l: Long) {
        choose = adapterView.getItemAtPosition(i).toString()
    }

    override fun onNothingSelected(adapterView: AdapterView<*>?) {
    }
}