package com.example.financialcalc.Helper

data class FavoriteListClass(
    val title: String, val description: String, val icon: Int, val favourite: Boolean
)