package com.example.financialcalc.Activitys

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.Purchase
import com.example.financialcalc.R


class ProScreen : AppCompatActivity(){
    lateinit var billingClient: BillingClient
    val SKU_Lifetime_AddBucket_120: String = "financial_pro"
    private var purchaseItem: Purchase? = null
    var price: MutableLiveData<Double> = MutableLiveData(0.0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pro_screen)
    }
//        val closeBtn: ImageView = findViewById(R.id.iv_close)
//        val termText: TextView = findViewById(R.id.tv_privacy_policy_text)
//        val continueWithAd = findViewById<CardView>(R.id.btn_with_ad)
//        val purchaseBtn = findViewById<CardView>(R.id.btn_buy_pro)
//        val progressBar = findViewById<LinearLayout>(R.id.progress)
//        val priceView: TextView = findViewById(R.id.price)
//        val intent = intent
//        var fromPro: Boolean = false
//        setupBillingClient()
//        intent?.let {
//            fromPro = it.getBooleanExtra("fromPro", true)
//        }
//
//
//        val sharePref = applicationContext.getSharedPreferences(
//            AppConstant.PACKAGE_NAME,
//            MODE_PRIVATE
//        )
//
//
//        var localPrice = sharePref.getInt("price", 0)
//
//        price.value = localPrice.toDouble()
//        price.observe(this) {
//            priceView.text = "${it.toString()}/Lifetime"
//        }
//
//
//        if (fromPro) {
//            closeBtn.visibility = View.VISIBLE
//            continueWithAd.visibility = View.GONE
//        } else {
//            if (AdConstant.rewardAdId.isNotEmpty()) {
//                AdLoad.loadRewardedAd(AdConstant.rewardAdId, this)
//                AdLoad.rewardAdLoaded.observe(this) {
//
//                    if (AdLoad.rewardFailed) {
//                        val newIntent = Intent(this, MainActivity::class.java)
//                        startActivity(newIntent)
//                        finish()
//                    }
//                    if (progressBar.visibility == View.VISIBLE) {
//                        AdLoad.showRewardedAd(this)
//                    }
//                }
//            }
//        }
//
//        purchaseBtn.setOnClickListener {
//            purchaseItem(SKU_Lifetime_AddBucket_120)
//        }
//
//
//
//
//        closeBtn.setOnClickListener {
//            finish()
//        }
//
//        continueWithAd.setOnClickListener {
//            if (AdConstant.rewardAdId.isEmpty()) {
//                val newIntent = Intent(this, MainActivity::class.java)
//                startActivity(newIntent)
//                finish()
//            } else {
//                if (AdLoad.rewardFailed) {
//                    val newIntent = Intent(this, MainActivity::class.java)
//                    startActivity(newIntent)
//                    finish()
//                } else {
//                    if (AdLoad.rewardAdLoaded.value!!) {
//                        AdLoad.showRewardedAd(this)
//                    } else {
//                        progressBar.visibility = View.VISIBLE
//                    }
//                }
//            }
//
//        }
//
//        Log.e("TAG", "onCreate: ${termText.text}")
//        val termSpanning: SpannableString = SpannableString(termText.text)
//        val indexOfTerm = termText.text.indexOf("Term")
//        val indexOfPrivacy = termText.text.indexOf("Privacy")
//
//        termSpanning.setSpan(
//            ForegroundColorSpan(getColor(R.color.colorBlue)),
//            indexOfTerm,
//            indexOfTerm + 16,
//            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
//
//        )
//        termSpanning.setSpan(
//            object : ClickableSpan() {
//                override fun onClick(widget: View) {
//                    val intent = Intent(Intent.ACTION_VIEW)
//                    intent.setData(Uri.parse(AppConstant.privacyLink))
//                    startActivity(intent)
//                }
//
//            },
//            indexOfTerm,
//            indexOfTerm + 16,
//            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
//        )
//        termSpanning.setSpan(
//            ForegroundColorSpan(getColor(R.color.colorBlue)),
//            indexOfPrivacy,
//            indexOfPrivacy + 14,
//            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
//        )
//
//        termSpanning.setSpan(
//            object : ClickableSpan() {
//                override fun onClick(widget: View) {
//                    val intent = Intent(Intent.ACTION_VIEW)
//                    intent.setData(Uri.parse(AppConstant.privacyLink))
//                    startActivity(intent)
//                }
//
//            },
//            indexOfPrivacy,
//            indexOfPrivacy + 14,
//            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
//        )
//
//        termText.isClickable = true
//        termText.movementMethod = LinkMovementMethod.getInstance()
//
//
//        termText.text = termSpanning
//    }
//
//    private fun setupBillingClient() {
//        val instance: BillingClient = BillingClientSetup.getInstance(this@ProScreen, this@ProScreen)
//        this.billingClient = instance
//
//        billingClient.startConnection(object : BillingClientStateListener {
//            override fun onBillingServiceDisconnected() {
//            }
//
//            override fun onBillingSetupFinished(billingResult: BillingResult) {
//                if (billingResult.responseCode == BillingClient.BillingResponseCode.OK) {
//                    queryProductDetails()
//                }
//            }
//        })
//        instance.startConnection(object : BillingClientStateListener {
//            override fun onBillingSetupFinished(billingResult: BillingResult) {
//                if (billingResult.responseCode == 0) {
//                    return
//                }
//            }
//
//            override fun onBillingServiceDisconnected() {
//            }
//        })
//    }
//
//    fun purchaseItem(item: String) {
//        if (billingClient.isReady) {
//            billingClient.querySkuDetailsAsync(SkuDetailsParams.newBuilder()
//                .setSkusList(Arrays.asList<String>(*arrayOf<String>(item)))
//                .setType(BillingClient.SkuType.INAPP).build(),
//                SkuDetailsResponseListener { billingResult, list ->
//                    if (billingResult.responseCode == 0 && list!!.size > 0) {
//                        billingClient.launchBillingFlow(
//                            this@ProScreen, BillingFlowParams.newBuilder().setSkuDetails(
//                                list!![0]
//                            ).build()
//                        ).responseCode
//                        return@SkuDetailsResponseListener
//                    }
//                })
//        } else {
//        }
//    }
//
//    private fun queryProductDetails() {
//        val skuList: MutableList<String> = ArrayList()
//        skuList.add(SKU_Lifetime_AddBucket_120)
//        val params = SkuDetailsParams.newBuilder()
//        params.setSkusList(skuList).setType(BillingClient.SkuType.INAPP)
//
//        billingClient.querySkuDetailsAsync(
//            params.build()
//        ) { billingResult, skuDetailsList ->
//            if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && skuDetailsList != null) {
//                for (skuDetails in skuDetailsList) {
//                    val sku = skuDetails.sku
//                    val prices = skuDetails.price
//                    price.value = prices.toDouble()
//                }
//            }
//        }
//    }
//
//    override fun onPurchasesUpdated(billingResult: BillingResult, list: MutableList<Purchase>?) {
//        if (billingResult.responseCode == BillingClient.BillingResponseCode.OK && list != null) {
//            handleItemAlreadyPurchase(list)
//
//            for (purchase in list) {
//                if (purchase.purchaseState == Purchase.PurchaseState.PURCHASED) {
//                    successDialog()
//                    val sharePref = applicationContext.getSharedPreferences(
//                        AppConstant.PACKAGE_NAME,
//                        MODE_PRIVATE
//                    )
//                    sharePref.edit().putBoolean("PURCHASE", true).apply()
//
//
//                } else if (purchase.purchaseState == Purchase.PurchaseState.PENDING) {
//                } else if (purchase.purchaseState == Purchase.PurchaseState.UNSPECIFIED_STATE) {
//                }
//            }
//        } else if (billingResult.responseCode == BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED) {
//            Toast.makeText(this, "Please Restart the app", Toast.LENGTH_SHORT).show()
//        } else {
//        }
//    }
//
//    private fun successDialog() {
//        val dialog = Dialog(this, R.style.s_permission)
//        dialog.setContentView(R.layout.my_purchase_dialog)
//        dialog.setCancelable(false)
//        val buttonYes = dialog.findViewById<TextView>(R.id.buttonOk)
//        buttonYes.setOnClickListener {
//            dialog.dismiss()
//            val i: Intent = Intent(this@ProScreen, MainActivity::class.java)
//            startActivity(i)
//            finish()
//        }
//        if (!isFinishing) {
//            dialog.show()
//        }
//    }
//
//    fun handleItemAlreadyPurchase(list: List<Purchase>) {
//        purchaseItem = null
//        val next = list[0]
//        this.billingClient.consumeAsync(
//            ConsumeParams.newBuilder()
//                .setPurchaseToken(next.purchaseToken).build(),
//            ConsumeResponseListener { billingResult, s ->
//                if (next.purchaseToken.equals(SKU_Lifetime_AddBucket_120, ignoreCase = true)) {
//                    val sharePref = applicationContext.getSharedPreferences(
//                        AppConstant.PACKAGE_NAME,
//                        MODE_PRIVATE
//                    )
//                    sharePref.edit().putBoolean("PURCHASE", true).apply()
//                }
//            })
//    }
}