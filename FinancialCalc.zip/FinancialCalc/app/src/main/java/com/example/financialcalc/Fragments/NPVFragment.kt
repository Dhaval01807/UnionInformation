package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Adapter.NPVAdapter
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import kotlin.math.pow

class NPVFragment : Fragment(), NPVAdapter.AdapterCallback {
    private var initialInvestment: EditText? = null
    private var discountRate: EditText? = null
    private var recyclerView: RecyclerView? = null
    private var ans: LinearLayout? = null
    private var addStocks: LinearLayout? = null
    private var resetBtn: LinearLayout? = null
    private var c1: TextView? = null
    private var calculateBtn: TextView? = null
    private var npv: TextView? = null
    private var knowMore: TextView? = null
    private var decimals: DecimalClass? = null
    private var gridLayoutManager1: GridLayoutManager? = null
    private var breakEvenAdapter: NPVAdapter? = null


    private fun initializeView(view: View) {
        AppConstant.IRR_LIST.clear()

        initialInvestment = view.findViewById(R.id.investment)
        discountRate = view.findViewById(R.id.discountRate)

        recyclerView = view.findViewById(R.id.recycler)

        ans = view.findViewById(R.id.answers)
        addStocks = view.findViewById(R.id.add)

        c1 = view.findViewById(R.id.currency1)
        resetBtn = view.findViewById(R.id.reset)
        knowMore = view.findViewById(R.id.knowMore)
        npv = view.findViewById(R.id.npv)
        calculateBtn = view.findViewById(R.id.calculate)
        ans ?.visibility = View.GONE
    }


    override fun onMethodCallback() {
        addNewRecycler()
    }

    private fun calculate() {
        ans!!.visibility = View.VISIBLE
        decimals = DecimalClass()
        val C = addToArray()
        val n: Int = AppConstant.NPV_LiST.size
        var npvDouble = 0.0
        val r = discountRate!!.text.toString().toDouble() / 100
        for (i in n downTo 1) {
            npvDouble += C[i] / (1 + r).pow(i.toDouble())
        }
        npv!!.setText(decimals!!.roundOfToTwo(npvDouble) + " " + AppConstant.CURRENCY_SELECTED)
    }

    private fun addToArray(): List<Double> {
        val array: MutableList<Double> = ArrayList()
        array.add(initialInvestment!!.text.toString().toDouble())
        for (d in AppConstant.NPV_LiST) {
            array.add(d)
        }
        return array
    }

    private fun addNewRecycler() {
        breakEvenAdapter = NPVAdapter(requireContext(), AppConstant.NPV_LiST, this)
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = breakEvenAdapter
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_n_p_v, container, false)
        initializeView(view)
        addStocks!!.setOnClickListener {
            AppConstant.NPV_LiST.add(0.0)
            addNewRecycler()
        }
        c1?.text = AppConstant.CURRENCY_SELECTED
        calculateBtn!!.setOnClickListener {

            if(initialInvestment?.text.toString().isEmpty()){
                Toast.makeText(requireContext(),"Initial Investment Cannot Be Empty",Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (discountRate!!.text.toString().isEmpty()) {
                discountRate!!.setText("0")
            }
            calculate()
        }
        resetBtn!!.setOnClickListener {
            initialInvestment!!.setText("")
            ans!!.visibility = View.GONE
            AppConstant.NPV_LiST.clear()
            addNewRecycler()
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "IRR Calculator")
            startActivity(intent)
        }
        return view
    }
}