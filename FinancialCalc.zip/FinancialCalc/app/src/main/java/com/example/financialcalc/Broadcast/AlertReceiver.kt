package com.example.financialcalc.Broadcast

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.financialcalc.MainActivity
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class AlertReceiver : BroadcastReceiver() {
    var purchase: SharedPreferences? = null
    override fun onReceive(context: Context, intent: Intent) {
        val i = Intent(context, MainActivity::class.java)
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        val pendingIntent = PendingIntent.getActivity(context, 0, i, 0)
        val builder: NotificationCompat.Builder = NotificationCompat.Builder(context, "Financial")
            .setSmallIcon(R.drawable.ic_rupee)
            .setContentTitle("Financial Calculator")
            .setAutoCancel(true)
            .setContentText("Your Ads Free hss expired")
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
        val notificationManagerCompat = NotificationManagerCompat.from(context)
        notificationManagerCompat.notify(123, builder.build())
        purchase = context.getSharedPreferences(AppConstant.PACKAGE_NAME, Context.MODE_PRIVATE)

        purchase?.edit()?.putBoolean("PURCHASE", false)?.apply()
        AppConstant.PURCHASE_STATUS = false
    }
}