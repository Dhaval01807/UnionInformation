package com.example.financialcalc.Adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Helper.DiscountListClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import java.lang.String
import kotlin.Boolean
import kotlin.CharSequence
import kotlin.Int

class DiscountAdapter(
    var context: Context,
    val itemNameList: List<DiscountListClass>,
    var removeDiscount: Boolean,
    callback: AdapterCallback
) :
    RecyclerView.Adapter<DiscountAdapter.ViewHolder>() {
    private val mAdapterCallback = callback

    var inflater: LayoutInflater = LayoutInflater.from(context)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View = inflater.inflate(R.layout.discount_adapter, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val discountList: DiscountListClass = itemNameList[holder.adapterPosition]

        holder.itemName.setText(discountList.itemName)
        holder.actualValue.setText(String.valueOf(discountList.actualValue))
        if (!removeDiscount) {
            holder.discountValue.setText(String.valueOf(discountList.discountValue))
        }

        holder.qty.setText(String.valueOf(discountList.qty))

        holder.itemName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                val discountList1: DiscountListClass = itemNameList[holder.adapterPosition]
                if (holder.itemName.text.toString().isEmpty()) {
                    val p = " "
                    val newDiscount: DiscountListClass = DiscountListClass(
                        discountList1.actualValue,
                        discountList1.qty,
                        discountList1.discountValue,
                        p
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                } else {
                    val p = (holder.itemName.text.toString())
                    val newDiscount: DiscountListClass = DiscountListClass(
                        discountList1.actualValue,
                        discountList1.qty,
                        discountList1.discountValue,
                        p
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                }
            }
        })
        holder.actualValue.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                val discountList1: DiscountListClass = itemNameList[holder.adapterPosition]
                if (holder.actualValue.text.toString().isEmpty()) {
                    val a = 0.0
                    val newDiscount: DiscountListClass = DiscountListClass(
                        a, discountList1.qty, discountList1.discountValue,
                        discountList1.itemName
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                } else {
                    val a = holder.actualValue.text.toString().toDouble()
                    val newDiscount: DiscountListClass = DiscountListClass(
                        a, discountList1.qty, discountList1.discountValue,
                        discountList1.itemName
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                }
            }
        })
        holder.discountValue.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                val discountList1: DiscountListClass = itemNameList[holder.adapterPosition]
                if (holder.discountValue.text.toString().isEmpty()) {
                    val d = 0.0
                    val newDiscount: DiscountListClass = DiscountListClass(
                        discountList1.actualValue, discountList1.qty, d,
                        discountList1.itemName
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                } else {
                    val d = holder.discountValue.text.toString().toDouble()
                    val newDiscount: DiscountListClass = DiscountListClass(
                        discountList1.actualValue, discountList1.qty, d,
                        discountList1.itemName
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                }
            }
        })
        holder.qty.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
            }

            override fun afterTextChanged(s: Editable) {
                val discountList1: DiscountListClass = itemNameList[holder.adapterPosition]
                if (holder.qty.text.toString().isEmpty()) {
                    val q = 0.0
                    val newDiscount: DiscountListClass = DiscountListClass(
                        discountList1.actualValue, q, discountList1.discountValue,
                        discountList1.itemName
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                } else {
                    val q = holder.qty.text.toString().toDouble()
                    val newDiscount: DiscountListClass = DiscountListClass(
                        discountList1.actualValue, q, discountList1.discountValue,
                        discountList1.itemName
                    )
                    AppConstant.DISCOUNT_LIST[holder.adapterPosition] = newDiscount
                }
            }
        })


        holder.delete.setOnClickListener {
            AppConstant.DISCOUNT_LIST.removeAt(position)
            mAdapterCallback.onMethodCallback()
        }
    }

    interface AdapterCallback {
        fun onMethodCallback()
    }

    override fun getItemCount(): Int {
        return itemNameList.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var itemName: EditText = itemView.findViewById<EditText>(R.id.itemName)
        var actualValue: EditText = itemView.findViewById<EditText>(R.id.autualValue)
        var discountValue: EditText = itemView.findViewById<EditText>(R.id.discountValue)
        var qty: EditText = itemView.findViewById<EditText>(R.id.qty)
        var currency1: TextView = itemView.findViewById<TextView>(R.id.currency1)
        var currency2: TextView = itemView.findViewById<TextView>(R.id.currency2)
        var delete: ImageButton = itemView.findViewById<ImageButton>(R.id.delete)

        init {
            currency2.text =AppConstant.CURRENCY_SELECTED
            currency1.text =AppConstant.CURRENCY_SELECTED
            if (removeDiscount) {
                discountValue.setText("")
                discountValue.isEnabled = false
            }
        }
    }
}
