package com.example.financialcalc.Helper

data class DepreciationClass(
    val year: Int,
    val beginning: Double,
    val ending: Double,
    val depPercentage: Double,
    val depAMount: Double,
    val depAccumlated: Double
)