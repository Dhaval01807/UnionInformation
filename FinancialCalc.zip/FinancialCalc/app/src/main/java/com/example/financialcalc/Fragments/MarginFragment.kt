package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView


class MarginFragment : Fragment() {
    private var share: ShapeableImageView? = null
    private var costPrice: EditText? = null
    private var margin: EditText? = null
    private var saleTax: EditText? = null
    private var markUp: TextView? = null
    private var netPrice: TextView? = null
    private var grossPrice: TextView? = null
    private var profit: TextView? = null
    private var currency1: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var monthlyToggleBoolean: Boolean = true
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null

    private fun initialize(view: View) {
        reset = view.findViewById(R.id.reset)
        share = view.findViewById(R.id.share)
        calculate = view.findViewById(R.id.calculate)

        costPrice = view.findViewById(R.id.costPrice)
        margin = view.findViewById(R.id.margin)
        saleTax = view.findViewById(R.id.tax)

        markUp = view.findViewById(R.id.markup)
        netPrice = view.findViewById(R.id.netPrice)
        grossPrice = view.findViewById(R.id.grossPrice)
        profit = view.findViewById(R.id.profit)
        currency1 = view.findViewById(R.id.oneCurrency)
        knowMore = view.findViewById(R.id.knowMore)

        answer = view.findViewById(R.id.answers)
        answer ?.visibility = View.GONE
    }

    fun calculate() {
        val decimals= DecimalClass()
        answer!!.visibility = View.VISIBLE
        val costString = costPrice!!.text.toString()
        val marginString = margin!!.text.toString()
        val saleString = saleTax!!.text.toString()

        if (costString.isEmpty() || marginString.isEmpty() || saleString.isEmpty()) {
            Toast.makeText(activity, "Enter all the value", Toast.LENGTH_SHORT).show()
        } else {
            val markUpValue = 100 / (100 / marginString.toDouble() - 1)
            val profitValue = costString.toDouble() * markUpValue / 100
            val netPriceValue = costString.toDouble() + profitValue
            val grossPriceValue = netPriceValue + netPriceValue * saleString.toDouble() / 100

            markUp?.text = (decimals.round(markUpValue) + " %")
            profit?.text = (decimals.round(profitValue) + " " + AppConstant.CURRENCY_SELECTED)
            netPrice?.text = (decimals.round(netPriceValue) + " " + AppConstant.CURRENCY_SELECTED)
            grossPrice?.text = (decimals.round(grossPriceValue) + " " + AppConstant.CURRENCY_SELECTED)
        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_margin, container, false)
        initialize(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED

        reset!!.setOnClickListener {
            costPrice!!.setText("")
            margin!!.setText("")
            saleTax!!.setText("")
            monthlyToggleBoolean = true
            answer!!.visibility = View.GONE
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Margin Calculator")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (costPrice!!.text.toString().isEmpty() || margin!!.text.toString().isEmpty()
                || saleTax!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener {
            if (costPrice!!.text.toString().isEmpty() || margin!!.text.toString().isEmpty()
                || saleTax!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()

                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my Margin Calculator which has Markup % as ${markUp!!.text}
 with NetPrice of${netPrice!!.text}

 Check your FD using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }

        return view
    }
}