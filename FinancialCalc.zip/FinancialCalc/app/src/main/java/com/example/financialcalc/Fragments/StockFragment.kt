package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Activitys.CalculationScreen
import com.example.financialcalc.Adapter.CalculationListAdapter
import com.example.financialcalc.Helper.ListAdapterModel
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class StockFragment : Fragment(), CalculationListAdapter.AdapterCallback {
    var recyclerView: RecyclerView? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_stock, container, false)
        recyclerView = view.findViewById(R.id.recycler)
        var listAdapter: ListAdapterModel
        val list: MutableList<ListAdapterModel> = ArrayList<ListAdapterModel>()
        for (i in 0 until AppConstant.STOCK_TITLE_lIST.size) {
            listAdapter = ListAdapterModel(
                AppConstant.STOCK_TITLE_lIST[i],
                AppConstant.STOCK_INFO_lIST[i],
                AppConstant.STOCK_ICON_LIST[i]
            )
            list.add(listAdapter)
        }
        val calculationListAdapter: CalculationListAdapter = CalculationListAdapter(
            context, list,
            this
        )
        val gridLayoutManager = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView?.setLayoutManager(gridLayoutManager)
        recyclerView?.setAdapter(calculationListAdapter)
        return view
    }


    override fun onCalled(name: String?) {
        val intent = Intent(context, CalculationScreen::class.java)
        intent.putExtra("NAME_OF_APP", name)
        startActivity(intent)
    }
}