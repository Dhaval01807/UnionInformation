package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import com.google.android.material.imageview.ShapeableImageView
import kotlin.math.pow

class BondFragment : Fragment() {
    private var share: ShapeableImageView? = null
    private var faceValue: EditText? = null
    private var annualInterest: EditText? = null
    private var currentValue: EditText? = null
    private var couponRate: EditText? = null
    private var tenure: EditText? = null
    private var ytm: TextView? = null
    private var eay: TextView? = null
    private var currentYield: TextView? = null
    private var currency1: TextView? = null
    private var currency2: TextView? = null
    private var currency3: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null

    private fun initializeView(view: View) {
        reset = view.findViewById<LinearLayout>(R.id.reset)
        share = view.findViewById<ShapeableImageView>(R.id.share)
        calculate = view.findViewById<TextView>(R.id.calculate)

        faceValue = view.findViewById<EditText>(R.id.faceValue)
        currentValue = view.findViewById<EditText>(R.id.currentMarket)
        annualInterest = view.findViewById<EditText>(R.id.annualInterest)
        tenure = view.findViewById<EditText>(R.id.tenure)
        couponRate = view.findViewById<EditText>(R.id.couponRate)

        ytm = view.findViewById<TextView>(R.id.ytm)
        eay = view.findViewById<TextView>(R.id.EAY)
        currentYield = view.findViewById<TextView>(R.id.currentYield)
        currency1 = view.findViewById<TextView>(R.id.oneCurrency)
        currency2 = view.findViewById<TextView>(R.id.twoCurrency)
        currency3 = view.findViewById<TextView>(R.id.threeCurrency)
        knowMore = view.findViewById<TextView>(R.id.knowMore)

        answer = view.findViewById<LinearLayout>(R.id.answers)
        answer?.visibility = View.GONE
    }

    fun calculate() {
        answer!!.visibility = View.VISIBLE
        val fV = faceValue!!.text.toString().toDouble()
        val aI = annualInterest!!.text.toString().toDouble()
        val currentMar = currentValue!!.text.toString().toDouble()
        val coupon = couponRate!!.text.toString().toDouble()
        val time = tenure!!.text.toString().toDouble()

        val ytmDouble = (aI + ((fV - currentMar) / time)) / ((fV + currentMar) / 2) * 100
        val cYield = aI / currentMar * 100
        val etmDouble = 100 * ((1 + ytmDouble).pow(2.0) - 1)

        val decimal: DecimalClass = DecimalClass()

        ytm?.text = "${decimal.round(ytmDouble)} ${AppConstant.CURRENCY_SELECTED}"

        currentYield?.text = "${decimal.round(cYield)} ${AppConstant.CURRENCY_SELECTED}"

        eay?.text = "${decimal.round(etmDouble)} ${AppConstant.CURRENCY_SELECTED}"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_bond, container, false)

        initializeView(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED
        currency2?.text = AppConstant.CURRENCY_SELECTED
        currency3?.text = AppConstant.CURRENCY_SELECTED

        reset!!.setOnClickListener {
            couponRate!!.setText("")
            faceValue!!.setText("")
            currentValue!!.setText("")
            annualInterest!!.setText("")

            tenure!!.setText("")
            answer!!.visibility = View.GONE
        }

        knowMore!!.setOnClickListener {
            val intent = Intent(activity, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Bond Calculation")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (faceValue!!.text.toString().isEmpty() || currentValue!!.text.toString()
                    .isEmpty() || tenure!!.text.toString().isEmpty() || couponRate!!.text.toString()
                    .isEmpty() || annualInterest!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
            }
        }
        share!!.setOnClickListener {
            if (faceValue!!.text.toString().isEmpty() || currentValue!!.text.toString()
                    .isEmpty() || tenure!!.text.toString().isEmpty() || couponRate!!.text.toString()
                    .isEmpty() || annualInterest!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else {
                calculate()
                val intent = Intent(Intent.ACTION_SEND)
                intent.setType("text/plain")
                intent.putExtra(Intent.EXTRA_SUBJECT, "Financial Calculator")
                intent.putExtra(
                    Intent.EXTRA_TEXT,
                    """I have calculated my Bond Yield which has Yield to Maturity (YTM) ${ytm!!.text}
 having Future Value of ${eay!!.text}

 Check the TVM calculation using Financial Calculator 
${AppConstant.PLAYSTORE_LINK}"""
                )
                startActivity(Intent.createChooser(intent, "Share Using"))
            }
        }
        return view
    }
}