package com.example.financialcalc.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.content.res.AppCompatResources
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.R

class OnBoardingAdapter(val context: Context): RecyclerView.Adapter<OnBoardingAdapter.ViewHolder>() {
    val image:List<Int> = listOf(R.drawable.ic_onboarding1,R.drawable.ic_onboarding3,R.drawable.ic_onboarding2)
    val heading:List<String> = listOf("Take Control of Your Finances","Powerful Finance Calculators","Boost Your Financial Knowledge")
    val subHeading:List<String> = listOf("Smart tools to calculate, analyze, and grow your wealth.","Calculate EMI, SIP, break-even points, and more in seconds.","Understand key financial terms for smarter decisions.")



    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val image:ImageView = itemView.findViewById(R.id.tv_image)
        val heading: TextView = itemView.findViewById(R.id.tv_heading)
        val subHeading: TextView = itemView.findViewById(R.id.tv_subheading)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.on_boarding_layout,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return 3
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.image.setImageDrawable(AppCompatResources.getDrawable(context,image[position]))
        holder.heading.text = heading[position]
        holder.subHeading.text = subHeading[position]
    }
}