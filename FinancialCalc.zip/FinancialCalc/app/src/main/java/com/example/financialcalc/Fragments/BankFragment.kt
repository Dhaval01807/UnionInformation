package com.example.financialcalc.Fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Activitys.CalculationScreen
import com.example.financialcalc.Adapter.CalculationListAdapter
import com.example.financialcalc.Helper.ListAdapterModel
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class BankFragment : Fragment(), CalculationListAdapter.AdapterCallback {
    var recyclerView: RecyclerView? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_bank, container, false)
        recyclerView = view.findViewById(R.id.recycler)
        val list: MutableList<ListAdapterModel> = mutableListOf()
        for (i in 0 until AppConstant.BANK_TITLE_lIST.size) {
            list.add(ListAdapterModel(
                AppConstant.BANK_TITLE_lIST[i],
                AppConstant.BANK_INFO_lIST[i],
                AppConstant.BANK_ICON_LIST[i]
            ))
        }
        val calculationListAdapter: CalculationListAdapter = CalculationListAdapter(
            context, list, this
        )
        recyclerView?.setLayoutManager(LinearLayoutManager(requireContext()))
        recyclerView?.setAdapter(calculationListAdapter)
        return view
    }


    override fun onCalled(name: String?) {
        val intent = Intent(context, CalculationScreen::class.java)
        intent.putExtra("NAME_OF_APP", name)
        startActivity(intent)
    }
}