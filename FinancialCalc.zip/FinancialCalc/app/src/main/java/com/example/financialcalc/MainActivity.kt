package com.example.financialcalc

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.viewpager2.widget.ViewPager2
import com.example.financialcalc.Activitys.FavoriteScreen
import com.example.financialcalc.Activitys.ProScreen
import com.example.financialcalc.Adapter.FragmentAdapter
import com.example.financialcalc.Ads.AdConstant
import com.example.financialcalc.Ads.AdLoad
import com.example.financialcalc.Utils.AppConstant
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.material.navigation.NavigationView
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.scrounger.countrycurrencypicker.library.Country
import com.scrounger.countrycurrencypicker.library.CountryCurrencyPicker
import com.scrounger.countrycurrencypicker.library.Listener.CountryCurrencyPickerListener
import com.scrounger.countrycurrencypicker.library.PickerType

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private var viewPager2: ViewPager2? = null
    private var navigationView: NavigationView? = null
    private var tabLayout: TabLayout? = null
    private var drawer: DrawerLayout? = null
    private var toolbar: Toolbar? = null
    private var fav: ImageView? = null
    private var sharedPreferences: SharedPreferences? = null
    private var purchase: SharedPreferences? = null
    private var mInterstitialAd: InterstitialAd? = null
    private var backPressedTime: Boolean = false
    private var bannerAd: LinearLayout? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initializeView()
        purchase = applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)



        if (!AppConstant.PURCHASE_STATUS) {
            if (AdConstant.homeBanner.isNotEmpty()) {
                val adView = AdLoad.loadBanner(AdConstant.homeBanner, this)
                bannerAd?.addView(adView)
            }
        }

        AdLoad.loadNativeAd(AdConstant.calculatorNativeAd,this)
        viewPager2!!.adapter = FragmentAdapter(this)
        fav!!.setOnClickListener {
            startActivity(
                Intent(
                    this@MainActivity, FavoriteScreen::class.java
                )
            )
        }
        val tabLayoutMediator = TabLayoutMediator(
            tabLayout!!, viewPager2!!
        ) { tab, position ->
            when (position) {
                3 -> {
                    tab.setText("Stock")
                    tab.setIcon(R.drawable.ic_stock)
                }

                1 -> {
                    tab.setText("Finance")
                    tab.setIcon(R.drawable.ic_rupee)
                }

                2 -> {
                    tab.setText("Business")
                    tab.setIcon(R.drawable.ic_business)
                }

                0 -> {
                    tab.setText("Bank")
                    tab.setIcon(R.drawable.ic_bank)
                }
            }
        }
        tabLayoutMediator.attach()
    }


    override fun onBackPressed() {
        val drawer = findViewById<View>(R.id.drawer_layout) as DrawerLayout
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START)
        } else {
            if (backPressedTime) {
                super.onBackPressed()
            } else {
                backPressedTime = true
                Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun setSupportActionBar(toolbar: Toolbar?) {
    }

    fun initializeView() {
        viewPager2 = findViewById<ViewPager2>(R.id.viewPager)
        tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        toolbar = findViewById<View>(R.id.toolbar) as Toolbar
        setSupportActionBar(toolbar)
        fav = findViewById<ImageView>(R.id.favMenu)
        bannerAd = findViewById<LinearLayout>(R.id.home_banner)

        drawer = findViewById<View>(R.id.drawer_layout) as DrawerLayout
        val toggle = ActionBarDrawerToggle(
            this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawer!!.addDrawerListener(toggle)
        toggle.syncState()
        navigationView = findViewById<View>(R.id.nav_view) as NavigationView
        navigationView!!.setNavigationItemSelectedListener(this)
        val headerView = navigationView!!.getHeaderView(0)
        val favourite = headerView.findViewById<LinearLayout>(R.id.favourite)
        val removeAds = headerView.findViewById<LinearLayout>(R.id.removeAds)
        val changeCurrency = headerView.findViewById<LinearLayout>(R.id.changeCurrency)
        val rateUs = headerView.findViewById<LinearLayout>(R.id.rateUs)
        val share = headerView.findViewById<LinearLayout>(R.id.share)
        val contactUs = headerView.findViewById<LinearLayout>(R.id.contactUs)
        val privacyPolicy = headerView.findViewById<LinearLayout>(R.id.privacyPolicy)

        val currencyIcon = headerView.findViewById<TextView>(R.id.currencyIcon)
        currencyIcon.text = AppConstant.CURRENCY_SELECTED
        if (AppConstant.PURCHASE_STATUS) {
            removeAds.visibility = View.GONE
        }
        privacyPolicy.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setData(Uri.parse(AppConstant.privacyLink))
            startActivity(intent)
            drawer!!.closeDrawer(GravityCompat.START)
        }
        removeAds.setOnClickListener {
            startActivity(Intent(this@MainActivity, ProScreen::class.java))
            drawer!!.closeDrawer(GravityCompat.START)
        }

        changeCurrency.setOnClickListener {
            currency()
            drawer!!.closeDrawer(GravityCompat.START)
        }
        rateUs.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setData(Uri.parse(getString(R.string.appLink)))
            startActivity(intent)
            drawer!!.closeDrawer(GravityCompat.START)
        }
        share.setOnClickListener {
            val intent = Intent(Intent.ACTION_SEND)
            intent.setType("text/plain")
            intent.putExtra(Intent.EXTRA_TEXT, getString(R.string.appLink))
            intent.putExtra(Intent.EXTRA_SUBJECT, "EMI A Financial Calculator")
            startActivity(Intent.createChooser(intent, "Share Using"))
            drawer!!.closeDrawer(GravityCompat.START)
        }
        contactUs.setOnClickListener {
            val selectorIntent = Intent(Intent.ACTION_SENDTO)
            selectorIntent.setData(Uri.parse("mailto:"))
            val emailIntent = Intent(Intent.ACTION_SEND)
            emailIntent.putExtra(
                Intent.EXTRA_EMAIL,
                arrayOf<String>(AppConstant.EMAIL_ADDRESS)
            )
            emailIntent.selector = selectorIntent
            startActivity(Intent.createChooser(emailIntent, "Send email..."))
            drawer!!.closeDrawer(GravityCompat.START)
        }
        favourite.setOnClickListener {
            startActivity(Intent(this@MainActivity, FavoriteScreen::class.java))
            drawer!!.closeDrawer(GravityCompat.START)
        }
        sharedPreferences =
            applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)
        AppConstant.LIGHT_THEME = sharedPreferences?.getBoolean(AppConstant.THEME, true) ?: true
    }

    private fun currency() {
        sharedPreferences =
            applicationContext.getSharedPreferences(AppConstant.PACKAGE_NAME, MODE_PRIVATE)


        val pickerDialog: CountryCurrencyPicker =
            CountryCurrencyPicker.newInstance(PickerType.COUNTRYandCURRENCY,
                object : CountryCurrencyPickerListener {
                    override fun onSelectCountry(country: Country) {
                        sharedPreferences?.edit()
                            ?.putString(AppConstant.CURRENCY, country.currency?.symbol)
                            ?.apply()
                        Toast.makeText(
                            this@MainActivity,
                            country.currency?.symbol,
                            Toast.LENGTH_SHORT
                        ).show()
                        AppConstant.CURRENCY_SELECTED =
                            country.currency?.symbol ?: AppConstant.CURRENCY_SELECTED
                    }

                    override fun onSelectCurrency(currency: com.scrounger.countrycurrencypicker.library.Currency) {
                        sharedPreferences?.edit()
                            ?.putString(AppConstant.CURRENCY, currency.symbol)?.apply()
                        Toast.makeText(this@MainActivity, currency.symbol, Toast.LENGTH_SHORT)
                            .show()
                        AppConstant.CURRENCY_SELECTED = currency.symbol
                    }
                })
        pickerDialog.show(supportFragmentManager, CountryCurrencyPicker.DIALOG_NAME)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        if (id == R.id.favourite) {
            val intent = Intent(this@MainActivity, FavoriteScreen::class.java)
            startActivity(intent)
        }
        return super.onOptionsItemSelected(item)
    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        return false
    }

    override fun onPointerCaptureChanged(hasCapture: Boolean) {
    }
}