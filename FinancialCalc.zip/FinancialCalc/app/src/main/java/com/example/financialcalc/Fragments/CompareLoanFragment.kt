package com.example.financialcalc.Fragments

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.financialcalc.Activitys.TheoryScreen
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant
import java.math.BigDecimal
import java.math.RoundingMode
import kotlin.math.pow

class CompareLoanFragment : Fragment() {
    private var principalAmount1: EditText? = null
    private var principalAmount2: EditText? = null
    private var interest1: EditText? = null
    private var interest2: EditText? = null
    private var tenure1: EditText? = null
    private var tenure2: EditText? = null
    private var emi1: TextView? = null
    private var emi2: TextView? = null
    private var totalInterestTxt1: TextView? = null
    private var totalInterestTxt2: TextView? = null
    private var totalAmount1: TextView? = null
    private var totalAmount2: TextView? = null
    private var diffEmi: TextView? = null
    private var diffInterest: TextView? = null
    private var diffTotalAmount: TextView? = null
    private var monthToggle: TextView? = null
    private var currency1: TextView? = null
    private var currency2: TextView? = null
    private var knowMore: TextView? = null
    private var calculate: TextView? = null
    private var monthlyToggleBoolean: Boolean = true
    private var answer: LinearLayout? = null
    private var reset: LinearLayout? = null


    private fun initializeView(view: View) {
        reset = view.findViewById(R.id.reset)
        calculate = view.findViewById(R.id.calculate)

        principalAmount2 = view.findViewById<EditText>(R.id.principalAmount2)
        principalAmount1 = view.findViewById<EditText>(R.id.principalAmount1)
        interest1 = view.findViewById<EditText>(R.id.interest1)
        interest2 = view.findViewById<EditText>(R.id.interest2)
        tenure2 = view.findViewById<EditText>(R.id.tenure2)
        tenure1 = view.findViewById<EditText>(R.id.tenure1)

        emi1 = view.findViewById<TextView>(R.id.emi1)
        emi2 = view.findViewById<TextView>(R.id.emi2)
        totalAmount1 = view.findViewById<TextView>(R.id.totalAmount1)
        totalAmount2 = view.findViewById<TextView>(R.id.totalAmount2)
        totalInterestTxt1 = view.findViewById<TextView>(R.id.interestAns1)
        totalInterestTxt2 = view.findViewById<TextView>(R.id.interestAns2)
        diffEmi = view.findViewById<TextView>(R.id.diffEmi)
        diffInterest = view.findViewById<TextView>(R.id.diffInterest)
        diffTotalAmount = view.findViewById<TextView>(R.id.diffTotal)
        monthToggle = view.findViewById(R.id.month)
        currency1 = view.findViewById(R.id.oneCurrency)
        currency2 = view.findViewById<TextView>(R.id.two)
        knowMore = view.findViewById(R.id.knowMore)


        answer = view.findViewById(R.id.answers)
        answer?.visibility = View.GONE
    }

    private fun calculate() {
        val decimal = DecimalClass()
        answer!!.visibility = View.VISIBLE
        var tenureValue1 = 0.0
        var tenureValue2 = 0.0
        var emiVal1 = 0.0
        var emiVal2 = 0.0
        var totalInterest1 = 0.0
        var totalInterest2 = 0.0
        var totalPayment1 = 0.0
        var totalPayment2 = 0.0
        var diffEmiVal = 0.0
        var diffInterestVal = 0.0
        var diffPayment = 0.0
        if (monthlyToggleBoolean) {
            tenureValue1 = tenure1!!.text.toString().toDouble()
            tenureValue2 = tenure2!!.text.toString().toDouble()
        } else {
            tenureValue1 = tenure2!!.text.toString().toDouble() * 12
            tenureValue2 = tenure2!!.text.toString().toDouble() * 12
        }
        val amount1 = principalAmount1!!.text.toString().toDouble()
        val amount2 = principalAmount2!!.text.toString().toDouble()
        val rateVal1 = interest1!!.text.toString().toDouble() / 1200
        val rateVal2 = interest2!!.text.toString().toDouble() / 1200

        var pmt = amount1 * (rateVal1) / (1 - (1 + rateVal1).pow(-tenureValue1))
        totalInterest1 = pmt * tenureValue1 - amount1
        totalPayment1 = totalInterest1 + amount1
        var p = (1 + rateVal1).pow(tenureValue1)
        emiVal1 = amount1 * rateVal1 * p / (p - 1)

        pmt = amount2 * (rateVal2) / (1 - (1 + rateVal2).pow(-tenureValue2))
        totalInterest2 = pmt * tenureValue2 - amount2
        totalPayment2 = totalInterest2 + amount2
        p = (1 + rateVal2).pow(tenureValue2)
        emiVal2 = amount2 * rateVal2 * p / (p - 1)
        totalAmount1?.text = "${decimal.round(totalPayment1)} ${AppConstant.CURRENCY_SELECTED}"
        totalAmount2?.text = "${decimal.round(totalPayment2)} ${AppConstant.CURRENCY_SELECTED}"

        if (totalPayment1 < totalPayment2) {
            totalAmount1!!.setTextColor(Color.parseColor("#26CA6A"))
            totalAmount2!!.setTextColor(Color.parseColor("#F80606"))
            diffPayment = totalPayment2 - totalPayment1
        } else if (totalPayment1 == totalPayment2) {
            totalAmount2!!.setTextColor(Color.parseColor("#FF6D00"))
            totalAmount1!!.setTextColor(Color.parseColor("#FF6D00"))
            diffPayment = 0.0
        } else {
            totalAmount2!!.setTextColor(Color.parseColor("#26CA6A"))
            totalAmount1!!.setTextColor(Color.parseColor("#F80606"))
            diffPayment = totalPayment1 - totalPayment2
        }
        var bd = BigDecimal(diffPayment).setScale(1, RoundingMode.HALF_UP)
        diffPayment = bd.toDouble()
        diffTotalAmount!!.text =
            "Difference:  " + (diffPayment) + " " + AppConstant.CURRENCY_SELECTED

        totalInterestTxt1?.text =
            decimal.round(totalInterest1) + " " + AppConstant.CURRENCY_SELECTED
        totalInterestTxt2?.text =
            decimal.round(totalInterest2) + " " + AppConstant.CURRENCY_SELECTED


        if (totalInterest1 < totalInterest2) {
            diffInterestVal = totalInterest2 - totalInterest1
            totalInterestTxt1!!.setTextColor(Color.parseColor("#26CA6A"))
            totalInterestTxt2!!.setTextColor(Color.parseColor("#F80606"))
        } else if (totalInterest1 == totalInterest2) {
            diffInterestVal = 0.0
            totalInterestTxt1!!.setTextColor(Color.parseColor("#FF6D00"))
            totalInterestTxt2!!.setTextColor(Color.parseColor("#FF6D00"))
        } else {
            diffInterestVal = totalInterest1 - totalInterest2
            totalInterestTxt2!!.setTextColor(Color.parseColor("#26CA6A"))
            totalInterestTxt1!!.setTextColor(Color.parseColor("#F80606"))
        }
        bd = BigDecimal(diffInterestVal).setScale(1, RoundingMode.HALF_UP)
        diffInterestVal = bd.toDouble()
        diffInterest!!.text =
            "Difference:  " + (diffInterestVal) + " " + AppConstant.CURRENCY_SELECTED

        //emi
        emi1?.text = decimal.round(emiVal1) + " " + AppConstant.CURRENCY_SELECTED
        emi2?.text = decimal.round(emiVal2) + " " + AppConstant.CURRENCY_SELECTED

        if (emiVal1 < emiVal2) {
            diffEmiVal = emiVal2 - emiVal1
            emi1!!.setTextColor(Color.parseColor("#26CA6A"))
            emi2!!.setTextColor(Color.parseColor("#F80606"))
        } else if (emiVal1 == emiVal2) {
            diffEmiVal = 0.0
            emi1!!.setTextColor(Color.parseColor("#FF6D00"))
            emi2!!.setTextColor(Color.parseColor("#FF6D00"))
        } else {
            diffEmiVal = emiVal1 - emiVal2
            emi2!!.setTextColor(Color.parseColor("#26CA6A"))
            emi1!!.setTextColor(Color.parseColor("#F80606"))
        }
        bd = BigDecimal(diffEmiVal).setScale(1, RoundingMode.HALF_UP)
        diffEmiVal = bd.toDouble()
        diffEmi!!.text = "Difference:  " + (diffEmiVal) + " " + AppConstant.CURRENCY_SELECTED
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_compare_loan, container, false)
        initializeView(view)
        currency1?.text = AppConstant.CURRENCY_SELECTED
        currency2?.text = AppConstant.CURRENCY_SELECTED

        reset!!.setOnClickListener {
            principalAmount1!!.setText("")
            principalAmount2!!.setText("")
            interest1!!.setText("")
            interest2!!.setText("")
            monthToggle!!.text = "Monthly"
            monthlyToggleBoolean = true
            tenure1!!.setText("")
            tenure2!!.setText("")
            answer!!.visibility = View.GONE
        }
        monthToggle!!.setOnClickListener {
            if (monthlyToggleBoolean) {
                monthlyToggleBoolean = false
                monthToggle!!.text = "Yearly"
            } else {
                monthlyToggleBoolean = true
                monthToggle!!.text = "Monthly"
            }
        }
        knowMore!!.setOnClickListener {
            val intent = Intent(context, TheoryScreen::class.java)
            intent.putExtra("NAME_OF_APP", "Compare Loan")
            startActivity(intent)
        }
        calculate!!.setOnClickListener {
            if (principalAmount1!!.text.toString().isEmpty() || principalAmount2!!.text.toString()
                    .isEmpty() || tenure2!!.text.toString().isEmpty()
                || interest1!!.text.toString().isEmpty() || interest2!!.text.toString()
                    .isEmpty() || tenure1!!.text.toString().isEmpty()
            ) {
                Toast.makeText(context, "Enter all the * values", Toast.LENGTH_SHORT).show()
            } else if (interest2!!.text.toString().toDouble() > 50 || interest1!!.text.toString()
                    .toDouble() > 50
            ) {
                Toast.makeText(context, "Interest should be less than 50%", Toast.LENGTH_SHORT)
                    .show()
            } else {
                calculate()
            }
        }
        return view
    }
}