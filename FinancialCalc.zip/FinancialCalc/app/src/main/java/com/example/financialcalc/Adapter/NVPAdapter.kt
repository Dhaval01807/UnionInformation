package com.example.financialcalc.Adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class NPVAdapter(
    var context: Context,
    var list: List<Double>,
    private val mAdapterCallback: AdapterCallback
) :
    RecyclerView.Adapter<NPVAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.irr_element, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.investment.setText(list[holder.adapterPosition].toString())


        holder.investment.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (holder.investment.text.toString().isEmpty()) {
                    val p = 0.0
                    AppConstant.NPV_LiST[holder.adapterPosition] = p
                } else {
                    val p = holder.investment.text.toString().toDouble()
                    AppConstant.NPV_LiST[holder.adapterPosition] = p
                }
            }

            override fun afterTextChanged(s: Editable) {
                if (holder.investment.text.toString().isEmpty()) {
                    val p = 0.0
                    AppConstant.NPV_LiST[holder.adapterPosition] = p
                } else {
                    val p = holder.investment.text.toString().toDouble()
                    AppConstant.NPV_LiST[holder.adapterPosition] = p
                }
            }
        })

        holder.delete.setOnClickListener {
            AppConstant.NPV_LiST.removeAt(position)
            mAdapterCallback.onMethodCallback()
        }
    }

    interface AdapterCallback {
        fun onMethodCallback()
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var investment: EditText = itemView.findViewById<EditText>(R.id.investment)
        var delete: ImageButton = itemView.findViewById<ImageButton>(R.id.delete)
    }
}