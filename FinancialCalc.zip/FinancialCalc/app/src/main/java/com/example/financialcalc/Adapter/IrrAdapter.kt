package com.example.financialcalc.Adapter

import android.content.Context
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class IrrAdapter(
    var context: Context,
    var list: List<Double>,
    private val mAdapterCallback: AdapterCallback
) :
    RecyclerView.Adapter<IrrAdapter.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        var inflater: LayoutInflater = LayoutInflater.from(context)
        val view: View = inflater.inflate(R.layout.irr_element, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.investment.setText(list[holder.adapterPosition].toString())

        holder.currency.text = AppConstant.CURRENCY_SELECTED

        holder.investment.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }

            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                if (holder.investment.text.toString().isEmpty()) {
                    val p = 0.0
                    AppConstant.IRR_LIST[holder.adapterPosition] = p
                } else {
                    val p = holder.investment.text.toString().toDouble()
                    AppConstant.IRR_LIST[holder.adapterPosition] = p
                }
            }

            override fun afterTextChanged(s: Editable) {
                if (holder.investment.text.toString().isEmpty()) {
                    val p = 0.0
                    AppConstant.IRR_LIST[holder.adapterPosition] = p
                } else {
                    val p = holder.investment.text.toString().toDouble()
                    AppConstant.IRR_LIST[holder.adapterPosition] = p
                }
            }
        })

        holder.delete.setOnClickListener {
            AppConstant.IRR_LIST.removeAt(position)
            mAdapterCallback.onMethodCallback()
        }
    }

    interface AdapterCallback {
        fun onMethodCallback()
    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var investment: EditText = itemView.findViewById<EditText>(R.id.investment)
        var delete: ImageButton = itemView.findViewById<ImageButton>(R.id.delete)
        var currency: TextView = itemView.findViewById<TextView>(R.id.currency1)
    }
}