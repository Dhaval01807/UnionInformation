package com.example.financialcalc.Fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.financialcalc.Adapter.DiscountAdapter
import com.example.financialcalc.Helper.DecimalClass
import com.example.financialcalc.Helper.DiscountListClass
import com.example.financialcalc.R
import com.example.financialcalc.Utils.AppConstant

class DiscountFragment : Fragment(), DiscountAdapter.AdapterCallback {
    private var itemName: EditText? = null
    private var qty: EditText? = null
    private var actualValue: EditText? = null
    private var discountValue: EditText? = null
    private var overAllDiscount: EditText? = null
    private var recyclerView: RecyclerView? = null
    private var ans: LinearLayout? = null
    private var addStocks: LinearLayout? = null
    private var resetBtn: LinearLayout? = null
    private var addDiscount: LinearLayout? = null
    private var removeDiscount: SwitchCompat? = null
    private var c1: TextView? = null
    private var c2: TextView? = null
    private var calculate: TextView? = null
    private var totalPrice: TextView? = null
    private var percentageToggle: TextView? = null
    private var currencyToggle: TextView? = null
    private var priceSold: TextView? = null
    private var discountPercentage: TextView? = null
    private var discountAmount: TextView? = null
    private var decimals: DecimalClass? = null
    private var removeDiscountBoolean: Boolean = false
    private var percentageToggleBool: Boolean = true
    private var gridLayoutManager1: GridLayoutManager? = null
    private var discountAdapter: DiscountAdapter? = null


    private fun initializeView(view: View) {
        itemName = view.findViewById(R.id.itemName)
        qty = view.findViewById(R.id.qty)
        actualValue = view.findViewById<EditText>(R.id.autualValue)
        discountValue = view.findViewById<EditText>(R.id.discountValue)
        overAllDiscount = view.findViewById<EditText>(R.id.overallDiscount)

        recyclerView = view.findViewById(R.id.recycler)

        ans = view.findViewById(R.id.answers)
        addStocks = view.findViewById(R.id.add)
        resetBtn = view.findViewById(R.id.reset)
        addDiscount = view.findViewById<LinearLayout>(R.id.addDiscount)

        removeDiscount = view.findViewById<SwitchCompat>(R.id.removeDiscount)

        c1 = view.findViewById(R.id.currency1)
        c2 = view.findViewById<TextView>(R.id.currency2)
        calculate = view.findViewById(R.id.calculate)
        totalPrice = view.findViewById<TextView>(R.id.totalPrice)
        percentageToggle = view.findViewById<TextView>(R.id.percentToggle)
        currencyToggle = view.findViewById<TextView>(R.id.currencyToggle)
        priceSold = view.findViewById<TextView>(R.id.priceSold)
        discountPercentage = view.findViewById<TextView>(R.id.totalDiscountercentage)
        discountAmount = view.findViewById<TextView>(R.id.discountValueAns)

        ans?.visibility = View.GONE
        
        addDiscount?.visibility = View.INVISIBLE
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_discount, container, false)
        initializeView(view)
        currencyToggle?.text = AppConstant.CURRENCY_SELECTED
        c1?.text = AppConstant.CURRENCY_SELECTED
        c2?.text = AppConstant.CURRENCY_SELECTED
        addStocks!!.setOnClickListener {
            val discountList: DiscountListClass = DiscountListClass(0.0, 1.0, 0.0, "Item Name")
            AppConstant.DISCOUNT_LIST.add(discountList)
            addNewRecycler()
        }
        calculate!!.setOnClickListener {
            if (qty!!.text.toString().isEmpty()) {
                qty!!.setText("1")
            }
            if (qty!!.text.toString().isNotEmpty() && actualValue!!.text.toString().isNotEmpty()
                && discountValue!!.text.toString().isNotEmpty()
            ) {
                calculate()
            } else {
                Toast.makeText(context, "Enter All the Value", Toast.LENGTH_LONG).show()
            }
        }
        resetBtn!!.setOnClickListener {
            itemName!!.setText("")
            removeDiscount!!.isChecked = false
            addDiscount!!.visibility = View.GONE
            removeDiscountBoolean = false
            qty!!.setText("1")
            actualValue!!.setText("")
            overAllDiscount!!.setText("")
            discountValue!!.setText("")
            ans!!.visibility = View.GONE
            AppConstant.DISCOUNT_LIST.clear()
            addNewRecycler()
        }
        percentageToggle!!.setOnClickListener {
            percentageToggle!!.setBackgroundResource(R.drawable.toggle_on)
            currencyToggle!!.background = null
            percentageToggleBool = true
        }
        currencyToggle!!.setOnClickListener {
            percentageToggle!!.background = null
            currencyToggle!!.setBackgroundResource(R.drawable.toggle_on)
            percentageToggleBool = false
        }
        removeDiscount!!.setOnCheckedChangeListener { compoundButton, b ->
            removeDiscountBoolean = b
            if (removeDiscountBoolean) {
                addDiscount!!.visibility = View.VISIBLE
            } else {
                addDiscount!!.visibility = View.INVISIBLE
            }
            addNewRecycler()
        }

        return view
    }

    private fun calculate() {
        ans!!.visibility = View.VISIBLE
        decimals = DecimalClass()
        var totalPriceValue =
            actualValue!!.text.toString().toDouble() * qty!!.text.toString().toDouble()
        var i = 0
        for (d in AppConstant.DISCOUNT_LIST) {
            totalPriceValue += d.qty * d.actualValue
            i++
        }

        if (removeDiscountBoolean) {
            if (overAllDiscount!!.text.toString().isNotEmpty()) {
                val d = overAllDiscount!!.text.toString().toDouble()
                if (percentageToggleBool) {
                    val dv = d * totalPriceValue / 100
                    discountAmount!!.text =
                        ("" + decimals?.round(dv)) + " " + AppConstant.CURRENCY_SELECTED
                    discountPercentage!!.text = ("" + decimals?.round(d)).toString() + " %"
                    priceSold!!.text =
                        ("" + decimals?.round(totalPriceValue - dv)).toString() + " " + AppConstant.CURRENCY_SELECTED
                } else {
                    discountAmount!!.text =
                        ("" + decimals?.round(d)).toString() + " " + AppConstant.CURRENCY_SELECTED
                    discountPercentage!!.text =
                        ("" + decimals?.round(d / totalPriceValue * 100)).toString() + " %"
                    priceSold!!.text =
                        ("" + decimals?.round(totalPriceValue - d)).toString() + " " + AppConstant.CURRENCY_SELECTED
                }
            } else {
                Toast.makeText(context, "Add the value of OverAll Discount", Toast.LENGTH_SHORT)
                    .show()
            }
        } else {
            var discountPriceValue = discountValue!!.text.toString().toDouble()
            for (d in AppConstant.DISCOUNT_LIST) {
                discountPriceValue += d.discountValue
            }
            discountAmount!!.text =
                ("" + decimals?.round(discountPriceValue)).toString() + " " + AppConstant.CURRENCY_SELECTED

            discountPercentage!!.text =
                ("" + decimals?.round(discountPriceValue / totalPriceValue * 100)).toString() + " %"
            priceSold!!.text =
                ("" + decimals?.round(totalPriceValue - discountPriceValue)).toString() + " " + AppConstant.CURRENCY_SELECTED
        }
        totalPrice!!.text =
            ("" + decimals?.round(totalPriceValue)).toString() + " " + AppConstant.CURRENCY_SELECTED
    }

    private fun addNewRecycler() {
        discountAdapter = DiscountAdapter(
            requireContext(), AppConstant.DISCOUNT_LIST, removeDiscountBoolean,
            this
        )
        gridLayoutManager1 = GridLayoutManager(context, 1, GridLayoutManager.VERTICAL, false)
        recyclerView!!.layoutManager = gridLayoutManager1
        recyclerView!!.adapter = discountAdapter
    }

    override fun onMethodCallback() {
        addNewRecycler()
    }
}