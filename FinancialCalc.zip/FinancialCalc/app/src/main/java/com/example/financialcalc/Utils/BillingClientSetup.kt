package com.example.financialcalc.Utils

import android.content.Context
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.PurchasesUpdatedListener

object BillingClientSetup {
    private val instance: BillingClient? = null

    fun getInstance(
        context: Context,
        purchasesUpdatedListener: PurchasesUpdatedListener
    ): BillingClient {
        val billingClient = instance
        return billingClient ?: setupBillingClient(context, purchasesUpdatedListener)
    }

    private fun setupBillingClient(
        context: Context,
        purchasesUpdatedListener: PurchasesUpdatedListener
    ): BillingClient {
        return BillingClient.newBuilder(context).enablePendingPurchases()
            .setListener(purchasesUpdatedListener).build()
    }
}